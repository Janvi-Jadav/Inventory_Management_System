<?php
include 'fpdf.php';
include 'exfpdf.php';
include 'easyTable.php';

$pdf=new exFPDF();
$pdf->AliasNbPages();
$pdf->AddPage(); 
$pdf->SetFont('helvetica','',10);

$pdf->orderDerails("2021-02-21 15:12:49", "ch_1INJc4D3LGdOphZhUzFGOYW9");
$pdf->orderNo("00268");
$bill_add = "Uzaima Nagi,40 Braziers Qauy South Street, City, Bishop's Stortford, England, GB - CM23 3YW";
$ship_add = "Uzaima Nagi,40 Braziers Qauy South Street, City, Bishop's Stortford, England, GB - CM23 3YW";
$pdf->addClientAdresse($bill_add, $ship_add);
//$pdf->addClientAdresse($bill_add);


$table=new easyTable($pdf, '{100, 100}', 'width:70; border:0; font-size:8; line-height:1.2; paddingX:0');
 
$table->easyCell('Items in your cart','font-size:12;font-style:B;');
$table->easyCell('(5) items','font-size:12;font-style:B;align:R;');
$table->printRow();

$table->endTable(0);


$table=new easyTable($pdf, '{20, 90, 20, 20, 20, 30}','align:C{LCRR};border:1; border-color:#a1a1a1; ');

$table->easyCell("IMAGE", "align:C; font-size:8;font-style:B;valign:B");
$table->easyCell("NAME", "align:C; font-size:8;font-style:B;valign:B");
$table->easyCell("QUANTITE", "align:C; font-size:8;font-style:B;:B");
$table->easyCell("PRICE", "align:C; font-size:8;font-style:B;valign:B");
$table->easyCell("TOTAL", "align:C; font-size:8;font-style:B;valign:B");
$table->easyCell("", "align:C; font-size:8; valign:B");
$table->printRow();

$table->easyCell("", 'img:image.png,w10;align:C; font-size:8; valign:M');
$table->easyCell("10 PACK 9H Fully Curved Tempered Protective Glass forIPhone SE 11 Pro Max XR X XS Max 7 8 6 Plus 5 ScreenProtector IPhone SE 11 Pro Max X 10 PACK 9H FullyCurved Tempered Protective Glass for IPhone SE 11 ProMax XR X XS Max 7 8 6 Plus 5 Screen Protector IPhoneSE 11 Pro Max X\n<b>Cable Colours : Black\nLengths : 1 Meter</b>\n\n <s 'font-size:8;font-color:#ff0000;align:R;'>Discount Applied</s>", 'align:L; font-size:8; valign:T');
$table->easyCell("1", 'align:C; font-size:8; valign:M');
$table->easyCell("<s 'font-size:10;'><b>$0.79</b>\n <s 'font-size:8;font-color:#ff0000;'>($2.99)</s></s>", 'align:C; font-size:10; valign:M');
$table->easyCell("$2.99", 'align:C; font-size:8; valign:M');
$table->easyCell("<s 'font-size:10;font-color:#ff0000; href:http://www.fpdf.org/'>ORDER AGAIN</s>", 'align:C; font-size:8; valign:M');
$table->printRow();

$table->easyCell("", 'img:image.png,w10;align:C; font-size:8; valign:M');
$table->easyCell("10 PACK 9H Fully Curved Tempered Protective Glass forIPhone SE 11 Pro Max XR X XS Max 7 8 6 Plus 5 ScreenProtector IPhone SE 11 Pro Max X 10 PACK 9H FullyCurved Tempered Protective Glass for IPhone SE 11 ProMax XR X XS Max 7 8 6 Plus 5 Screen Protector IPhoneSE 11 Pro Max X\n<b>Cable Colours : Black\nLengths : 1 Meter</b>\n\n <s 'font-size:8;font-color:#ff0000;align:R;'>Discount Applied</s>", 'align:L; font-size:8; valign:T');
$table->easyCell("1", 'align:C; font-size:8; valign:M');
$table->easyCell("<s 'font-size:10;'><b>$0.79</b>\n <s 'font-size:8;font-color:#ff0000;'>($2.99)</s></s>", 'align:C; font-size:10; valign:M');
$table->easyCell("$2.99", 'align:C; font-size:8; valign:M');
$table->easyCell("<s 'font-size:10;font-color:#ff0000; href:http://www.fpdf.org/'>ORDER AGAIN</s>", 'align:C; font-size:8; valign:M');
$table->printRow();

$table->easyCell("", 'img:image.png,w10;align:C; font-size:8; valign:M');
$table->easyCell("10 PACK 9H Fully Curved Tempered Protective Glass forIPhone SE 11 Pro Max XR X XS Max 7 8 6 Plus 5 ScreenProtector IPhone SE 11 Pro Max X 10 PACK 9H FullyCurved Tempered Protective Glass for IPhone SE 11 ProMax XR X XS Max 7 8 6 Plus 5 Screen Protector IPhoneSE 11 Pro Max X\n<b>Cable Colours : Black\nLengths : 1 Meter</b>", 'align:L; font-size:8; valign:T');
$table->easyCell("1", 'align:C; font-size:8; valign:M');
$table->easyCell("<s 'font-size:10;'><b>$0.79</b></s>", 'align:C; font-size:10; valign:M');
$table->easyCell("$2.99", 'align:C; font-size:8; valign:M');
$table->easyCell("<s 'font-size:10;font-color:#ff0000; href:http://www.fpdf.org/'>ORDER AGAIN</s>", 'align:C; font-size:8; valign:M');
$table->printRow();



$table->endTable(5);

$tableB=new easyTable($pdf, 2, 'width:75; align:R{LC}; border:1;border-color:#a1a1a1;');

$tableB->easyCell("Total Quantity", 'border:LT;font-size:10;font-style:B;valign:M;');
$tableB->easyCell("1 PCS.", 'border:RT;align:R;font-size:10;font-style:B;valign:M;');
$tableB->printRow();

$tableB->easyCell("Shipping Charges", 'border:LT;font-size:10;font-style:B;valign:M;');
$tableB->easyCell("Free", 'border:RT;align:R;font-size:10;font-style:B;valign:M;');
$tableB->printRow();

$tableB->easyCell("Total (in. VAT)", 'border:LTB;font-size:10;font-style:B;valign:M;');
$tableB->easyCell("$2.99", 'border:RTB;align:R;font-size:10;font-style:B;valign:M;');
$tableB->printRow();

$tableB->endTable(10);

$pdf->Output('D','filename.pdf'); 

?>