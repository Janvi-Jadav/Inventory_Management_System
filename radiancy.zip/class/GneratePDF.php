<?php


use Carbon\Carbon;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;

class GneratePDF
{

  public static function DownloadStockReport()
  {


    $products = Product::where('is_active', 1)->orderBy('id', 'DESC')->get();

    $pdf = new exFPDF('P', 'mm', 'A4');
    $pdf->SetMargins(2, 2, 2);
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 10);

    $table1 = new easyTable($pdf, '{210}', 'font-style:B;border:0;font-size:15; ');

    $table1->easyCell('Product Stock Report', 'align:C;');
    $table1->printRow();
    $table1->endTable(3);

    $table2 = new easyTable($pdf, '{160,50}', 'align:L;border:1;font-size:12');

    $table2->easyCell('Product Name', 'font-style:B;align:L;paddingY:0.1;paddingY:1;');
    $table2->easyCell('Qty', 'font-style:B;align:R;paddingY:0.1;paddingY:1;');
    $table2->printRow();
    $table2->endTable(0);

    $table3 = new easyTable($pdf, '{160,50}', 'align:L;border:1;font-size:10');

    foreach ($products as $p) {
      $table3->easyCell($p->name, 'font-style:B;align:L;paddingY:0.1;paddingY:1;');
      $table3->easyCell($p->curr_stock, 'font-style:B;align:R;paddingY:0.1;paddingY:1;');
      $table3->printRow();
    }
    $table3->endTable(3);

    $pdf_name = 'stock_report_' . Carbon::now()->format('d-m-Y');

    // $pdf->Output();
    $pdf->Output('D', $pdf_name . '.pdf');
  }
}
