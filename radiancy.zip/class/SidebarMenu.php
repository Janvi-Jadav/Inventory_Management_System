<?php

class SidebarMenu
{

	private $menu = array();

	function add($menu)
	{
		array_push($this->menu, $menu);
	}

	function get_menu()
	{
		return $this->menu;
	}
}
