<?php
include('bootstrap.php');
include('assets/phpqrcode/qrlib.php');
 
class Qrgenearate{

  public static function generateqr($text){
    global $doc_rt_url;
    $path = $doc_rt_url . "uploads/qrcode/";
    $name = time().uniqid().".png";
    $qrcode = $path.$name;
    QRcode::png($text,$qrcode);   
    return $name;     
  }
}
?>