<?php
class BarcodeGenerate
{
    public static function generateBarcode($sku, $barcode)
    {
        global $doc_rt_url;
        global $config;

        $name = $barcode . '.png';

        $path = $doc_rt_url . '/dist/';
        $font = $path . '/arial.ttf';

        $filename = rand(9, 99) . 'barcode.png';
        $txt_save = "str-block.png";
        $qr_save = $doc_rt_url . "/uploads/qrcode/" . $name;

        $resize_width = (144 * 14);
        $resize_height = (43 * 14);

        imageGenereaterBlock($sku, $barcode, $filename, $txt_save, $resize_width, $resize_height, $path);
        // Create the image
        $im_wd = 2250;
        $im_th = 1470;

        $im_txt_wd = 2250;
        $im_txt_th = 550;

        $im = imagecreatetruecolor($im_wd, $im_th);

        // Create some colors
        $white = imagecolorallocate($im, 255, 255, 255);
        $grey = imagecolorallocate($im, 128, 128, 128);
        $black = imagecolorallocate($im, 0, 0, 0);
        imagefilledrectangle($im, 0, 0, $im_wd, $im_th, $white);

        $qr_file = $path . '/' . $filename;
        $txt_file = $path . '/' . $txt_save;

        $srcImage = imagecreatefrompng($qr_file);
        imagecopyresampled($im, $srcImage, 115, 150, 0, 0, $resize_width, $resize_height, $resize_width, $resize_height);
        imagettftext($im, 100, 0, 650, 870, $black, $font, $barcode);

        $srcImages = imagecreatefrompng($txt_file);
        imagecopyresampled($im, $srcImages, 0, 900, 0, 0, $im_txt_wd, $im_txt_th, $im_txt_wd, $im_txt_th);

        imagepng($im, $qr_save);

        unlink($qr_file);
        unlink($txt_file);
        imagedestroy($im);

        return $name;
    }
}
