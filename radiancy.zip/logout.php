<?php

require "bootstrap.php";
$id = getSessionLoginUserID();
$type = "logout";
$date = Carbon\Carbon::now();
// LoginLogoutHistory::add_history($id,$type,$date);

Auth::logout();
