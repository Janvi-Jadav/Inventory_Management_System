<?php
require "bootstrap.php";
?>
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $config['site_name']; ?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/bower_components/bootstrap/dist/css/bootstrap.min.css'; ?>">
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/bower_components/font-awesome/css/font-awesome.min.css'; ?>">
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/bower_components/Ionicons/css/ionicons.min.css'; ?>">
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/dist/css/AdminLTE.min.css'; ?>">
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/plugins/iCheck/square/blue.css'; ?>">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <link rel="icon" type="image/x-icon" href="<?php echo $config['site_url']; ?>/images/fevicon.png" />
</head>

<body class="hold-transition login-page">
  <div class="login-box">
    <div class="login-logo">
      <img src="<?php echo $config['site_url'] . '/images/large-logo.png'; ?>" class="img img-responsive" style="width: 50%;margin:0 25%;">
    </div>
    <!-- /.login-logo -->
    <div class="login-box-body">
      <p class="login-box-msg">Sign in to start your session</p>

      <form action="<?php echo $config['form_action_url'] ?>/do_login.php" method="post">

        <div class="form-group has-feedback">
          <input type="text" class="form-control" placeholder="Email" name="email">
          <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
        </div>
        <div class="form-group has-feedback">
          <input type="password" class="form-control" placeholder="Password" name="password">
          <span class="glyphicon glyphicon-lock form-control-feedback"></span>
        </div>
        <div class="row">
          <div class="col-xs-8">

          </div>
          <!-- /.col -->
          <div class="col-xs-4">
            <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
          </div>
          <!-- /.col -->
        </div>
        <br>
        <div class="row">
          <div class="col-xs-12">



          </div>
        </div>
      </form>

    </div>
    <!-- /.login-box-body -->
  </div>
  <!-- /.login-box -->

  <script src="<?php echo $config['site_url'] . '/bower_components/jquery/dist/jquery.min.js'; ?>"></script>
  <script src="<?php echo $config['site_url'] . '/bower_components/bootstrap/dist/js/bootstrap.min.js'; ?>"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css">
  <script src="<?php echo $config['site_url'] . '/plugins/iCheck/icheck.min.js'; ?>"></script>
  <script>
    $(function() {
      $('input').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        radioClass: 'iradio_square-blue',
        increaseArea: '20%' /* optional */
      });
    });
  </script>

  <script type="text/javascript">
    <?php if (isset($_SESSION['flash'])) { ?>
      var type = "<?php echo (isset($_SESSION['flash']['type'])) ? $_SESSION['flash']['type'] : 'info' ?>";
      switch (type) {
        case 'info':
          toastr.info("<?php echo $_SESSION['flash']['message'] ?>");
          break;
        case 'warning':
          toastr.warning("<?php echo $_SESSION['flash']['message'] ?>");
          break;
        case 'success':
          toastr.success("<?php echo $_SESSION['flash']['message'] ?>");
          break;
        case 'error':
          toastr.error("<?php echo $_SESSION['flash']['message'] ?>");
          break;
      }
    <?php unset($_SESSION['flash']);
    } ?>
  </script>

</body>

</html>