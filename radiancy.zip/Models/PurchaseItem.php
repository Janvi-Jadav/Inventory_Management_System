<?php

//namespace Models;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model as Eloquent;
use Illuminate\Database\Capsule\Manager as Capsule;

class PurchaseItem extends Eloquent
{
  protected $table = 'purchase_item';
  protected $primaryKey = 'id';


  public function __construct($table_name = null)
  {
    parent::__construct();
    if ($table_name != NULL) {
      $this->table = $table_name;
    }
  }

  public function product()
  {
    return $this->belongsTo(Product::class, 'item_id', 'id');
  }

  function purchase()
  {
    return $this->belongsTo(Purchase::class, 'purchase_id', 'id');
  }
}
