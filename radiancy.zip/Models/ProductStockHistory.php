<?php

//namespace Models;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model as Eloquent;
use Illuminate\Database\Capsule\Manager as Capsule;

class ProductStockHistory extends Eloquent
{
  protected $table = 'product_stock_history';
  protected $primaryKey = 'id';


  public function __construct($table_name = null)
  {
    parent::__construct();
    if ($table_name != NULL) {
      $this->table = $table_name;
    }
  }

  public static function createProductHistory($pdr_id, $inv_id, $qty, $old_curr_stock, $new_curr_stock, $type)
  {
    $user_id = getSessionLoginUserID();
    $history = new ProductStockHistory();
    $history->pdr_id = $pdr_id;
    $history->inv_id = $inv_id;
    $history->type = $type;
    $history->qty = $qty;
    $history->old_curr_stock = $old_curr_stock;
    $history->new_curr_stock = $new_curr_stock;
    $history->user_id = $user_id;
    $history->save();
  }
}
