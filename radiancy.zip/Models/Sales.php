<?php

//namespace Models;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model as Eloquent;
use Illuminate\Database\Capsule\Manager as Capsule;

class Sales extends Eloquent
{
  protected $table = 'sales';
  protected $primaryKey = 'id';


  public function __construct($table_name = null)
  {
    parent::__construct();
    if ($table_name != NULL) {
      $this->table = $table_name;
    }
  }

  public function party()
  {
    return $this->belongsTo(Party::class, 'party_id', 'id');
  }

  public function user()
  {
    return $this->belongsTo(User::class, 'user_id', 'user_id');
  }

  public function sales_items()
  {
    return $this->hasMany(SalesItem::class, 'sales_id', 'id');
  }

  public static function getInvoiceNo()
  {
    $last_stock = Sales::orderBy('id', 'desc')->first();
    if ($last_stock == NULL) {
      $invoice = 1;
    } else {
      $inv = ($last_stock->inv_no + 1);
      $invoice = ($inv != '' ? $inv : 1);
    }
    return $invoice;
  }
}
