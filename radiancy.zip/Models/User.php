<?php

//namespace Models;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model as Eloquent;
use Illuminate\Database\Capsule\Manager as Capsule;

class User extends Eloquent
{
  protected $table = 'users';
  protected $primaryKey = 'user_id';
  protected $appends = ['fullname'];


  public function __construct($table_name = null)
  {
    parent::__construct();
    if ($table_name != NULL) {
      $this->table = $table_name;
    }
  }

  public static function getShopNameById($shop_id)
  {
    $shop = USer::findUserById($shop_id);
    return $shop->first_name . ' ' . $shop->last_name;
  }


  public static function getUserById($id)
  {
    $user = User::find($id);
    return $user;
  }

  public static function getUserByType($type, $is_active = null)
  {
    $user = User::where('user_type', $type);
    if ($is_active != null) {
      $user = $user->where('is_active', $is_active);
    }
    $user = $user->get();
    return $user;
  }

  public function getFullnameAttribute()
  {
    return $this->first_name . ' ' . $this->last_name;
  }

  public static function getUserByAdminID($id)
  {

    $user = User::where(array('user_type' => 'user', 'parent_admin_user_id' => $id))->orwhere(array('user_id' => $id))->orderBy('user_type', 'ASC')->get();
    return $user;
  }
  public static function checkUserStatus($id)
  {
    $user = User::where(array('user_id' => $id, 'is_active' => 1))->first();
    return $user;
  }

  public static function findUserById($id)
  {
    $user = User::where(array('user_id' => $id))->first();
    return $user;
  }
}
