<?php

//namespace Models;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model as Eloquent;
use Illuminate\Database\Capsule\Manager as Capsule;

class Product extends Eloquent
{
  protected $table = 'products';
  protected $primaryKey = 'id';


  public function __construct($table_name = null)
  {
    parent::__construct();
    if ($table_name != NULL) {
      $this->table = $table_name;
    }
  }

  public static function updateStock($prd_id, $id, $qty, $type, $inv_type)
  {

    $product = Product::find($prd_id);

    $product_old_stock = $product->curr_stock;
    $product_new_stock = 0;

    if ($product != null) {
      if ($type == 'add') {
        $product->curr_stock = $product->curr_stock + $qty;
        $product_new_stock = $product_old_stock + $qty;
      }
      if ($type == 'minus') {
        $product->curr_stock = $product->curr_stock - $qty;
        $product_new_stock = $product_old_stock - $qty;
      }
      if ($type == 'replace') {
        $product->curr_stock = $qty;
        $product_new_stock =  $qty;
      }
      if ($type == 'opening_stock') {
        $product->curr_stock = $qty;
        $product_new_stock =  $qty;
      }
      $product->save();
      ProductStockHistory::createProductHistory($prd_id, $id, $qty, $product_old_stock, $product_new_stock, $inv_type);
    }
  }
}
