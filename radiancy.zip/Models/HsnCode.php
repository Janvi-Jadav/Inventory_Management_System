<?php

//namespace Models;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model as Eloquent;
use Illuminate\Database\Capsule\Manager as Capsule;

class HsnCode extends Eloquent
{
  protected $table = 'hsn_code';
  protected $primaryKey = 'id';


  public function __construct($table_name = null)
  {
    parent::__construct();
    if ($table_name != NULL) {
      $this->table = $table_name;
    }
  }
}
