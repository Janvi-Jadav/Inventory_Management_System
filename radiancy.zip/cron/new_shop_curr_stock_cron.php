
<?php
$db_mode = 1;
include('../bootstrap.php');
ini_set('max_execution_time', -1);

use Carbon\Carbon;

$shops = User::getActiveShop();
$products = Product::getActiveProduct();

foreach ($products as $p) {
  $product_id = $p->id;
  foreach ($shops as $shop) {
    $shop_id = $shop->user_id;
    $exist = (new SpCurrentStock($shop_id))->where('pdr_id', $product_id)->first();
    if ($exist == null) {
      $new_shop_product = (new SpCurrentStock($shop_id));
      $new_shop_product->shop_id = $shop_id;
      $new_shop_product->pdr_id = $product_id;
      $new_shop_product->min_qty = 0;
      $new_shop_product->save();
    }
  }
}
