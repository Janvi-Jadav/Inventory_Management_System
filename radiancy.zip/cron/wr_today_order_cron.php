
<?php
$db_mode = 1;
include('../bootstrap.php');
ini_set('max_execution_time', -1);

use Carbon\Carbon;

$product_limit = 100;
$cur_date = Carbon::now()->format('Y-m-d');
$shops = User::getActiveShop();
$past_date = Carbon::now()->subDay(1);
WrTodayOrder::whereDate('created_at', $past_date)->delete();
$wr_stocks = WrTodayOrder::whereDate('order_date', Carbon::now())->where('is_reset', 0)->pluck('pdr_id');

$products = Product::with('category')->where('is_active', 1)->where('wr_min_qty', '>', 0)->wherenotIn('id', $wr_stocks)->take($product_limit)->get();

if ($products->count() > 0) {
  $get_progress = Progress::where('key', 'is_data_loading')->first();
  if ($get_progress == null) {
    $progress = new Progress();
    $progress->key = 'is_data_loading';
    $progress->value = 1;
    $progress->save();
  } else {
    $get_progress->value = 1;
    $get_progress->save();
  }

  foreach ($products as $product) {
    $insert = new WrTodayOrder();
    $prd_id = $product->id;
    // $wr_stock = $product->warehouse_stock;
    $category = $product->category;
    $cat_id = $product->category->id;
    $brand_id = $product->brand->id;
    $type = ($category->is_vape == 1 ? 'vape' : 'other');
    $insert->pdr_id = $prd_id;
    $insert->type = $type;
    $wr_req_qty = ($product->wr_min_qty - $product->wr_curr_stock);
    $wr_to_shop_send = $product->wr_shop_qty;
    $shop_order = 0;
    foreach ($shops as $shop) {
      $start_date = Carbon::now()->subDays(30)->startOfDay();
      $end_date = Carbon::now()->endOfDay();
      $order_count = WrBillItem::where('pdr_id', $prd_id)->where('created_at', '>', $start_date)->where('created_at', '<', $end_date)->sum('qty');
      // $order_count = 0;
      $insert->last_month_sell_count = $order_count;
      $req_order = (new SpCurrentStock($shop->user_id))::getShopRequiredRealQty($prd_id, $shop->user_id);

      $prd_code = ProductBarcode::where('pdr_id', $prd_id)->orderBy('qty', 'DESC')->first();
      $pcs = 1;
      if ($prd_code != null) {
        $pcs = $prd_code->qty;
      }

      $cl_nm = Product::getClmnNameLower($shop->first_name);
      $shop_order = $shop_order +
        $req_order['req_qty'];
    }
    $consider_qty = 0;
    $consider_qty = $shop_order + $wr_req_qty;

    if ($consider_qty <= 0) {
      $consider_qty == 0;
    }
    $insert->odr_qty = $consider_qty;
    $last_ord_date = WrBillItem::where('pdr_id', $product->id)->orderBy('id', 'DESC')->first();
    $insert->last_order_date = $last_ord_date == null ? null : $last_ord_date->created_at;
    $insert->order_date = Carbon::now();
    $insert->save();
  }
} else {
  $get_progress = Progress::where('key', 'is_data_loading')->first();
  $get_progress->value = 0;
  $get_progress->save();
}
