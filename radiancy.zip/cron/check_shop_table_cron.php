<?php
$db_mode = 1;
include('../bootstrap.php');

use Carbon\Carbon;

// $party = (new SpCurrentStock(5))->get();
$users = User::whereIn('user_type', array('shop'))->get();
foreach ($users as $shop) {
  $shop_id = $shop->user_id;
  User::createNewSpCurrentStockTable($shop_id);
  User::createNewSpBillTable($shop_id);
  User::createNewSpBillItemTable($shop_id);
  User::createNewSpSkipItemTable($shop_id);
  User::createNewSpErrorLogTable($shop_id);
  User::createNewSpQuickUpdateHistoryTable($shop_id);
  User::createNewSpTodayOrderTable($shop_id);
  User::createNewSpEodTable($shop_id);
  User::createNewSpEodHistoryTable($shop_id);
  User::createNewSpPosBillTable($shop_id);
  User::createNewSpPosBillItemTable($shop_id);
  User::createNewSpPosDeleteBillTable($shop_id);
  User::createNewSpPosDeleteBillItemTable($shop_id);
  User::createNewSpPosBillCurrencyTable($shop_id);
  User::createNewSpOrderTable($shop_id);
  User::createNewSpOrderItemTable($shop_id);
  User::createNewSpRefundTable($shop_id);
  User::createNewSpRefundItemTable($shop_id);
  User::createNewSpExchangeTable($shop_id);
  User::createNewSpExchangeItemTable($shop_id);

  User::createNewSpWalletHistoryTable($shop_id);
}
