
<?php
$db_mode = 1;
include('../bootstrap.php');
ini_set('max_execution_time', -1);

use Carbon\Carbon;

$past_date = Carbon::now()->subDay(1);
$product_limit = 10000;
$shops = User::getActiveShop();
foreach ($shops as $del_shop) {
  (new SpTodayOrder($del_shop->user_id))->whereDate('created_at', $past_date)->delete();
}
foreach ($shops as $shop) {
  $shop_id = $shop->user_id;
  $wr_stocks = (new SpTodayOrder($shop_id))->whereDate('created_at', Carbon::now())->where('is_reset', 0)->pluck('pdr_id');
  $products = Product::with('category')->where('wr_shop_qty', '>', 0)->wherenotIn('id', $wr_stocks)->take($product_limit)->get();
  if ($products->count() > 0) {
    $get_progress = Progress::where('key', 'is_shop_data_loading')->first();
    if ($get_progress == null) {
      $progress = new Progress();
      $progress->key = 'is_shop_data_loading';
      $progress->value = 1;
      $progress->save();
    } else {
      $get_progress->value = 1;
      $get_progress->save();
    }
    foreach ($products as $product) {
      //dd($product);
      $prd_id = $product->id;
      $category = $product->category;
      $type = ($category->is_vape == 1 ? 'vape' : 'other');

      $need_send_qty = (new SpCurrentStock($shop_id))->getRequiredQty($prd_id, $shop_id);

      if ($need_send_qty > 0) {
        $td_order_insert = (new SpTodayOrder($shop_id));
        $td_order_insert->type = $type;
        $td_order_insert->pdr_id = $prd_id;
        $td_order_insert->shop_id = $shop_id;
        $td_order_insert->qty = $need_send_qty;
        $td_order_insert->order_date = Carbon::now();
        $td_order_insert->save();
      } else {
        $td_order_insert = (new SpTodayOrder($shop_id));
        $td_order_insert->type = $type;
        $td_order_insert->pdr_id = $prd_id;
        $td_order_insert->shop_id = $shop_id;
        $td_order_insert->order_date = Carbon::now();
        $td_order_insert->qty = 0;
        $td_order_insert->save();
      }
    }
  } else {
    $get_progress = Progress::where('key', 'is_shop_data_loading')->first();
    $get_progress->value = 0;
    $get_progress->save();
  }
}
?>