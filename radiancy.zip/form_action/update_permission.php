<?php

require "../bootstrap.php";

use Carbon\Carbon;

$user_id = get_form_value('master_user');
$permission = get_form_value('permission');


Permission::where(array('user_id' => $user_id))->update(['is_active' => 0]);
foreach ($permission as $p) {
  Permission::updateOrCreate(array(
    'user_id' => $user_id,
    'permission' => $p
  ), array(
    'user_id' => $user_id,
    'permission' => $p,
    'is_active' => 1
  ));
}

$user         = User::find($user_id);
$user_acc_type = $user->user_type;

$type = $user_acc_type;
if ($user_acc_type == 'super_admin') {
  $type = 'master_admin';
}

FlashMessage::set('Permission Update Successfully', 'success');
redirect('/index.php?view=master_users&type=' . $type);
