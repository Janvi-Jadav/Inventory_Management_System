<?php

require "../bootstrap.php";

use Carbon\Carbon;

$crud = get_form_value('crud');
$user_id = getSessionUserID();
$shop_id = getSessionUserID();

if ($crud == 'multi_image_upload') {
  if (isset($_FILES['files']['name']) && $_FILES['files']['name'][0] != '') {
    foreach ($_FILES["files"]["tmp_name"] as $key => $tmp_name) {
      $file_name = $_FILES["files"]["name"][$key];
      $ext = pathinfo($file_name, PATHINFO_EXTENSION);
      $result = uniqid();
      $file_name = $result . "." . $ext;
      $file_tmp = $_FILES["files"]["tmp_name"][$key];

      $target_dir = $doc_rt_url . "uploads/";
      $target_file = $target_dir . basename($file_name);
      move_uploaded_file($file_tmp, $target_file);

      $mimg = new MultiImage;
      $mimg->name = $file_name;
      $mimg->save();
    }
    FlashMessage::set('Images Upload Successfully', 'success');
  } else {
    ErrorLogSystem::addError('Error While in Uploading',  ' Multi Image Upload');
    FlashMessage::set('Error While in Uploading', 'error');
  }
  redirect('/index.php?view=multi_image');
}

if ($crud == 'new_eod_open') {
  $name = get_form_value('name');
  $shop_id = getSessionUserID();
  $user_id = getSessionLoginUserID();
  $currency_icon = getCurrency();
  $c_qty = get_form_value('c_qty');

  $eod = (new SpEod($shop_id))::getEOD();
  $eod_id = $eod['data']->id;

  if ($eod_id != '') {
    $eod = (new SpEod($shop_id))->find($eod_id);

    $open = 0;
    foreach ($c_qty as $k => $v) {
      $qty = $v;
      $ddt = explode('_', $k);
      $currency_id = $ddt[0];
      $currency_num = $ddt[1];

      $amnt = ($qty * $currency_num);
      $open = ($open + $amnt);
      //dd($ddt);
      //echo $k .'___'.$v;

      $insert = (new SpEodHistory($shop_id));
      $insert->eod_id = $eod_id;
      $insert->shop_id = $shop_id;
      $insert->user_id = $user_id;
      $insert->type = 'open';
      $insert->currency_type = $currency_icon;
      $insert->currency_id = $currency_id;
      $insert->qty = $qty;
      $insert->amount = $amnt;
      $insert->save();
    }
    $eod->open = $open;
    $eod->is_open = 0;
    $eod->save();

    FlashMessage::set('EOD Open Successfully', 'success');
    redirect('/index.php?view=pos');
  } else {
    FlashMessage::set('somthing wrong...!', 'error');
    redirect('/index.php?view=eod&action=start_day');
  }
}

if ($crud == 'new_eod_close') {
  $w_limit = 0;
  $name = get_form_value('name');
  $shop_id = getSessionUserID();
  $user_id = getSessionLoginUserID();
  $currency_icon = getCurrency();
  $c_qty = get_form_value('c_qty');
  $closing_bal = get_form_value('closing_bal');
  $adjust_amt = get_form_value('adjust_amt');
  $shop_product_stock = get_form_value('phone_stock');

  $eod = (new SpEod($shop_id))::getEOD();
  $eod_id = $eod['data']->id;

  if ($eod_id != '') {
    $eod = (new SpEod($shop_id))->find($eod_id);
    $is_metch = (new SpEod($shop_id))::checkEodendMetch($eod_id, $c_qty, $closing_bal, $shop_id);
    if ($is_metch == 1) {

      $close = 0;
      foreach ($c_qty as $k => $v) {
        $qty = $v;
        $ddt = explode('_', $k);
        $currency_id = $ddt[0];
        $currency_num = $ddt[1];

        $currency_num = (float) $currency_num;
        $qty = (int) $qty;

        $amnt = ($qty * $currency_num);
        $close = ($close + $amnt);

        $insert = (new SpEodHistory($shop_id));
        $insert->eod_id = $eod_id;
        $insert->shop_id = $shop_id;
        $insert->user_id = $user_id;
        $insert->type = 'close';
        $insert->currency_type = $currency_icon;
        $insert->currency_id = $currency_id;
        $insert->qty = $qty;
        $insert->amount = $amnt;
        $insert->save();
      }

      $eod->close = $close;
      $eod->shop_product_stock = $shop_product_stock;
      $eod->is_close = 0;
      $eod->is_active = 0;
      $eod->is_match = 1;
      $eod->save();

      $w_limit = User::getWalletAmount($shop_id, $type = 'wallet_limit');
      if ($w_limit > 0) {
        if ($closing_bal <= 0) {
          User::AddUpdateWalletAmount($adjust_amt, $type = 'add', $shop_id);
          (new SpWalletHistory($shop_id))::AddWalletHistory($shop_id, $type = 'eod_close', $adjust_amt, 'add', $msg = "eod close adjust amount", null);
        } else {
          User::AddUpdateWalletAmount($closing_bal, $type = 'add', $shop_id);
          (new SpWalletHistory($shop_id))::AddWalletHistory($shop_id, $type = 'eod_close', $closing_bal, 'add', $msg = "eod close adjust amount", null);
        }
      }


      FlashMessage::set('EOD Close Successfully', 'success');
      redirect('/index.php?view=pos');
    } else {
      FlashMessage::set('EOD Close not match', 'error');
      redirect('/index.php?view=eod&action=end_day');
    }
  } else {
    FlashMessage::set('somthing wrong...!', 'error');
    redirect('/index.php?view=eod&action=end_day');
  }
}

if ($crud == 'new_bill_currency_add') {
  $c_qty = get_form_value('c_qty');
  $bill_id = get_form_value('bill_id');
  $currency_icon = getCurrency();

  foreach ($c_qty as $k => $v) {
    $qty = $v;
    if ($v > 0) {
      $ddt = explode('_', $k);
      $currency_id = $ddt[0];
      $currency_num = $ddt[1];

      $currency_num = (float) $currency_num;
      $qty = (int) $qty;

      $amnt = ($qty * $currency_num);
      $insert = (new SpPosBillCurrency($shop_id));
      $insert->bill_id = $bill_id;
      $insert->currency_type = $currency_icon;
      $insert->currency_id = $currency_id;
      $insert->qty = $qty;
      $insert->shop_id = $shop_id;
      $insert->amount = $amnt;
      $insert->save();
    }
  }
  FlashMessage::set('Bill Add Successfully', 'success');
  redirect('/index.php?view=pos');
}

if ($crud == 'update_shop_product_price') {
  $shop_id = getSessionUserID();
  $id = get_form_value('id');
  $product_id = get_form_value('product_id');
  $unit_price = get_form_value('unit_price');
  $minimum_qty = get_form_value('minimum_qty');
  $old_price = 0;

  $shop_cr = (new SpCurrentStock($shop_id))->where(array('shop_id' => $shop_id, 'pdr_id' => $product_id))->latest()->first();


  if ($shop_cr != null) {
    $shop_cr->min_qty = $minimum_qty;
    $shop_cr->save();
  }
  SpPosBill::clearBillSession();
  FlashMessage::set('Product Price Update Successfully', 'success');
  redirect('/index.php?view=shop_product_price');
}

//for discount
if ($crud == 'add_discount') {
  $user_id = null;
  if (getSessionUserType() == 'shop') {
    $user_id = getSessionUserID();
  }
  $group_id = get_form_value('group_id');
  $qty = get_form_value('qty');
  $price = get_form_value('price');
  $offer = get_form_value('offer');
  $voucher = get_form_value('voucher');
  $voucher_price = get_form_value('voucher_price');

  $dis = Discount::where(array('group_id' => $group_id, 'qty' => $qty, 'price' => $price, 'user_id' => $user_id))->first();
  $check_voucher = null;
  if ($voucher != null) {
    $check_voucher = Discount::CheckvoucherExists($voucher);
  }

  $is_check_count = Discount::where(array('group_id' => $group_id, 'user_id' => $user_id, 'is_check' => 1))->count();
  if ($dis == NULL && $check_voucher == NULL) {
    $discount = new Discount;
    $discount->group_id = $group_id;
    $discount->user_id = $user_id;
    $discount->qty = $qty;
    $discount->price = $price;
    $discount->offer = $offer;
    if ($is_check_count < 3) {
      $discount->is_check = 1;
    }
    if ($voucher != null && $voucher_price != null) {
      $discount->voucher = $voucher;
      $discount->voucher_price = $voucher_price;
      $discount->voucher_active = 1;
    }
    $discount->save();

    SpPosBill::clearBillSession();
    FlashMessage::set('Discount Add Successfully', 'success');
  } elseif ($dis != null) {
    FlashMessage::set('Discount already exist', 'error');
  } else {
    FlashMessage::set('Voucher already exist', 'error');
  }
  redirect('/index.php?view=discount');
  //die;
}

if ($crud == 'update_discount') {
  $user_id = null;
  if (getSessionUserType() == 'shop') {
    $user_id = getSessionUserID();
  }
  $id = get_form_value('id');
  $group_id = get_form_value('group_id');
  $qty = get_form_value('qty');
  $price = get_form_value('price');
  $offer = get_form_value('offer');
  $voucher = get_form_value('voucher');
  $voucher_price = get_form_value('voucher_price');

  $dis = Discount::where(array('qty' => $qty, 'price' => $price, 'user_id' => $user_id))->where('id', '<>', $id)->first();
  $check_voucher = null;
  if ($voucher != null) {
    $check_voucher = Discount::CheckvoucherExists($voucher, $id);
  }

  if ($dis == NULL && $check_voucher == NULL) {

    $discount = Discount::find($id);
    if ($discount->user_id !=  $user_id) {
      FlashMessage::set('not allowed', 'error');
    } else {
      //$discount->group_id = $group_id;
      $discount->qty = $qty;
      $discount->price = $price;
      $discount->offer = $offer;
      $discount->voucher = $voucher;
      $discount->voucher_price = $voucher_price;
      if ($voucher == null && $voucher_price == null) {
        $discount->voucher_active = 0;
      }
      $discount->save();

      SpPosBill::clearBillSession();
      FlashMessage::set('Discount Update Successfully', 'success');
    }
  } elseif ($dis != null) {
    FlashMessage::set('Discount already exist', 'error');
  } else {
    FlashMessage::set('Voucher already exist', 'error');
  }
  redirect('/index.php?view=discount');
}
