<?php

require "../bootstrap.php";

use Carbon\Carbon;

$crud = get_form_value('crud');
if ($crud == 'add_party') {
  $cmp_name = get_form_value('cmp_name');
  $cmp_person_name = get_form_value('cmp_person_name');
  $gst_no = get_form_value('gst_no');
  $mo_no = get_form_value('mo_no');
  $address = get_form_value('address');
  $city = get_form_value('city');
  $state = get_form_value('state');
  $country = get_form_value('country');
  $email = get_form_value('email');


  $chk = Party::where('cmp_name', $cmp_name)->first();
  if ($chk == null) {

    $party = new Party();
    $party->cmp_name = $cmp_name;
    $party->cmp_person_name = $cmp_person_name;
    $party->mobile = $mo_no;
    $party->gst_no = $gst_no;
    $party->address = $address;
    $party->city = $city;
    $party->state = $state;
    $party->country = $country;
    $party->email = $email;
    $party->save();

    FlashMessage::set('Party Add Successfully', 'success');
    redirect('/index.php?view=party');
  } else {
    FlashMessage::set('Party Already Exist', 'error');
    redirect('/index.php?view=party');
  }
}
