<?php

require "../bootstrap.php";

use Carbon\Carbon;

$user_id = getSessionLoginUserID();

$crud = get_form_value('crud');
if ($crud == 'add_purchase') {

  $party_id = get_form_value('party_id');

  $p_notes = get_form_value('s_notes');
  $s_inv_no = get_form_value('s_inv_no');
  $s_date = get_form_value('s_date');

  $salesDate = Carbon::createFromFormat('d/m/Y', $s_date);


  $invoice_no = Sales::getInvoiceNo();
  $total_qty = 0;

  if ($_SESSION['sales_bill'] == []) {
    FlashMessage::set('Please Add Item', 'error');
    redirect('/index.php?view=purchase');
  }


  if (isset($_SESSION['sales_bill'])) {
    $sales = new Sales();
    $sales->party_id = $party_id;
    $sales->remark = $s_notes;
    $sales->user_id = $user_id;
    $sales->inv_no = $invoice_no;
    $sales->total_qty = 0;
    $sales->datetime = Carbon::now();
    $sales->sales_inv_no = $s_inv_no;
    $sales->sales_date = $salesDate;
    $sales->save();

    foreach ($_SESSION['sales_bill'] as $key => $p) {
      $pdr_id = $p['pdr_id'];
      $qty = $p['qty'];
      $total_qty = $total_qty + $qty;

      $sales_item = new SalesItem();
      $sales_item->sales_id = $sales->id;
      $sales_item->item_id = $pdr_id;
      $sales_item->qty = $qty;
      $sales_item->datetime = Carbon::now();
      $sales_item->save();
      Product::updateStock($pdr_id, $sales->id, $qty, 'minus', 'Sales');
    }
    $sales->total_qty = $total_qty;
    $sales->save();
    unset($_SESSION['sales_bill']);
    FlashMessage::set('Sales Bill Create Sucessfully', 'success');
    redirect('/index.php?view=sales');
  } else {
    FlashMessage::set('Session Destroy', 'error');
    redirect('/index.php?view=sales');
  }
}
