<?php

require "../bootstrap.php";
use Carbon\Carbon;

$user_id = get_form_value('user_id');
$first_name = get_form_value('first_name');
$last_name = get_form_value('last_name');
$email = get_form_value('email');
$contact_no = get_form_value('contact_no');
$permission = get_form_value('permission');
$accounts = get_form_value('account');

//include('validation/user_update_validate.php');
if($email == null){
	FlashMessage::set('Enter is already exits','error');
  redirect($_SERVER['HTTP_REFERER'],'full');
}else{
	$find_user = User::where('email',$email)->where('user_id', '<>', $user_id)->first();
  if($find_user != NULL){
    FlashMessage::set($email.' is already exits','error');
    redirect($_SERVER['HTTP_REFERER'],'full');
  }else{
	$user = User::find($user_id);
	$user->first_name = $first_name;
	$user->last_name = $last_name;
	$user->email = $email;
	$user->contact_no = $contact_no;
	$user->save();

	Permission::where(array('user_id'=>$user_id))->update(['is_active' => 0]);
	foreach($permission as $p){
		Permission::updateOrCreate(array(
			'user_id'=>$user_id,
			'permission'=>$p
		),array(
			'user_id'=>$user_id,
			'permission'=>$p,
			'is_active'=>1
		));
	}
}
}

FlashMessage::set('User Update Successfully','success');
redirect('/index.php?view=users')

?>