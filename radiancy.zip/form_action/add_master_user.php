<?php

require "../bootstrap.php";

use Carbon\Carbon;

$first_name = get_form_value('first_name');
$last_name = get_form_value('last_name');
$email = get_form_value('email');
$password = get_form_value('password');
$contact_no = get_form_value('contact_no');
$module = get_form_value('module');
$expiry_date = get_form_value('expiry_date');
$permission = get_form_value('permission');

$title = get_form_value('title');
$vat_no = get_form_value('vat_no');
$address = get_form_value('address');
$close_time = get_form_value('close_time');
$map_link = get_form_value('map_link');

if ($email == null) {
  FlashMessage::set('Enter is already exits', 'error');
  redirect($_SERVER['HTTP_REFERER'], 'full');
} else {
  $find_user = User::where('email', $email)->first();
  if ($find_user != NULL) {
    FlashMessage::set($email . ' is already exits', 'error');
    redirect($_SERVER['HTTP_REFERER'], 'full');
  } else {
    $user = new User;
    $user->first_name = $first_name;
    $user->last_name = $last_name;
    $user->email = $email;
    $user->password = md5($password);
    $user->contact_no = $contact_no;
    $user->user_type = 'shop';
    $user->code = getRandomNo(6, 'user');

    $user->invoice_ttl = $title;
    $user->invoice_vat = $vat_no;
    $user->invoice_address = $address;

    $user->close_time = Carbon::parse($close_time)->format('H:i:s');
    $user->map_link = $map_link;

    $user->save();


    $shop_id = $user->user_id;
    User::createNewSpCurrentStockTable($shop_id);
    User::createNewSpBillTable($shop_id);
    User::createNewSpBillItemTable($shop_id);
    User::createNewSpSkipItemTable($shop_id);
    User::createNewSpErrorLogTable($shop_id);
    User::createNewSpQuickUpdateHistoryTable($shop_id);
    User::createNewSpTodayOrderTable($shop_id);





    foreach ($permission as $p) {
      $permission = new Permission;
      $permission->user_id = $user->user_id;
      $permission->permission = $p;
      $permission->save();
    }
  }
}

FlashMessage::set('User Add Successfully', 'success');
redirect('/index.php?view=master_users');
