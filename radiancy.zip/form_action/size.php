<?php

require "../bootstrap.php";

use Carbon\Carbon;

$crud = get_form_value('crud');
if ($crud == 'add_size') {
  $name = get_form_value('name');

  $chk = Size::where('name', $name)->first();
  if ($chk != null) {
    FlashMessage::set('Size Already Exist', 'error');
    redirect('/index.php?view=size');
  } else {
    $size = new Size();
    $size->name = $name;
    $size->save();
    FlashMessage::set('Size Add Successfully', 'success');
    redirect('/index.php?view=size');
  }
}

if ($crud == 'update_size') {
  $name = get_form_value('name');
  $id = get_form_value('id');

  $chk = Size::where('name', $name)->first();
  if ($chk != null) {
    FlashMessage::set('Size Already Exist', 'error');
    redirect('/index.php?view=size');
  } else {
    $size = Size::find($id);
    $size->name = $name;
    $size->save();
    FlashMessage::set('Size Update Successfully', 'success');
    redirect('/index.php?view=size');
  }
}
