<?php

if(isset($email)){
	$find_user = User::where('email',$email)->where('user_id', '<>', $user_id)->first();
	if($find_user != NULL){

		FlashMessage::set($email.' is already exits','error');
		redirect($_SERVER['HTTP_REFERER'],'full');

	}

}

?>