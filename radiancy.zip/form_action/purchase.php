<?php

require "../bootstrap.php";

use Carbon\Carbon;

$user_id = getSessionLoginUserID();

$crud = get_form_value('crud');
if ($crud == 'add_purchase') {

  $party_id = get_form_value('party_id');
  $p_inv_no = get_form_value('p_inv_no');

  $p_notes = get_form_value('p_notes');
  $p_date = get_form_value('p_date');

  $invoice_no = Purchase::getInvoiceNo();
  $total_qty = 0;
  $purchaseDate = Carbon::createFromFormat('d/m/Y', $p_date);

  if ($_SESSION['purchase_bill'] == []) {
    FlashMessage::set('Please Add Item', 'error');
    redirect('/index.php?view=purchase');
  }


  if (isset($_SESSION['purchase_bill'])) {
    $purchase = new Purchase();
    $purchase->party_id = $party_id;
    $purchase->purchase_inv_no = $p_inv_no;
    $purchase->remark = $p_notes;
    $purchase->user_id = $user_id;
    $purchase->inv_no = $invoice_no;
    $purchase->total_qty = 0;
    $purchase->datetime = Carbon::now();
    $purchase->purchase_date = $purchaseDate;
    $purchase->save();

    foreach ($_SESSION['purchase_bill'] as $key => $p) {
      $pdr_id = $p['pdr_id'];
      $qty = $p['qty'];
      $total_qty = $total_qty + $qty;

      $purchase_item = new PurchaseItem();
      $purchase_item->purchase_id = $purchase->id;
      $purchase_item->item_id = $pdr_id;
      $purchase_item->qty = $qty;
      $purchase_item->datetime = Carbon::now();
      $purchase_item->save();

      Product::updateStock($pdr_id, $purchase->id, $qty, 'add', 'Purchase');
    }
    $purchase->total_qty = $total_qty;
    $purchase->save();
    unset($_SESSION['purchase_bill']);
    FlashMessage::set('Purchase Bill Create Sucessfully', 'success');
    redirect('/index.php?view=purchase');
  } else {
    FlashMessage::set('Session Destroy', 'error');
    redirect('/index.php?view=purchase');
  }
}
