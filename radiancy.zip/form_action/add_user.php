<?php

require "../bootstrap.php";

use Carbon\Carbon;

$first_name = get_form_value('first_name');
$last_name = get_form_value('last_name');
$email = get_form_value('email');
$password = get_form_value('password');
$contact_no = get_form_value('contact_no');
$permission = get_form_value('permission');
if ($email == null) {
  FlashMessage::set('Enter is already exits', 'error');
  redirect($_SERVER['HTTP_REFERER'], 'full');
} else {
  $find_user = User::where('email', $email)->first();
  if ($find_user != NULL) {
    FlashMessage::set($email . ' is already exits', 'error');
    redirect($_SERVER['HTTP_REFERER'], 'full');
  } else {
    $user = new User;
    $user->first_name = $first_name;
    $user->last_name = $last_name;
    $user->email = $email;
    $user->password = md5($password);
    $user->contact_no = $contact_no;
    $user->user_type = 'user';
    $user->parent_admin_user_id = $_SESSION['user_data']['user_id'];
    $user->save();

    foreach ($permission as $p) {
      $permission = new Permission;
      $permission->user_id = $user->user_id;
      $permission->permission = $p;
      $permission->save();
    }
  }
}

FlashMessage::set('User Add Successfully', 'success');
redirect('/index.php?view=users');
