<?php

require "../bootstrap.php";

use Carbon\Carbon;

$crud = get_form_value('crud');
if ($crud == 'add_product') {
  $name = get_form_value('name');
  $brand = get_form_value('brand');
  $color = get_form_value('color');
  $part_no = get_form_value('part_no');
  $size = get_form_value('size');
  $opening_stock = get_form_value('opening_stock');

  $productName = $name;
  $brandName = '';
  $colorName = '';
  $partNo = '';
  $sizeName = '';
  $openingStock = 0;
  $currentStock = 0;

  if ($brand != null || $brand != '') {
    $brandName = ' [' . $brand . ']';
  }
  if ($color != null || $color != '') {
    $colorName = ' (' . $color . ')';
  }
  if ($part_no != null || $part_no != '') {
    $partNo = ' (' . $part_no . ')';
  }
  if ($size != null || $size != '') {
    $sizeName = ' ' . $size;
  }
  if ($opening_stock != null || $opening_stock != '') {
    $openingStock = $opening_stock;
    $currentStock = $opening_stock;
  }

  $finalName = $productName . $brandName . $colorName . $partNo . $sizeName;
  $chk = Product::where('name', $finalName)->first();
  if ($chk != null) {
    FlashMessage::set('Product Already Exist', 'error');
    redirect('/index.php?view=product');
  } else {
    $product = new Product();
    $product->name = $finalName;
    $product->brand = $brand;
    $product->color = $color;
    $product->part_no = $part_no;
    $product->size = $size;
    $product->opening_stock = $openingStock;
    // $product->curr_stock = $currentStock;
    $product->save();

    Product::updateStock($product->id, null, $openingStock, 'opening_stock', 'New Product Add');

    FlashMessage::set('Product Add Successfully', 'success');
    redirect('/index.php?view=product');
  }
}
