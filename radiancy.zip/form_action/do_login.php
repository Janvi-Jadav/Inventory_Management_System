<?php

require "../bootstrap.php";

$email = get_form_value('email');
$password = get_form_value('password');

$User = new User;
$user_data = $User->where(array('email' => $email, 'password' => md5($password), 'is_active' => 1))->first();

if ($user_data == NULL) {

	$user_data = $User->where(array('email' => $email))->first();
	if ($user_data == NULL) {
		FlashMessage::set($email . ' is not registered.', 'error');
	} else if ($user_data->is_active == 0) {
		FlashMessage::set($email . ' is blocked by admin.', 'warning');
	} else {
		FlashMessage::set('Password is invalid, please check that.', 'warning');
	}

	redirect('/login.php');
} else {
	$rtn = '/index.php';
	// do login
	$user_data = $user_data->toArray();
	$_SESSION['login_status'] = '1';
	$_SESSION['user_data'] = $user_data;
	if ($user_data['user_type'] == 'user') {
		if ($user_data['parent_admin_user_id'] != null && $user_data['parent_admin_user_id'] != '') {
			$_SESSION['shop_user_id'] = $user_data['parent_admin_user_id'];
			$rtn = '/index.php';
		} else {
			FlashMessage::set($email . ' has no shop.', 'error');
			//redirect('/login.php');
			$rtn = '/login.php';
		}
	} else {
		$_SESSION['shop_user_id'] = $user_data['user_id'];
		$rtn = '/index.php';
	}

	// set local data
	/* $user_type = getSessionUserType();
		if($user_type == 'user' || $user_type == 'admin'){
			$login_time = GetLoginTimeset();
			if($login_time != 0){

			}
		} */


	FlashMessage::set('Welcome to ' . $user_data['first_name'] . ' ' . $user_data['last_name'], 'success');
	$id = $user_data['user_id'];
	$type = "login";
	$date = Carbon\Carbon::now();
	// LoginLogoutHistory::add_history($id,'login',$date);
	redirect($rtn);
}
