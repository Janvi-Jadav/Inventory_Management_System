<?php

require "../bootstrap.php";

use Carbon\Carbon;

$crud = get_form_value('crud');
if ($crud == 'add_hsn') {
  $hsn_name = get_form_value('hsn_name');
  $hsn_code = get_form_value('hsn_code');

  $chk = HsnCode::where('code_name', $hsn_name)->orwhere('code', $hsn_code)->first();
  if ($chk != null) {
    FlashMessage::set('HSN Code Already Exist', 'error');
    redirect('/index.php?view=hsn_code');
  } else {
    $new = new HsnCode();
    $new->code_name = $hsn_name;
    $new->code = $hsn_code;
    $new->save();
    FlashMessage::set('HSN Code Add Successfully', 'success');
    redirect('/index.php?view=hsn_code');
  }
}

if ($crud == 'update_hsn') {
  $hsn_name = get_form_value('hsn_name');
  $hsn_code = get_form_value('hsn_code');
  $hsn_id = get_form_value('id');

  $chk = HsnCode::where('code_name', $hsn_name)->orwhere('code', $hsn_code)->where('id', '<>', $hsn_id)->first();
  if ($chk != null) {
    FlashMessage::set('HSN Code Already Exist', 'error');
    redirect('/index.php?view=hsn_code');
  } else {
    $new = HsnCode::find($hsn_id);
    $new->code_name = $hsn_name;
    $new->code = $hsn_code;
    $new->save();
    FlashMessage::set('HSN Code Update Successfully', 'success');
    redirect('/index.php?view=hsn_code');
  }
}
