<?php
$db_mode = true;
require "../bootstrap.php";

use Illuminate\Database\Capsule\Manager as Capsule;

Capsule::schema()->create('party', function ($table) {
    $table->increments('id');
    $table->string('cmp_name')->nullable()->default(NULL);
    $table->string('cmp_person_name')->nullable()->default(NULL);
    $table->string('mobile')->nullable()->default(NULL);
    $table->string('email')->nullable()->default(NULL);
    $table->string('gst_no')->nullable()->default(NULL);
    $table->string('address')->nullable()->default(NULL);
    $table->string('city')->nullable()->default(NULL);
    $table->string('state')->nullable()->default(NULL);
    $table->string('country')->nullable()->default(NULL);
    $table->integer('is_active')->default(1);
    $table->timestamps();
});
