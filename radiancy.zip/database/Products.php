<?php
$db_mode = true;
require "../bootstrap.php";

use Illuminate\Database\Capsule\Manager as Capsule;

Capsule::schema()->create('products', function ($table) {
    $table->increments('id');
    $table->string('name')->nullable()->default(NULL);
    $table->string('brand')->nullable()->default(NULL);
    $table->string('color')->nullable()->default(NULL);
    $table->string('part_no')->nullable()->default(NULL);
    $table->string('size')->nullable()->default(NULL);
    $table->integer('opening_stock')->default(0);
    $table->integer('curr_stock')->default(0);
    $table->integer('is_active')->default(1);
    $table->timestamps();
});
