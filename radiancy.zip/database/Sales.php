<?php
$db_mode = true;
require "../bootstrap.php";

use Illuminate\Database\Capsule\Manager as Capsule;

Capsule::schema()->create('sales', function ($table) {
    $table->increments('id');
    $table->integer('party_id');
    $table->integer('user_id');
    $table->string('inv_no');
    $table->string('remark')->default('')->nullable();
    $table->string('sales_inv_no');
    $table->datetime('sales_date');
    $table->integer('total_qty');
    $table->datetime('datetime');
    $table->integer('is_active')->default(1);
    $table->timestamps();
});
