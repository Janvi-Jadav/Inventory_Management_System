<?php
$db_mode = true;
require "../bootstrap.php";

use Illuminate\Database\Capsule\Manager as Capsule;

Capsule::schema()->create('purchase', function ($table) {
    $table->increments('id');
    $table->integer('party_id');
    $table->integer('user_id');
    $table->string('inv_no');
    $table->string('remark')->default('')->nullable();
    $table->string('purchase_inv_no');
    $table->integer('total_qty');
    $table->datetime('datetime');
    $table->datetime('purchase_date');
    $table->integer('is_active')->default(1);
    $table->timestamps();
});
