<?php
$db_mode = true;
require "../bootstrap.php";

use Illuminate\Database\Capsule\Manager as Capsule;

Capsule::schema()->create('purchase_item', function ($table) {
    $table->increments('id');
    $table->integer('purchase_id');
    $table->integer('item_id');
    $table->integer('qty');
    $table->datetime('datetime');
    $table->integer('is_active')->default(1);
    $table->timestamps();
});
