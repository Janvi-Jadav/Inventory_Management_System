<?php
$db_mode = true;
require "../bootstrap.php";

use Illuminate\Database\Capsule\Manager as Capsule;

Capsule::schema()->create('users', function ($table) {
    $table->increments('user_id');
    $table->string('first_name');
    $table->string('last_name')->nullable()->default(NULL);
    $table->string('email')->unique();
    $table->string('password');
    $table->string('contact_no')->nullable()->default(NULL);
    $table->string('user_type');
    $table->string('prefix')->nullable()->default(NULL);
    $table->integer('parent_admin_user_id')->nullable();
    $table->integer('is_active')->default(1);
    $table->string('last_login')->nullable()->default(NULL);
    $table->string('gst_no')->nullable()->default(NULL);
    $table->string('address')->nullable()->default(NULL);
    $table->dateTime('last_fetch')->nullable()->default(null);
    $table->integer('gst_rate')->nullable()->default(18);
    $table->timestamps();
});

Capsule::schema()->table('users', function ($table) {});
