<?php
$db_mode = true;
require "../bootstrap.php";

use Illuminate\Database\Capsule\Manager as Capsule;

Capsule::schema()->create('product_stock_history', function ($table) {
    $table->increments('id');
    $table->integer('pdr_id')->default(0);
    $table->integer('inv_id')->default(null)->nullable();
    $table->integer('qty')->default(0);
    $table->integer('old_curr_stock')->default(0);
    $table->integer('new_curr_stock')->default(0);
    $table->integer('user_id')->default(0);
    $table->string('type')->nullable()->default(NULL);
    $table->integer('is_active')->default(1);
    $table->timestamps();
});
