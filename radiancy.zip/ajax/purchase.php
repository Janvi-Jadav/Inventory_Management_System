<?php
require "../bootstrap.php";

use Carbon\Carbon;

$method = get_form_value('method');

if ($method == 'addPurchaseItem') {
  $out['type'] = 'error';
  $pdr_id = get_form_value('product_id');
  $qty = get_form_value('qty');


  if ($pdr_id == null || $pdr_id == '') {
    $out['msg'] = 'Please Select Product';
  } else if ($qty <= 0) {
    $out['msg'] = 'Invalid Qty';
  } else {

    if (!isset($_SESSION['purchase_bill'])) {
      $_SESSION['purchase_bill'] = [];
    }

    if (searchArray($pdr_id, $_SESSION['purchase_bill'], 'pdr_id') == 'add') {
      $tmp = [];
      $tmp['pdr_id'] = $pdr_id;
      $tmp['qty'] = $qty;
      array_push($_SESSION['purchase_bill'], $tmp);
      $out['type'] = 'success';
      $out['msg'] = 'Product Add Successfully';
    } else {
      $out['type'] = 'error';
      $out['msg'] = 'Product Already Exist';
    }
  }
  echo json_encode($out);
  die;
}

if ($method == 'displaySession') {
  $out['type'] = 'success';
  $out['msg'] = 'Session Not Create...';

  if (!isset($_SESSION['purchase_bill'])) {
    $_SESSION['purchase_bill'] = [];
  }

  ob_start();
  $total_qty = 0;

?>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Product Name</th>
        <th scope="col">Qty</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
      if (isset($_SESSION['purchase_bill']) && $_SESSION['purchase_bill'] != '') {
        foreach ($_SESSION['purchase_bill'] as $key => $p) {

          $pdr_id = $p['pdr_id'];
          $qty = $p['qty'];
          $total_qty = $total_qty + $qty;

          $name = Product::find($pdr_id)->name;

      ?>
          <tr>
            <td data-label="#" class="text-center"><?php echo $key + 1; ?></td>
            <td data-label="Product Name" class="text-left">
              <?php echo $name; ?><br>
            </td>
            <td data-label="Qty"><input value="<?php echo $qty; ?>" data-key="<?php echo $key; ?>" type="number" class="form-control qty no-paddings min_width change_qty" readonly>
            <td data-label="Action" class="text-center">
              <a class="fa fa-fw fa-trash-o text-red" href="javascript:;" title="Delete Item?" onclick="removeSession(<?php echo $key; ?>);"></a>
            </td>
          </tr>
        <?php

        } ?>
      <?php } else { ?>
        <tr>
          <td class="text-center" colspan="3">No Record Found!</td>
        </tr>
      <?php } ?>

    </tbody>
  </table>
<?php
  $string = ob_get_contents();
  ob_clean();

  $out['html'] = $string;
  $out['total_qty'] = $total_qty;

  echo json_encode($out);
  die;
}

if ($method == 'removeItem') {
  $key = get_form_value('key');
  $final_key = $key;
  unset($_SESSION['purchase_bill'][$final_key]);
  $out['type'] = 'success';
  $out['msg'] = 'Item Remove Successfully';
  echo json_encode($out);
  die;
}

if ($method == 'displayBill') {
  $out['type'] = 'success';

  $id = get_form_value('id');

  $purchaseBill = Purchase::find($id);
  $partyName = $purchaseBill->party->cmp_name;
  $inv_no = $purchaseBill->inv_no;
  $inv_date = Carbon::parse($purchaseBill->datetime)->format('d/m/Y');

  ob_start();
  $total_qty = 0;

?>
  <table id="example1" class="table table-bordered">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Product Name</th>
        <th scope="col">Qty</th>
      </tr>
    </thead>
    <tbody>
      <?php

      foreach ($purchaseBill->purchase_items as $key => $p) {

        $pdr_id = $p->item_id;
        $qty = $p->qty;
        $total_qty = $total_qty + $qty;

        $name = Product::find($pdr_id)->name;

      ?>
        <tr>
          <td data-label="#" class="text-center"><?php echo $key + 1; ?></td>
          <td data-label="Product Name" class="text-left">
            <?php echo $name; ?><br>
          </td>
          <td data-label="Qty"><?php echo $qty; ?>
        </tr>
      <?php

      } ?>

      <tr>
        <th colspan="2" data-label="#" class="text-center">Total Qty</th>
        <th data-label="Total Qty" class="text-right">
          <?php echo $total_qty; ?>
        </th>
      </tr>


    </tbody>
  </table>
<?php
  $string = ob_get_contents();
  ob_clean();

  $out['inv_no'] = 'Purchase Invoice : ' . $inv_no;
  $out['cmp_name'] = 'Company Name : ' . $partyName;
  $out['inv_date'] = 'Date : ' . $inv_date;
  $out['html'] = $string;
  $out['total_qty'] = $total_qty;

  echo json_encode($out);
  die;
}
