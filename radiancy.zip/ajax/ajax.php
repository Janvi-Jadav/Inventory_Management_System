<?php

require "../bootstrap.php";

$action = get_form_value('action');
$out = array();

if ($action != NULL) {

	include($action . '.php');
} else {
	$out['type'] = 'error';
}
echo json_encode($out);
