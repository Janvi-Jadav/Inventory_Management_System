<?php
require "../bootstrap.php";

use Carbon\Carbon;

$method = get_form_value('method');

if ($method == 'toggleProduct') {
  $out['type'] = 'error';
  $id = get_form_value('id');
  $product = Product::find($id);
  // dd($product->is_active);
  if ($product != null) {
    if ($product->is_active == 1) {
      $product->is_active = 0;
    } else {
      $product->is_active = 1;
    }
    $product->save();
    $out['type'] = 'success';
  }
  echo json_encode($out);
  die;
}
