<?php

require "../bootstrap.php";

use Carbon\Carbon;

$method = get_form_value('method');

if ($method == 'productHistory') {
  $out['type'] = 'success';

  $id = get_form_value('id');

  $productHistory = ProductStockHistory::where('pdr_id', $id)->orderBy('id', 'DESC')->get();
  $product = Product::find($id);
  $productName = $product->name;
  $product_curr_stock = $product->curr_stock;

  ob_start();
  $total_qty = 0;

?>
  <table id="example1" class="table table-bordered">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Date</th>
        <th scope="col">Qty</th>
        <th scope="col">Type</th>
        <th scope="col">Old Stock</th>
        <th scope="col">New Stock</th>
      </tr>
    </thead>
    <tbody>
      <?php

      foreach ($productHistory as $key => $p) {

      ?>
        <tr>
          <td data-label="#" class="text-center"><?php echo $key + 1; ?></td>
          <td data-label="Date" class="text-left">
            <?php echo Carbon::parse($p->datetime)->format('d/m/Y'); ?><br>
          </td>
          <td data-label="Qty"><?php echo $p->qty; ?>
          <td data-label="Type"><?php echo $p->type; ?>
          <td data-label="Old Stock"><?php echo $p->old_curr_stock; ?>
          <td data-label="New Stock"><?php echo $p->new_curr_stock; ?>
        </tr>
      <?php

      } ?>

      <tr>
        <th colspan="4" data-label="#" class="text-center">Current Stock</th>
        <th colspan="2" data-label="Current Stock" class="text-right">
          <?php echo $product_curr_stock; ?>
        </th>
      </tr>


    </tbody>
  </table>
<?php
  $string = ob_get_contents();
  ob_clean();

  $out['productName'] = 'Stock of : ' . $productName;
  $out['html'] = $string;
  $out['product_curr_stock'] = 'Current Stock :' . $product_curr_stock;

  echo json_encode($out);
  die;
}
