<?php
require "../bootstrap.php";

$rtn = 0;
if (!(isset($_SESSION['login_status']) && $_SESSION['login_status'] != '')) {
  $rtn = 1;
}
$out['type']      = 'success';
$out['status']      = $rtn;
echo json_encode($out);
die;
