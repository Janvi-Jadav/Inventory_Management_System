<?php $shop_id     = (isset($_GET['shop_id']) && $_GET['shop_id'] != '') ? $_GET['shop_id'] : null;
$shopdt = User::find($shop_id);
?>
<div class="col-md-3">
  <div class="box box-solid">
    <div class="box-header with-border">
      <h3 class="box-title">WR <?php echo $shopdt->first_name; ?> Managment</h3>

      <div class="box-tools">
        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
        </button>
      </div>
    </div>

    <div class="box-body no-padding">
      <ul class="nav nav-pills nav-stacked">
        <li id="today_order_pda" class="side_nav"><a href="<?php echo $config['site_url'] ?>/index.php?view=shop_order_pda&action=list&shop_id=<?php echo $shop_id; ?>"><i class="fa fa-circle-o text-red"></i>Today Order By PDA</a></li>
      </ul>
    </div>

    <div class="box-body no-padding">
      <ul class="nav nav-pills nav-stacked">
        <li id="quick_order_pda" class="side_nav"><a href="<?php echo $config['site_url'] ?>/index.php?view=shop_order_pda&action=quick_order&shop_id=<?php echo $shop_id; ?>"><i class="fa fa-circle-o text-red"></i>Quick Order By PDA</a></li>
      </ul>
    </div>

    <div class="box-body no-padding">
      <ul class="nav nav-pills nav-stacked">
        <li id="shop_order_history" class="side_nav <?php echo $view_mode == 'shop_bills' ? 'active' : '' ?> <?php echo $view_mode == 'shop_bill_details' ? 'active' : '' ?>"><a href="<?php echo $config['site_url'] ?>/index.php?view=shop_stock_history&action=shop_bills&shop_id=<?php echo $shop_id; ?>"><i class="fa fa-circle-o text-red"></i>Shop Order History</a></li>
      </ul>
    </div>

    <div class="box-body no-padding">
      <ul class="nav nav-pills nav-stacked">
        <li id="shop_bill_request" class="side_nav <?php echo $view_mode == 'shop_bill_request' ? 'active' : '' ?>"><a href="<?php echo $config['site_url'] ?>/index.php?view=shop_stock_history&action=shop_bill_request&type=pendding_bill&shop_id=<?php echo $shop_id; ?>"><i class="fa fa-circle-o text-red"></i>Waiting for Acceptance</a></li>
      </ul>
    </div>

    <div class="box-body no-padding">
      <ul class="nav nav-pills nav-stacked">
        <li id="shop_bill_request" class="side_nav <?php echo $view_mode == 'quick_stock_update' ? 'active' : '' ?>"><a href="<?php echo $config['site_url'] ?>/index.php?view=shop_quick_stock_history&shop_id=<?php echo $shop_id; ?>"><i class="fa fa-circle-o text-red"></i>Quick Update History</a></li>
      </ul>
    </div>

  </div>

  <div class="box box-solid">
    <div class="box-header with-border">
      <h3 class="box-title"><?php echo $shopdt->first_name; ?> Reports</h3>

      <div class="box-tools">
        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
        </button>
      </div>
    </div>

    <div class="box-body no-padding">
      <ul class="nav nav-pills nav-stacked">
        <li id="today_order_pda" class="side_nav <?php echo $ui_mode == 'eod_report' ? 'active' : '' ?>"><a href="<?php echo $config['site_url'] ?>/index.php?view=eod_report&action=view&shop_id=<?php echo $shop_id; ?>"><i class="fa fa-circle-o text-red"></i>Eod Reports</a></li>
      </ul>
    </div>

    <div class="box-body no-padding">
      <ul class="nav nav-pills nav-stacked">
        <li id="today_order_pda" class="side_nav <?php echo $_GET['view'] == 'shop_report' ? 'active' : '' ?>"><a href="<?php echo $config['site_url'] ?>/index.php?view=shop_report&action=view&shop_id=<?php echo $shop_id; ?>"><i class="fa fa-circle-o text-red"></i>Shop Reports</a></li>
      </ul>
    </div>

    <div class="box-body no-padding">
      <ul class="nav nav-pills nav-stacked">
        <li id="today_order_pda" class="side_nav <?php echo $_GET['view'] == 'sales_graph' ? 'active' : '' ?>"><a href="<?php echo $config['site_url'] ?>/index.php?view=sales_graph&action=graph&shop_id=<?php echo $shop_id; ?>"><i class="fa fa-circle-o text-red"></i>Sales Graph</a></li>
      </ul>
    </div>

  </div>
</div>