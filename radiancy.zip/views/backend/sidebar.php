<?php
include_once('sidebar_menu/' . $user_type . '.php');

//dd($data['side_ui_menu']);
?>
<!-- sidebar menu: : style can be found  in sidebar.less -->
<ul class="sidebar-menu" data-widget="tree">
  <?php
  if (isset($data['side_ui_menu']) && count($data['side_ui_menu']) > 0 && $data['side_ui_menu'] != '') {
    foreach ($data['side_ui_menu'] as $menu) { ?>
      <?php if (isset($menu['sub_menu']) && $menu['sub_menu'] != '') {

      ?>
        <li class="treeview <?php if ($data['page'] == $menu['page']) {
                              echo "active";
                            } ?>">
          <a href="#"><i class="<?php echo $menu['icon']; ?>"></i> <span><?php echo $menu['text']; ?></span>
            <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
          </a>
          <ul class="treeview-menu">
            <?php foreach ($menu['sub_menu'] as $sub_menu) {

              if (isset($sub_menu['sub_menu_2']) && $sub_menu['sub_menu_2'] != '') {


            ?>
                <li class="treeview <?php echo ((isset($data['sub_page']) && ($data['sub_page'] == $sub_menu['page'])) ? 'active' : ''); ?> ">
                  <a href="#"><i class="fa fa-circle-o"></i> <?php echo $sub_menu['text']; ?>
                    <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                  </a>
                  <ul class="treeview-menu">
                    <?php foreach ($sub_menu['sub_menu_2'] as $sub_menu_2) {
                      echo '<li class="' . ((isset($sub_menu_2['page']) && isset($data['sub_page_2']) && ($sub_menu_2['page'] == $data['sub_page_2'])) ? 'active' : '') . '" ><a href="' . $sub_menu_2['route'] . '"><i class="fa fa-circle-o"></i> ' . $sub_menu_2['text'] . '</a></li>';
                    } ?>

                  </ul>
                </li>
              <?php
              } else { ?>
                <li <?php if (isset($data['sub_page']) && ($data['sub_page'] == $sub_menu['page'])) {
                      echo 'class="active"';
                    } ?>>
                  <a href="<?php echo $sub_menu['route']; ?>" class="<?php echo $sub_menu['class'] ?>" id="<?php echo $sub_menu['id'] ?>">
                    <i class="fa fa-circle-o"></i> <?php echo $sub_menu['text']; ?>
                  </a>
                </li>
              <?php } ?>
              <!-- <li <?php if (isset($data['sub_page']) && ($data['sub_page'] == $sub_menu['page'])) {
                          echo 'class="active"';
                        } ?>>
                <a href="<?php echo $sub_menu['route']; ?>" class="<?php echo $sub_menu['class'] ?>" id="<?php echo $sub_menu['id'] ?>">
                  <i class="fa fa-circle-o"></i> <?php echo $sub_menu['text']; ?>
                </a>
              </li> -->
            <?php } ?>

          </ul>
        </li>

      <?php } else { ?>

        <li <?php if ($data['page'] == $menu['page']) {
              echo 'class="active"';
            } ?>>
          <a href="<?php echo $menu['route'] ?>" class="<?php echo $menu['class'] ?>" id="<?php echo $menu['id'] ?>">
            <i class="<?php echo $menu['icon'] ?>"></i> <span><?php echo $menu['text'] ?></span>
          </a>
        </li>

  <?php }
    }
  } ?>


  <li>
    <a href="<?php echo $config['site_url']; ?>/logout.php" onclick="return confirm('Are you sure to logout?')">
      <i class="fa fa-sign-out"></i> <span>Log Out</span>
    </a>
  </li>

</ul>