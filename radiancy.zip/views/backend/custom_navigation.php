<?php $usertype = getSessionUserType(); ?>
<div class="containers">
  <div class="navbar-header">
    <?php if ($simple_display_mode == 1) { ?>
      <a class="navbar-brand" href="<?php echo $config['site_url']; ?>"> Order Management</a>
    <?php } ?>
    <button class="navbar-toggle collapsed" data-target="#navbar-collapse" data-toggle="collapse" type="button">
      <i class="fa fa-bars"></i>
    </button>
  </div>
  <div class="navbar-custom-menu">
    <ul class="nav navbar-nav">
      <li class="dropdown messages-menu">
        <a href="<?php echo $config['site_url']; ?>/index.php"><i class="fa fa-dashboard"></i> Dashboard</a>
      </li>
      <li class="dropdown messages-menu">
        <a href="logout.php"><i class="fa fa-sign-out"></i> Log Out</a>
      </li>
    </ul>
  </div>
</div>