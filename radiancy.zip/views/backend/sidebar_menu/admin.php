<?php
$shop_id = getSessionUserID();


$side_ui_menu = new SidebarMenu;

$side_ui_menu->add(array(
  'type'  => 'menu',
  'icon'  => 'fa fa-dashboard',
  'text'  => 'Dashboard',
  'route' => $config['site_url'] . '/index.php',
  'page'  => 'dashboard',
  'class' => '',
  'id'    => 'dashboard',
  'extra' => '',
));

$data['side_ui_menu'] = $side_ui_menu->get_menu();

$data['admin_sidebar'] = $side_ui_menu->get_menu();
