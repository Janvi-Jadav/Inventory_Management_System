<?php
$shop_id = getSessionUserID();


$side_ui_menu = new SidebarMenu;

$side_ui_menu->add(array(
  'type'  => 'menu',
  'icon'  => 'fa fa-dashboard',
  'text'  => 'Dashboard',
  'route' => $config['site_url'] . '/index.php',
  'page'  => 'dashboard',
  'class' => '',
  'id'    => 'dashboard',
  'extra' => '',
));

if (checkPermition('all_user')) {
  $side_ui_menu->add(array(
    'type'  => 'menu',
    'icon'  => 'fa fa-users',
    'text'  => 'All Users',
    'route' => $config['site_url'] . '/index.php?view=users',
    'page'  => 'users',
    'class' => '',
    'id'    => 'users',
    'extra' => '',
  ));
}

if (checkPermition('device_managment')) {
  $side_ui_menu->add(array(
    'type'  => 'menu',
    'icon'  => 'fa fa-phone',
    'text'  => 'Phone - Buy / Sales',
    'route' => '#',
    'page'  => 'device_management',
    'class' => '',
    'id'    => 'device_management',
    'extra' => '',
    'sub_menu' => [

      array(
        'type'  => 'menu',
        'icon'  => 'fa fa-bar-chart',
        'text'  => 'Add Phone',
        'route' => $config['site_url'] . '/index.php?view=device_manage_shop&action=new',
        'page'  => 'new_device',
        'class' => '',
        'id'    => 'new_device',
        'extra' => '',
        'permission' => 'device_managment',
      ),

      array(
        'type'  => 'menu',
        'icon'  => 'fa fa-bar-chart',
        'text'  => 'Waiting For Accept',
        'route' => $config['site_url'] . '/index.php?view=device_manage_shop&action=waiting',
        'page'  => 'device_stock_waiting',
        'class' => '',
        'id'    => 'device_stock_waiting',
        'extra' => '',
        'permission' => 'device_managment',
      ),

      array(
        'type'  => 'menu',
        'icon'  => 'fa fa-bar-chart',
        'text'  => 'Phone Stock',
        'route' => $config['site_url'] . '/index.php?view=device_manage_shop',
        'page'  => 'device_stock',
        'class' => '',
        'id'    => 'device_stock',
        'extra' => '',
        'permission' => 'device_managment',
      ),
      array(
        'type'  => 'menu',
        'icon'  => 'fa fa-bar-chart',
        'text'  => 'Phone Sales Report',
        'route' => $config['site_url'] . '/index.php?view=device_manage_shop&action=out_stock',
        'page'  => 'device_out_stock',
        'class' => '',
        'id'    => 'device_out_stock',
        'extra' => '',
        'permission' => 'device_manage',
      ),


    ]
  ));
}

if (checkPermition('current_stock')) {
  $side_ui_menu->add(array(
    'type'  => 'menu',
    'icon'  => 'fa fa-bookmark-o',
    'text'  => 'Current Stock',
    'route' => $config['site_url'] . '/index.php?view=shop_user_stock',
    'page'  => 'shop_user_stock',
    'class' => '',
    'id'    => 'shop_user_stock',
    'extra' => '',
  ));
}

if (checkPermition('shop_product_price')) {
  $side_ui_menu->add(array(
    'type'  => 'menu',
    'icon'  => 'fa fa-gbp',
    'text'  => 'Update Min. Qty',
    'route' => $config['site_url'] . '/index.php?view=shop_product_price',
    'page'  => 'shop_product_price',
    'class' => '',
    'id'    => 'shop_product_price',
    'extra' => '',
  ));
}

if (checkPermition('discount')) {
  $side_ui_menu->add(array(
    'type'  => 'menu',
    'icon'  => 'fa fa-percent',
    'text'  => 'Offer',
    'route' => $config['site_url'] . '/index.php?view=discount',
    'page'  => 'discount',
    'class' => '',
    'id'    => 'discount',
    'extra' => '',
  ));
}

if (checkPermition('purchase_managment')) {

  $side_ui_menu->add(array(
    'type'     => 'menu',
    'icon'     => 'fa fa-database',
    'text'     => 'Purchase Management',
    'route'    => '#',
    'page'     => 'stock_manage',
    'class'    => '',
    'id'       => 'stock_manage',
    'extra'    => '',
    'sub_menu' => [
      array(
        'type'  => 'menu',
        'icon'  => 'fa fa-bookmark',
        'text'  => 'Purchase History',
        'route' => $config['site_url'] . '/index.php?view=shop_stock_manage',
        'page'  => 'shop_stock_manage',
        'class' => '',
        'id'    => 'shop_stock_manage',
        'extra' => '',
      ),
      array(
        'type'     => 'menu',
        'icon'     => 'fa fa-database',
        'text'     => 'Waiting for Acceptance',
        'route' => $config['site_url'] . '/index.php?view=shop_stock_history&action=shop_bill_request&type=pendding_bill',
        'page'     => 'shop_bill_request',
        'class'    => '',
        'id'       => 'shop_bill_request',
        'extra'    => '',
      ),
    ],
  ));
}

if (checkPermition('refund_management')) {

  $side_ui_menu->add(array(
    'type'     => 'menu',
    'icon'     => 'fa fa-database',
    'text'     => 'Refund Management',
    'route'    => '#',
    'page'     => 'refund_management',
    'class'    => '',
    'id'       => 'refund_management',
    'extra'    => '',
    'sub_menu' => [
      array(
        'type'  => 'menu',
        'icon'  => 'fa fa-bookmark',
        'text'  => 'Refund',
        'route' => $config['site_url'] . '/index.php?view=refund_management&action=refund',
        'page'  => 'refund',
        'class' => '',
        'id'    => 'refund',
        'extra' => '',
      ),
      array(
        'type'     => 'menu',
        'icon'     => 'fa fa-database',
        'text'     => 'Refund History',
        'route' => $config['site_url'] . '/index.php?view=refund_management&action=refund_history',
        'page'     => 'refund_history',
        'class'    => '',
        'id'       => 'refund_history',
        'extra'    => '',
      ),
    ],
  ));
}

if (checkPermition('exchange_management')) {

  $side_ui_menu->add(array(
    'type'     => 'menu',
    'icon'     => 'fa fa-exchange',
    'text'     => 'Exchange Management',
    'route'    => '#',
    'page'     => 'exchange_management',
    'class'    => '',
    'id'       => 'exchange_management',
    'extra'    => '',
    'sub_menu' => [
      array(
        'type'  => 'menu',
        'icon'  => 'fa fa-exchange',
        'text'  => 'Exchange',
        'route' => $config['site_url'] . '/index.php?view=exchange',
        'page'  => 'exchange',
        'class' => '',
        'id'    => 'exchange',
        'extra' => '',
      ),
      array(
        'type'     => 'menu',
        'icon'     => 'fa fa-database',
        'text'     => 'Exchange History',
        'route' => $config['site_url'] . '/index.php?view=exchange_history',
        'page'     => 'exchange_history',
        'class'    => '',
        'id'       => 'exchange_history',
        'extra'    => '',
      ),
    ],
  ));
}



if (checkPermition('eod')) {
  $side_ui_menu->add(array(
    'type'  => 'menu',
    'icon'  => 'fa fa-plus-square',
    'text'  => 'New POS',
    'route' => $config['site_url'] . '/index.php?view=pos',
    'page'  => 'pos',
    'class' => '',
    'id'    => 'pos',
    'extra' => '',
  ));
  $side_ui_menu->add(array(
    'type'  => 'menu',
    'icon'  => 'fa fa-plus-square',
    'text'  => 'POS PDA',
    'route' => $config['site_url'] . '/index.php?view=pos_pda',
    'page'  => 'pos_pda',
    'class' => '',
    'id'    => 'pos_pda',
    'extra' => '',
  ));
}


$sub_menu = [];

if (checkPermition('eod')) {
  $sub_menu[] = array(
    'type'  => 'menu',
    'icon'  => 'fa fa-list-alt',
    'text'  => 'Eod Open',
    'route' => $config['site_url'] . '/index.php?view=eod&action=start_day',
    'page'  => 'start_day',
    'class' => '',
    'id'    => 'start_day',
    'extra' => '',
    'permission' => 'eod',
  );

  $sub_menu[] = array(
    'type'  => 'menu',
    'icon'  => 'fa fa-list-alt',
    'text'  => 'Eod Close',
    'route' => $config['site_url'] . '/index.php?view=eod&action=end_day',
    'page'  => 'end_day',
    'class' => '',
    'id'    => 'end_day',
    'extra' => '',
    'permission' => 'eod',
  );


  $sub_menu[] = array(
    'type'  => 'menu',
    'icon'  => 'fa fa-bar-chart',
    'text'  => 'EOD Report',
    'route' => $config['site_url'] . '/index.php?view=eod_report&action=list',
    'page'  => 'eod_reports',
    'class' => '',
    'id'    => 'eod_reports',
    'extra' => '',
  );
}

if (count($sub_menu) != 0) {
  $side_ui_menu->add(array(
    'type'  => 'menu',
    'icon'  => 'fa fa-database',
    'text'  => 'EOD Details',
    'route' => '#',
    'page' => 'eod_report',
    'class' => '',
    'id'    => 'eod_report',
    'extra' => '',
    'sub_menu' => $sub_menu,
  ));
}

if (checkPermition('wallet_history')) {
  $side_ui_menu->add(array(
    'type'     => 'menu',
    'icon'     => 'fa fa-sort',
    'text'     => 'Wallet History',
    'route' => $config['site_url'] . '/index.php?view=wallet_history',
    'page'     => 'wallet_history',
    'class'    => '',
    'id'       => 'wallet_history',
    'extra'    => '',
  ));
}



$data['side_ui_menu'] = $side_ui_menu->get_menu();

$data['admin_sidebar'] = $side_ui_menu->get_menu();
