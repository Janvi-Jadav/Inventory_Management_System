<?php

$user_type = getSessionUserType();
$side_ui_menu = new SidebarMenu;
$side_ui_menu->add(array(
  'type'  => 'menu',
  'icon'  => 'fa fa-dashboard',
  'text'  => 'Dashboard',
  'route' => $config['site_url'] . '/index.php',
  'page' => 'dashboard',
  'class' => '',
  'id'    => 'dashboard',
  'extra' => '',
  'permission' => 'dashboard_edit',
));


if ($user_type == 'master_admin') {
  $side_ui_menu->add(array(
    'type'  => 'menu',
    'icon'  => 'fa fa-building-o',
    'text'  => 'User Managment',
    'route' => $config['site_url'] . '/index.php?view=master_users&type=master_admin',
    'page' => 'company_shop',
    'class' => '',
    'id'    => 'company_shop',
    'extra' => '',
    'permission' => 'company_shop',
  ));
}



if (checkPermition('product_managment')) {
  $side_ui_menu->add(array(
    'type'  => 'menu',
    'icon'  => 'fa fa-cube',
    'text'  => 'Products Management',
    'route' => '#',
    'page'  => 'product_managment',
    'class' => '',
    'id'    => 'product_managment',
    'extra' => '',
    'sub_menu' => [

      array(
        'type'  => 'menu',
        'icon'  => 'fa fa-bar-chart',
        'text'  => 'Products',
        'route' => $config['site_url'] . '/index.php?view=product',
        'page'  => 'product',
        'class' => '',
        'id'    => 'product',
        'extra' => '',
        'permission' => 'product_managment',
      ),
      array(
        'type'  => 'menu',
        'icon'  => 'fa fa-bar-chart',
        'text'  => 'Product Stock',
        'route' => $config['site_url'] . '/index.php?view=product_stock',
        'page'  => 'product_stock',
        'class' => '',
        'id'    => 'product_stock',
        'extra' => '',
        'permission' => 'product_managment',
      ),
    ]
  ));
}

if (checkPermition('party_managment')) {
  $side_ui_menu->add(array(
    'type'  => 'menu',
    'icon'  => 'fa fa-user',
    'text'  => 'Party Management',
    'route' => '#',
    'page'  => 'party_managment',
    'class' => '',
    'id'    => 'party_managment',
    'extra' => '',
    'sub_menu' => [
      array(
        'type'  => 'menu',
        'icon'  => 'fa fa-bar-chart',
        'text'  => 'Add Party',
        'route' => $config['site_url'] . '/index.php?view=party&action=new',
        'page'  => 'new_party',
        'class' => '',
        'id'    => 'new_party',
        'extra' => '',
        'permission' => 'party_managment',
      ),
      array(
        'type'  => 'menu',
        'icon'  => 'fa fa-bar-chart',
        'text'  => 'View Party',
        'route' => $config['site_url'] . '/index.php?view=party&action=list',
        'page'  => 'view_party',
        'class' => '',
        'id'    => 'view_party',
        'extra' => '',
        'permission' => 'party_managment',
      ),
    ]
  ));
}

if (checkPermition('purchase_managment')) {
  $side_ui_menu->add(array(
    'type'  => 'menu',
    'icon'  => 'fa fa-shopping-cart',
    'text'  => 'Purchase Management',
    'route' => '#',
    'page'  => 'purchase_managment',
    'class' => '',
    'id'    => 'purchase_managment',
    'extra' => '',
    'sub_menu' => [
      array(
        'type'  => 'menu',
        'icon'  => 'fa fa-bar-chart',
        'text'  => 'New Purchase',
        'route' => $config['site_url'] . '/index.php?view=purchase&action=new',
        'page'  => 'new_purchase',
        'class' => '',
        'id'    => 'new_purchase',
        'extra' => '',
        'permission' => 'purchase_managment',
      ),
      array(
        'type'  => 'menu',
        'icon'  => 'fa fa-bar-chart',
        'text'  => 'View Purchase',
        'route' => $config['site_url'] . '/index.php?view=purchase&action=list',
        'page'  => 'view_purchase',
        'class' => '',
        'id'    => 'view_purchase',
        'extra' => '',
        'permission' => 'purchase_managment',
      ),
    ]
  ));
}

if (checkPermition('sales_managment')) {
  $side_ui_menu->add(array(
    'type'  => 'menu',
    'icon'  => 'fa fa-shopping-cart',
    'text'  => 'Sales Management',
    'route' => '#',
    'page'  => 'sales_managment',
    'class' => '',
    'id'    => 'sales_managment',
    'extra' => '',
    'sub_menu' => [
      array(
        'type'  => 'menu',
        'icon'  => 'fa fa-bar-chart',
        'text'  => 'New Sales',
        'route' => $config['site_url'] . '/index.php?view=sales&action=new',
        'page'  => 'new_sales',
        'class' => '',
        'id'    => 'new_sales',
        'extra' => '',
        'permission' => 'sales_managment',
      ),
      array(
        'type'  => 'menu',
        'icon'  => 'fa fa-bar-chart',
        'text'  => 'View Sales',
        'route' => $config['site_url'] . '/index.php?view=sales&action=list',
        'page'  => 'view_sales',
        'class' => '',
        'id'    => 'view_sales',
        'extra' => '',
        'permission' => 'sales_managment',
      ),
    ]
  ));
}


$data['side_ui_menu'] = $side_ui_menu->get_menu();

$data['master_sidebar'] = $side_ui_menu->get_menu();
