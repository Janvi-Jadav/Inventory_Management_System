<?php

$side_ui_menu = new SidebarMenu;


$side_ui_menu->add(array(
	'type'  => 'menu',
	'icon'  => 'fa fa-dashboard',
	'text'  => 'Dashboard',
	'route' => $config['site_url'] . '/index.php',
	'page'  => 'dashboard',
	'class' => '',
	'id'    => 'dashboard',
	'extra' => '',
));


if (checkPermition('eod')) {
	$side_ui_menu->add(array(
		'type'  => 'menu',
		'icon'  => 'fa fa-plus-square',
		'text'  => 'New POS',
		'route' => $config['site_url'] . '/index.php?view=pos',
		'page'  => 'pos',
		'class' => '',
		'id'    => 'pos',
		'extra' => '',
	));
	$side_ui_menu->add(array(
		'type'  => 'menu',
		'icon'  => 'fa fa-plus-square',
		'text'  => 'POS PDA',
		'route' => $config['site_url'] . '/index.php?view=pos_pda',
		'page'  => 'pos_pda',
		'class' => '',
		'id'    => 'pos_pda',
		'extra' => '',
	));
}

$sub_menu = [];

if (checkPermition('eod')) {
	$sub_menu[] = array(
		'type'  => 'menu',
		'icon'  => 'fa fa-list-alt',
		'text'  => 'Eod Open',
		'route' => $config['site_url'] . '/index.php?view=eod&action=start_day',
		'page'  => 'start_day',
		'class' => '',
		'id'    => 'start_day',
		'extra' => '',
		'permission' => 'eod',
	);

	$sub_menu[] = array(
		'type'  => 'menu',
		'icon'  => 'fa fa-list-alt',
		'text'  => 'Eod Close',
		'route' => $config['site_url'] . '/index.php?view=eod&action=end_day',
		'page'  => 'end_day',
		'class' => '',
		'id'    => 'end_day',
		'extra' => '',
		'permission' => 'eod',
	);
}

if (count($sub_menu) != 0) {
	$side_ui_menu->add(array(
		'type'  => 'menu',
		'icon'  => 'fa fa-database',
		'text'  => 'EOD Details',
		'route' => '#',
		'page' => 'eod_report',
		'class' => '',
		'id'    => 'eod_report',
		'extra' => '',
		'sub_menu' => $sub_menu,
	));
}

$data['side_ui_menu'] = $side_ui_menu->get_menu();
