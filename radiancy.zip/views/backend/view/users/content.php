<section class="content">
	<div class="row">
		<?php if ($view_mode == 'list') { ?>
			<div class="col-md-12">
				<div class="box box-info">
					<div class="box-header with-border">
						<h3 class="box-title">User List</h3>
						<a href="<?php echo $config['site_url'] ?>/index.php?view=users&action=add" class="btn btn-md btn-primary pull-right">New User</a>
					</div>
					<div class="box-body">
						<table class="table table-bordered table-reponsive table-hover">
							<thead>
								<tr>
									<th scope="col">No</th>
									<th scope="col">Name</th>
									<th scope="col">UserName</th>
									<th scope="col">Contact No</th>
									<th scope="col">Status</th>
									<th scope="col">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php $i = 1;
								foreach ($users as $user) { ?>
									<tr>
										<td data-label="No"><?php echo $i; ?></td>
										<td data-label="Name"><?php echo $user->first_name ?> <?php echo $user->last_name ?></td>
										<td data-label="UserName"><?php echo $user->email ?></td>
										<td data-label="Contact No"><?php echo $user->contact_no ?></td>
										<td data-label="Status">
											<?php
											if ($user->is_active == 1) {
												echo '<b><p class="text-green">Active</p></b>';
											} else {
												echo '<b><p class="text-red">InActive</p></b>';
											} ?>
										</td>
										<td data-label="Action">
											<a href="<?php echo $config['site_url'] ?>/index.php?view=users&action=edit&user_id=<?php echo $user->user_id; ?>" class="btn btn-primary btn-xs">Edit</a>

											<?php
											if ($user->is_active == 1) { ?>
												<a href="<?php echo $config['site_url'] ?>/index.php?view=users&action=disable_user&user_id=<?php echo $user->user_id; ?>" class="btn btn-danger btn-xs">Disable</a>
											<?php } else { ?>
												<a href="<?php echo $config['site_url'] ?>/index.php?view=users&action=enable_user&user_id=<?php echo $user->user_id; ?>" class="btn btn-success btn-xs">Enable</a>
											<?php } ?>

											<button class="btn btn-warning btn-xs" onclick="open_model('<?php echo $user->user_id; ?>','<?php echo $user->first_name ?> <?php echo $user->last_name ?>')">Reset Password</button>
										</td>
									</tr>
								<?php $i++;
								} ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div id="password_reset" class="modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">Change Password For '<span id="full_name"></span>'</h4>
						</div>
						<div class="modal-body">
							<input type="hidden" id="password_reset_user_id" value="">
							<form class="form-horizontal">
								<div class="form-group">
									<label for="password" class="col-md-2 control-label">Password</label>
									<div class="col-md-10">
										<input type="text" class="form-control" id="password" placeholder="Enter Password">
									</div>
								</div>
							</form>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							<button type="button" class="btn btn-success" onclick="reset_password()">Reset Password</button>
						</div>
					</div>
				</div>
			</div>
		<?php }
		if ($view_mode == 'add') { ?>
			<div class="col-xs-12">
				<div class="box box-info">
					<div class="box-header with-border">
						<h3 class="box-title">New User</h3>
					</div>
					<div class="box-body">
						<form class="form-horizontal" action="<?php echo $config['form_action_url'] ?>/add_user.php" method="post" onsubmit="return user_validate();">
							<div class="form-group">
								<label for="first_name" class="col-md-2 control-label">First Name</label>
								<div class="col-md-10">
									<input type="text" class="form-control" name="first_name" id="first_name" placeholder="Enter First Name">
								</div>
							</div>
							<div class="form-group" style="display:none">
								<label for="last_name" class="col-md-2 control-label">Last Name</label>
								<div class="col-md-10">
									<input type="text" class="form-control" name="last_name" id="last_name" placeholder="Enter Last Name">
								</div>
							</div>
							<div class="form-group">
								<label for="email" class="col-md-2 control-label">UserName</label>
								<div class="col-md-10">
									<input type="text" class="form-control" name="email" id="email" placeholder="Enter Username">
								</div>
							</div>
							<div class="form-group">
								<label for="password" class="col-md-2 control-label">Password</label>
								<div class="col-md-10">
									<input type="password" class="form-control" name="password" id="password" placeholder="Enter password">
								</div>
							</div>
							<div class="form-group" style="display:none">
								<label for="contact_no" class="col-md-2 control-label">Contact No</label>
								<div class="col-md-10">
									<input type="text" class="form-control" name="contact_no" id="contact_no" placeholder="Enter Contact No">
								</div>
							</div>
							<div class="form-group">
								<label for="contact_no" class="col-md-2 control-label">Permission</label>
								<div class="col-md-10">
									<div class="checkbox">
										<?php foreach ($shop_user_permission_list as $p) {
										?>
											<label><input type="checkbox" name="permission[]" id="permission" value="<?php echo $p; ?>" /> <?php echo ucwords(str_replace('_', ' ', $p)); ?></label>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<?php } ?>
									</div>
								</div>
							</div>
							<div class="box-footer">
								<button type="submit" class="btn btn-info">Add User</button>
								<a href="<?php echo $config['site_url'] ?>/index.php?view=users" class="btn btn-default">Cancel</a>
							</div>
						</form>
					</div>
				</div>
			</div>
		<?php }
		if ($view_mode == 'edit') { ?>
			<div class="col-xs-12">
				<div class="box box-info">
					<div class="box-header with-border">
						<h3 class="box-title">Edit User</h3>
					</div>
					<div class="box-body">
						<form class="form-horizontal" action="<?php echo $config['form_action_url'] ?>/update_user.php" method="post" onsubmit="return update_user_validate();">
							<input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
							<div class="form-group">
								<label for="first_name" class="col-md-2 control-label">First Name</label>
								<div class="col-md-10">
									<input type="text" class="form-control" name="first_name" id="first_name" placeholder="Enter First Name" value="<?php echo $user->first_name; ?>">
								</div>
							</div>

							<div class="form-group" style="display:none">
								<label for="last_name" class="col-md-2 control-label">Last Name</label>
								<div class="col-md-10">
									<input type="text" class="form-control" name="last_name" id="last_name" placeholder="Enter Last Name" value="<?php echo $user->last_name; ?>">
								</div>
							</div>

							<div class="form-group">
								<label for="email" class="col-md-2 control-label">UserName</label>
								<div class="col-md-10">
									<input type="text" class="form-control" name="email" id="email" placeholder="Enter Username as Email-Id" value="<?php echo $user->email; ?>">
								</div>
							</div>

							<div class="form-group" style="display:none">
								<label for="contact_no" class="col-md-2 control-label">Contact No</label>
								<div class="col-md-10">
									<input type="text" class="form-control" name="contact_no" id="contact_no" placeholder="Enter Contact No" value="<?php echo $user->contact_no; ?>">
								</div>
							</div>

							<div class="form-group">
								<label for="contact_no" class="col-md-2 control-label">Permission</label>
								<div class="col-md-10">
									<div class="checkbox">
										<?php
										foreach ($shop_user_permission_list as $p) {
											if (in_array($p, $user_allowed_permission)) {
												$cls = 'checked="checked"';
											} else {
												$cls = '';
											}

										?>
											<label><input type="checkbox" name="permission[]" id="permission" <?php echo $cls; ?> value="<?php echo $p; ?>" /> <?php echo ucwords(str_replace('_', ' ', $p)); ?></label>
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<?php } ?>
									</div>
								</div>
							</div>
							<div class="box-footer">
								<button type="submit" class="btn btn-info">Update User</button>
								<a href="<?php echo $config['site_url'] ?>/index.php?view=users" class="btn btn-default">Cancel</a>
							</div>
						</form>
					</div>
				</div>
			</div>
		<?php } ?>
	</div>
</section>