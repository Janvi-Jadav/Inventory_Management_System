<?php

$view_mode = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : 'new';
$item_per_page = 10;

if (!checkPermition('party_managment')) {
	FlashMessage::set('Page not allowed to Access', 'error');
	redirect('/index.php');
}

$data['page'] = 'purchase_managment';

if ($view_mode == 'new') {
	if (isset($_SESSION['purchase_bill'])) {
		unset($_SESSION['purchase_bill']);
	}
	$data['sub_page'] = 'new_purchase';
	$invoice_no = Purchase::getInvoiceNo();
	$partys = Party::where('is_active', 1)->orderBy('id', 'DESC')->get();
	$products = Product::where('is_active', 1)->orderBy('id', 'DESC')->get();
}

if ($view_mode == 'list') {
	$data['sub_page'] = 'view_purchase';

	$purchaseList = Purchase::where('is_active', 1)->orderBy('id', 'DESC')->get();
}
