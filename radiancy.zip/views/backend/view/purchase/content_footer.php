<script>
  $(document).ready(function() {



    $('#scan_code').focus();
    $("#date").datepicker({
      format: 'dd/mm/yyyy',
      autoclose: true
    });
    $('#date').datepicker('setDate', 'today');

    $("#p_date").datepicker({
      format: 'dd/mm/yyyy',
      autoclose: true
    });
    $('#p_date').datepicker('setDate', 'today');
  });

  <?php if ($view_mode == 'new') { ?>

    $(document).ready(function() {
      displaySession();
    })

    function addPurchaseItem() {
      var e = document.getElementById("products");
      var product_id = e.value;
      var qty = document.getElementById("p_qty").value;

      if (product_id == 0) {
        toastr.error('Please Select Product');
      } else if (qty <= 0) {
        toastr.error('Invalid Qty');
      } else {
        var formData = {
          action: 'purchase',
          method: 'addPurchaseItem',
          product_id: product_id,
          qty: qty,
        }; //Array
        $.ajax({
          url: "<?php echo $config['ajax_url'] ?>",
          type: "POST",
          data: formData,
          success: function(data, textStatus, jqXHR) {
            data = JSON.parse(data);
            if (data.type == 'success') {
              displaySession();
              toastr.success(data.msg);
            } else {
              toastr.error(data.msg);
            }
          },
        });
      }
    }

    function displaySession() {
      var formData = {
        action: 'purchase',
        method: 'displaySession',
      }; //Array
      $.ajax({
        url: "<?php echo $config['ajax_url'] ?>",
        type: "POST",
        data: formData,
        success: function(data, textStatus, jqXHR) {
          data = JSON.parse(data);
          if (data.type == 'success') {
            $('#purchase_item_list').html(data.html);

            if (data.total_qty > 0) {
              document.getElementById("saveBtn").style.display = "block";
            } else {
              document.getElementById("saveBtn").style.display = "none";
            }

            document.getElementById("p_qty").value = "";

            document.getElementById("total_qty").value = data.total_qty;



          }
        },
      });
    }

    function removeSession(key) {
      var formData = {
        action: 'purchase',
        method: 'removeItem',
        key: key,
      }; //Array
      $.ajax({
        url: "<?php echo $config['ajax_url'] ?>",
        type: "POST",
        data: formData,
        success: function(data, textStatus, jqXHR) {
          data = JSON.parse(data);
          if (data.type == 'success') {
            displaySession();
            toastr.success(data.msg);
          } else {
            toastr.error(data.msg);
          }
        },
      });
    }

  <?php } ?>

  <?php if ($view_mode == 'list') { ?>

    function viewBillDetails(id) {
      var formData = {
        action: 'purchase',
        method: 'displayBill',
        id: id,
      }; //Array
      $.ajax({
        url: "<?php echo $config['ajax_url'] ?>",
        type: "POST",
        data: formData,
        success: function(data, textStatus, jqXHR) {
          data = JSON.parse(data);
          if (data.type == 'success') {
            // $('#purchase_item_list').html(data.html);

            $('#inv_no').html(data.inv_no);
            $('#cmp_name').html(data.cmp_name);
            $('#inv_date').html(data.inv_date);
            $('#text_str').html(data.html);



            $('#viewBill').modal('toggle');

          }
        },
      });
    }
  <?php } ?>
</script>