  <script>
  	<?php if ($view_mode == 'list') { ?>

  		function viewStockHistory(id) {
  			var formData = {
  				action: 'product',
  				method: 'productHistory',
  				id: id,
  			}; //Array
  			$.ajax({
  				url: "<?php echo $config['ajax_url'] ?>",
  				type: "POST",
  				data: formData,
  				success: function(data, textStatus, jqXHR) {
  					data = JSON.parse(data);
  					if (data.type == 'success') {
  						// $('#purchase_item_list').html(data.html);

  						$('#prd_name').html(data.productName);
  						$('#stock').html(data.product_curr_stock);

  						$('#text_str').html(data.html);



  						$('#viewProductHistory').modal('toggle');

  					}
  				},
  			});
  		}
  	<?php } ?>
  </script>