<?php

$view_mode = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : 'list';
$item_per_page = 10;

if (!checkPermition('product_managment')) {
	FlashMessage::set('Page not allowed to Access', 'error');
	redirect('/index.php');
}

$data['page'] = 'product_managment';
$data['sub_page'] = 'product_stock';

if ($view_mode == 'list') {
	$products = Product::where('is_active', 1)->orderBy('id', 'DESC')->get();
}
if ($view_mode == 'download') {
	GneratePDF::DownloadStockReport();
}
