<section class="content">
	<div class="row">
		<div class="col-md-12">
			<div class="box box-info">
				<div class="box-header with-border">
					<h3 class="box-title">Product Stock</h3>
					<div class="pull-right">
						<a href="<?php echo $config['site_url'] ?>/index.php?view=product_stock&action=download" class="btn btn-primary">Download PDF</a>
					</div>
				</div>
				<div class="box-body">
					<table id="example1" class="table table-bordered table-reponsive table-hover">
						<thead>
							<tr>
								<th scope="col">No</th>
								<th scope="col">Name</th>
								<th scope="col">Current Stock</th>
								<th scope="col">Update Stock</th>
							</tr>
						</thead>
						<tbody>
							<?php $i = 1;
							foreach ($products as $product) {
							?>
								<tr>
									<td data-label="No"><?php echo $i; ?></td>
									<td data-label="Name"><?php echo $product->name; ?></td>
									<th data-label="Current Stock"><?php echo $product->curr_stock; ?></th>
									<td>
										<button onclick="viewStockHistory(<?php echo $product->id; ?>)" class="btn btn-primary btn-sm">Stock History</button>
										<button class="btn btn-danger btn-sm">Update Stock</button>
									</td>
								</tr>
							<?php $i++;
							} ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<div id="viewProductHistory" class="modal fade" role="dialog">
		<div class="modal-dialog modal-md" role="document">
			<div class="modal-content">
				<div class="modal-header" style="padding: 10px;">
					<h4 class="modal-title" id="prd_name"></h4>
					<h4 class="modal-title" id="stock"></h4>
				</div>
				<div class="modal-body">
					<div class="container-fluid">
						<div class="row" id="text_str"></div>
					</div>
				</div>
				<div class="modal-footer text-left" id="alert_btn">
					<button id="print_no" type="button" class="btn btn-danger btn-header" data-type="" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
</section>