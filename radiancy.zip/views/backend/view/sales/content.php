<section class="content">
	<div class="row">
		<?php

		use Carbon\Carbon;

		if ($view_mode == 'new') { ?>
			<form class="form-horizontal was-validated" id="purchase_form" action="<?php echo $config['form_action_url'] ?>/sales.php" method="post" enctype="multipart/form-data">
				<div class="col-lg-6">
					<div class="box box-info">
						<div class="box-header with-border">
							<h3 class="box-title text-primary"><i class="fa fa-shopping-cart text-aqua"></i> New Sales</h3>
							<div class="pull-right">
								<a href="<?php echo $config['site_url'] ?>/index.php?view=sales&action=list" class="btn btn-primary">Sales Bill List</a>
							</div>
						</div>
						<div class="box-body shop_pda_odr">
							<div class="attachment-block clearfix">
								<div class="row dt_row">
									<div class="col-xs-4">
										<h4 class="inv_no">Invoice : <span class="text-danger"><?php echo $invoice_no; ?></span></h4>
									</div>
									<div class="col-xs-8">
										<div class="input-group">
											<label for="date" class="input-group-addon" title="Select Date"><i class="fa fa-calendar"></i></label>
											<input type="text" class="form-control input-sm" placeholder="DATE" id="date" name="date" autocomplete="off" disabled>
										</div>
									</div>
								</div>
							</div>


							<input type="hidden" class="form-control" name="crud" value="add_purchase">
							<div class="form-group row">
								<label for="name" class="col-sm-2 control-label">Company*</label>
								<div class="col-sm-10">
									<select class="form-control select2" name="party_id" required>
										<option value="">Select Party*</option>
										<?php foreach ($partys as $party) { ?>
											<option value="<?php echo $party->id; ?>"><?php echo $party->cmp_name; ?></option>
										<?php } ?>
									</select>
								</div>
							</div>

							<div class="form-group row">
								<label for="name" class="col-sm-2 control-label">Inv No*</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="s_inv_no" id="s_inv_no" placeholder="Sales Invoice No*" required>
								</div>
							</div>

							<div class="form-group row">
								<label for="p_notes" class="col-sm-2 control-label">Sales Note</label>
								<div class="col-sm-10">
									<textarea type="text" class="form-control" rows="3" name="a_notes" id="a_notes" placeholder="Sales Notes"></textarea>
								</div>
							</div>

							<div class="form-group row">
								<label for="name" class="col-sm-2 control-label">Date*</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Sales Date" id="s_date" name="s_date" autocomplete="off">
								</div>
							</div>

							<div class="form-group row">
								<label for="name" class="col-sm-2 control-label">Total Qty</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="total_qty" id="total_qty" readonly>
								</div>
							</div>

							<label for="name" class="control-label">Fill Sales Product Details</label>
							<div class="attachment-block mt-10 clearfix">
								<div class="row dt_row">
									<div class="col-xs-7">
										<div class="col-sm-12">
											<select class="form-control select2" id="products" name="product_id">
												<option value="0">Select Product*</option>
												<?php foreach ($products as $product) { ?>
													<option value="<?php echo $product->id; ?>"><?php echo $product->name; ?></option>
												<?php } ?>
											</select>
										</div>
									</div>

									<div class="col-xs-3">
										<div class="col-sm-12">
											<input type="number" class="form-control" name="s_qty" id="s_qty" placeholder="Enter Qty *">
										</div>
									</div>

									<div class="col-xs-2">
										<div class="col-sm-12">
											<button class="btn btn-success btn-sm" onclick="addSalesItem()" type="button">Add Item</button>
										</div>
									</div>

								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="box box-info">
						<div class="box-header with-border">
							<h3 class="box-title text-primary"><i class="fa fa-inventory text-aqua"></i>Added Item List</h3>
							<div class="pull-right">
								<a href="<?php echo $config['site_url'] ?>/index.php?view=purchase&action=new" class="btn btn-danger">Clear Bill</a>
							</div>
						</div>
						<div id="purchase_item_list" class="box-body"></div>
						<div class="box-footer text-right" id="saveBtn" style="display: none;">
							<label for="first_name" class="col-sm-2 control-label"></label>
							<button type="submit" class="btn btn-success btn-lg btn-block">Generate Invoice</button>
						</div>
					</div>
				</div>

			</form>


		<?php } elseif ($view_mode == 'list') { ?>
			<div class="col-md-12">
				<div class="box box-info">
					<div class="box-header with-border">
						<h3 class="box-title">Purchase Invoice List</h3>
						<div class="pull-right">
							<a href="<?php echo $config['site_url'] ?>/index.php?view=sales&action=new" class="btn btn-primary">New Sales Invoice</a>
						</div>
					</div>
					<div class="box-body">
						<table id="example1" class="table table-bordered table-reponsive table-hover">
							<thead>
								<tr>
									<th scope="col">No</th>
									<th scope="col">Invoice No</th>
									<th scope="col">Date</th>
									<th scope="col">Company Name</th>
									<th scope="col">Sales Invoice No</th>
									<th scope="col">Sales Date</th>
									<th scope="col">Qty</th>
									<th scope="col">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php $i = 1;
								foreach ($SalesList as $p) {
								?>
									<tr>
										<td data-label="No"><?php echo $i; ?></td>
										<td data-label="Invoice No"><?php echo $p->inv_no; ?></td>
										<td data-label="Date"><?php echo Carbon::parse($p->datetime)->format('d/m/Y'); ?></td>
										<td data-label="Company Name"><?php echo $p->party->cmp_name; ?></td>
										<td data-label="Sales Invoice No"><?php echo $p->sales_inv_no; ?></td>
										<td data-label="Sales Date"><?php echo Carbon::parse($p->sales_date)->format('d/m/Y'); ?></td>
										<td data-label="Total Qty"><?php echo $p->total_qty; ?></td>
										<td data-label="Action">
											<button type="button" onclick="viewBillDetails(<?php echo $p->id; ?>)" class="btn btn-xs btn-primary">View</button>
										</td>
									</tr>
								<?php $i++;
								} ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		<?php } ?>
	</div>

	<div id="viewBill" class="modal fade" role="dialog">
		<div class="modal-dialog modal-md" role="document">
			<div class="modal-content">
				<div class="modal-header" style="padding: 10px;">
					<h4 class="modal-title" id="inv_no"></h4>
					<h4 class="modal-title" id="cmp_name"></h4>
					<h4 class="modal-title" id="inv_date"></h4>
				</div>
				<div class="modal-body">
					<div class="container-fluid">
						<div class="row" id="text_str"></div>
					</div>
				</div>
				<div class="modal-footer text-left" id="alert_btn">
					<button id="print_no" type="button" class="btn btn-danger btn-header" data-type="" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>

</section>