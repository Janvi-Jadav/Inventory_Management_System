<?php

$view_mode = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : 'new';
$item_per_page = 10;

if (!checkPermition('sales_managment')) {
	FlashMessage::set('Page not allowed to Access', 'error');
	redirect('/index.php');
}

$data['page'] = 'sales_managment';

if ($view_mode == 'new') {
	if (isset($_SESSION['sales_bill'])) {
		unset($_SESSION['sales_bill']);
	}
	$data['sub_page'] = 'new_sales';
	$invoice_no = Sales::getInvoiceNo();
	$partys = Party::where('is_active', 1)->orderBy('id', 'DESC')->get();
	$products = Product::where('is_active', 1)->orderBy('id', 'DESC')->get();
}

if ($view_mode == 'list') {
	$data['sub_page'] = 'view_sales';

	$SalesList = Sales::where('is_active', 1)->orderBy('id', 'DESC')->get();
}
