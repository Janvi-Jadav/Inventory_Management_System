<?php

$view_mode = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : 'new';
$item_per_page = 10;

if (!checkPermition('party_managment')) {
	FlashMessage::set('Page not allowed to Access', 'error');
	redirect('/index.php');
}

$data['page'] = 'party_managment';

if ($view_mode == 'new') {
	$data['sub_page'] = 'new_party';
}

if ($view_mode == 'list') {
	$data['sub_page'] = 'view_party';

	$partys = Party::where('is_active', 1)->orderBy('id', 'DESC')->get();
}
