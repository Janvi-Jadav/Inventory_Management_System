<section class="content">
	<div class="row">
		<?php if ($view_mode == 'new') { ?>
			<div class="col-md-12">
				<div class="box box-info">
					<div class="box-header with-border">
						<h3 class="box-title">Add New Party</h3>
						<div class="pull-right">
							<a href="<?php echo $config['site_url'] ?>/index.php?view=party&action=list" class="btn btn-primary">View All Party</a>
						</div>
					</div>
					<div class="box-body">
						<form class="form-horizontal" action="<?php echo $config['form_action_url'] ?>/party.php" method="post" enctype="multipart/form-data">

							<input type="hidden" class="form-control" name="crud" value="add_party">

							<div class="form-group row">
								<label for="name" class="col-sm-2 control-label">Company Name*</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="cmp_name" id="cmp_name" placeholder="Enter Company Name*" required>
								</div>
							</div>

							<div class="form-group row">
								<label for="name" class="col-sm-2 control-label">Contact Person Name*</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="cmp_person_name" id="cmp_person_name" placeholder="Contact Person Name*" required>
								</div>
							</div>

							<div class="form-group row">
								<label for="name" class="col-sm-2 control-label">GST No</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="gst_no" id="gst_no" placeholder="Enter GST No ">
								</div>
							</div>

							<div class="form-group row">
								<label for="name" class="col-sm-2 control-label">Mobile No*</label>
								<div class="col-sm-10">
									<input type="number" class="form-control" name="mo_no" id="mo_no" placeholder="Enter Mobile No*" required>
								</div>
							</div>

							<div class="form-group row">
								<label for="name" class="col-sm-2 control-label">Email address*</label>
								<div class="col-sm-10">
									<input type="email" class="form-control" name="email" id="email" placeholder="Enter Email Address*" required>
								</div>
							</div>

							<div class="form-group row">
								<label for="name" class="col-sm-2 control-label">Address*</label>
								<div class="col-sm-10">
									<textarea type="text" class="form-control" name="address" id="address" rows="3" placeholder="Enter Address*" required></textarea>
								</div>
							</div>

							<div class="form-group row">
								<label for="name" class="col-sm-2 control-label">City*</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="city" id="city" placeholder="Enter Party City*" required>
								</div>
							</div>

							<div class="form-group row">
								<label for="name" class="col-sm-2 control-label">State*</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="state" id="state" placeholder="Enter Party State*" required>
								</div>
							</div>

							<div class="form-group row">
								<label for="name" class="col-sm-2 control-label">Country*</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="country" value="India" id="country" placeholder="Enter Party Country*" required>
								</div>
							</div>

							<div class="box-footer">
								<label for="first_name" class="col-sm-2 control-label"></label>
								<button type="submit" class="btn btn-info">Save</button>
								<a href="<?php echo $config['site_url'] ?>/index.php?view=party" class="btn btn-default">Cancel</a>
							</div>

						</form>
					</div>
				</div>
			</div>
		<?php } elseif ($view_mode == 'list') { ?>
			<div class="col-md-12">
				<div class="box box-info">
					<div class="box-header with-border">
						<h3 class="box-title">Party List</h3>
						<div class="pull-right">
							<a href="<?php echo $config['site_url'] ?>/index.php?view=party&action=new" class="btn btn-primary">Add New Party</a>
						</div>
					</div>
					<div class="box-body">
						<table id="example1" class="table table-bordered table-reponsive table-hover">
							<thead>
								<tr>
									<th scope="col">No</th>
									<th scope="col">Company Name</th>
									<th scope="col">GST No</th>
									<th scope="col">Contact Name</th>
									<th scope="col">Mobile No</th>
									<th scope="col">City</th>
									<th scope="col">State</th>
								</tr>
							</thead>
							<tbody>
								<?php $i = 1;
								foreach ($partys as $p) {
								?>
									<tr>
										<td data-label="No"><?php echo $i; ?></td>
										<td data-label="Company Name"><?php echo $p->cmp_name; ?></td>
										<td data-label="GST No"><?php echo $p->gst_no; ?></td>
										<td data-label="Contact Name"><?php echo $p->cmp_person_name; ?></td>
										<td data-label="Mobile No"><?php echo $p->mobile; ?></td>
										<td data-label="City"><?php echo $p->city; ?></td>
										<td data-label="State"><?php echo $p->state; ?></td>
									</tr>
								<?php $i++;
								} ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		<?php } ?>
	</div>
</section>