<div class="col-md-12">
  <div class="box box-info">
    <div class="box-header with-border">
      <h3 class="box-title">Update Shop User</h3>
      <?php if ($type == 'shop') { ?>
        <a href="<?php echo $config['site_url'] ?>/index.php?view=master_users&action=add" class="btn btn-md btn-primary pull-right">Add Shop</a>
      <?php } else { ?>
        <a href="<?php echo $config['site_url'] ?>/index.php?view=master_users&action=add_admin" class="btn btn-md btn-primary pull-right">Add Admin</a>
      <?php }
      ?>

    </div>

    <div class="box-body">

      <table class="table table-bordered table-reponsive table-hover">
        <thead>
          <tr>
            <th scope="col">No</th>
            <th scope="col">Name</th>
            <th scope="col">UserName</th>
            <th scope="col">Contact No</th>
            <th scope="col">Active Module</th>
            <th scope="col">Status</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $i = 1;
          foreach ($users as $user) { ?>
            <tr>
              <td data-label="No"><?php echo $i; ?></td>
              <td data-label="Name"><?php echo $user->first_name ?> <?php echo $user->last_name ?></td>
              <td data-label="UserName"><?php echo $user->email ?></td>
              <td data-label="Contact No"><?php echo $user->contact_no ?></td>
              <td data-label="Active Module">-</td>
              <td data-label="Status">
                <?php
                if ($user->is_active == 1) {
                  echo '<b><p class="text-green">Active</p></b>';
                } else {
                  echo '<b><p class="text-red">InActive</p></b>';
                } ?>
              </td>
              <td data-label="Action">
                <a href="<?php echo $config['site_url'] ?>/index.php?view=master_users&action=edit&user_id=<?php echo $user->user_id; ?>&type=<?php echo $type; ?>" class="btn btn-primary btn-xs">Edit</a>

                <?php
                if ($user->is_active == 1) { ?>
                  <a href="<?php echo $config['site_url'] ?>/index.php?view=master_users&action=disable_user&user_id=<?php echo $user->user_id; ?>" class="btn btn-danger btn-xs">Disable</a>
                <?php } else { ?>
                  <a href="<?php echo $config['site_url'] ?>/index.php?view=master_users&action=enable_user&user_id=<?php echo $user->user_id; ?>" class="btn btn-success btn-xs">Enable</a>
                <?php } ?>

                <button class="btn btn-warning btn-xs" onclick="open_model('<?php echo $user->user_id; ?>','<?php echo $user->first_name ?> <?php echo $user->last_name ?>')">Reset Password</button>
                <a href="<?php echo $config['site_url'] ?>/index.php?view=master_users&action=enable_permission&user_id=<?php echo $user->user_id; ?>" class="btn btn-success btn-xs">Set Permission</a>
                <!-- <button type="button" onclick="submitForm()" class="btn btn-info btn-xs">All Permission</button> -->
                <form id="all_permission" action="<?php echo $config['form_action_url'] ?>/update_permission.php" method="post" style="display: inline;">
                  <input type="hidden" name="master_user" value="<?php echo $user->user_id; ?>">
                  <?php
                  $list;
                  if ($user->user_type == 'master_admin') {
                    $list = $master_admin_permissions;
                  }
                  if ($user->user_type == 'shop') {
                    $list = $shop_permission_list;
                  }
                  foreach ($list as $p) {
                  ?>
                    <input type="checkbox" name="permission[]" id="permission" checked value="<?php echo $p; ?>" style="display: none;" />
                  <?php
                  }
                  if ($user->user_type == 'master_admin') {
                  ?>
                    <button type="submit" class="btn btn-info btn-xs">All Permission</button>
                  <?php } ?>
                </form>

                <?php
                if ($user->user_type == 'admin' && $user->is_active == 1) {
                ?>
                  <!-- <a href="#" class="btn btn-danger btn-xs">Printer Setting</a> -->
                <?php } ?>


              </td>
            </tr>
          <?php $i++;
          } ?>
        </tbody>
      </table>

    </div>
  </div>
</div>

<div id="password_reset" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Change Password For '<span id="full_name"></span>'</h4>
      </div>
      <div class="modal-body">
        <input type="hidden" id="password_reset_user_id" value="">

        <form class="form-horizontal">
          <div class="form-group">
            <label for="password" class="col-sm-2 control-label">Password</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="password" placeholder="Enter Password">
            </div>
          </div>
        </form>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success" onclick="reset_password()">Reset Password</button>
      </div>
    </div>

  </div>
</div>