<?php


if ($user_acc_type == 'master_admin' || $user_acc_type == 'super_admin') {
  $menu = $data['master_sidebar'];
  // dd($menu);
}
if ($user_acc_type == 'shop') {
  $menu = [];
  foreach ($shop_permission_list as $p) {
    array_push($menu, ['text' => ucwords(str_replace('_', ' ', $p)), 'permission' => $p]);
  }
}

?>
<form class="form-horizontal" action="<?php echo $config['form_action_url'] ?>/update_master_user.php" method="post">
  <div class="col-xs-12">
    <div class="box box-info">
      <div class="box-header with-border">
        <h3 class="box-title">Update Shop User</h3>
        <div class="pull-right">
          <button type="submit" class="btn btn-md btn-info">Update User</button>
          <a href="<?php echo $config['site_url'] ?>/index.php?view=master_users" class="btn btn-md btn-primary">Shop List</a>
        </div>

      </div>
      <div class="box-body">



        <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">

        <div class="form-group">
          <label for="first_name" class="col-sm-2 control-label">First Name</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="first_name" id="first_name" placeholder="Enter First Name" value="<?php echo $user->first_name; ?>" required>
          </div>
        </div>

        <div class="form-group">
          <label for="last_name" class="col-sm-2 control-label">Last Name</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Enter Last Name" value="<?php echo $user->last_name; ?>">
          </div>
        </div>

        <div class="form-group">
          <label for="email" class="col-sm-2 control-label">UserName</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="email" id="email" placeholder="Enter Username as Email-Id" value="<?php echo $user->email; ?>" required>
          </div>
        </div>

        <div class="form-group">
          <label for="contact_no" class="col-sm-2 control-label">Contact No</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="contact_no" id="contact_no" placeholder="Enter Contact No" value="<?php echo $user->contact_no; ?>">
          </div>
        </div>

        <!-- <div class="form-group">
          <label for="contact_no" class="col-sm-2 control-label">Permission</label>
          <div class="col-sm-10">
            <div class="checkbox">

              <table class="table table-bordered table-reponsive table-hover">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Menu</th>
                    <th><label><input type="checkbox" id="checkbox-all" /><b> All Permission</b></label></th>
                  </tr>
                </thead>
                <tbody id="table-body">
                  <?php

                  foreach ($menu as $key => $p) {
                    $permission = isset($p['permission']) ? $p['permission'] : '';
                    if (in_array($permission, $user_allowed_permission)) {
                      $cls = 'checked="checked"';
                    } else {
                      $cls = '';
                    }
                  ?>
                    <tr>
                      <td><?php echo $key + 1; ?></td>
                      <td><?php echo $p['text']; ?></td>
                      <td>
                        <?php
                        if (isset($p['sub_menu'])) {
                          echo '<table>';
                          foreach ($p['sub_menu'] as $s) {
                            $sub_permission = isset($s['permission']) ? $s['permission'] : '';
                            if (in_array($sub_permission, $user_allowed_permission)) {
                              $sub_cls = 'checked="checked"';
                            } else {
                              $sub_cls = '';
                            }
                        ?>
                    <tr>
                      <td>
                        <?php
                            if (isset($s['permission'])) {
                        ?>

                          <label><?php echo isset($s['permission']) ? '<input type="checkbox" name="permission[]" id="permission"' . $sub_cls . ' value="' . $s['permission'] . '" />' : '' ?><?php echo isset($s['permission']) ? ucwords(str_replace('_', ' ', $s['permission'])) : ''; ?></label>
                        <?php
                            }

                        ?>
                      </td>
                    </tr>
                  <?php
                          }
                          echo '</table>';
                        } else {
                  ?>
                  <label><?php echo isset($p['permission']) ? '<input type="checkbox" name="permission[]" id="permission"' . $cls . ' value="' . $p['permission'] . '" />' : '' ?><?php echo isset($p['permission']) ? ucwords(str_replace('_', ' ', $p['permission'])) : ''; ?></label>
                <?php
                        }
                ?>


                </td>
                </tr>


              <?php
                  }


              ?>
                </tbody>
              </table>
            </div>
          </div>
        </div> -->


        <?php

        if ($user_acc_type == 'shop') {

        ?>

          <hr>

          <h4 class="box-title">Invoice Details</h4>
          <div class="form-group">
            <label for="title" class="col-sm-2 control-label">Title</Title></label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="title" id="title" placeholder="Enter Title" value="<?php echo $user->invoice_ttl; ?>">
            </div>
          </div>

          <div class="form-group">
            <label for="vat_no" class="col-sm-2 control-label">Vat No.</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="vat_no" id="vat_no" placeholder="Enter VAT no." value="<?php echo $user->invoice_vat; ?>">
            </div>
          </div>

          <div class="form-group">
            <label for="address" class="col-sm-2 control-label">Address</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="address" id="address" placeholder="Enter Address" value="<?php echo $user->invoice_address; ?>">
            </div>
          </div>
          <div class="form-group">
            <label for="map" class="col-sm-2 control-label">Map Link</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="map_link" id="map_link" placeholder="Enter Map Link" value="<?php echo $user->map_link; ?>">
            </div>
          </div>
          <div class="form-group">
            <label for="close_time" class="col-sm-2 control-label">Close Time</label>
            <div class="col-sm-4">
              <?php
              $date = null;
              if ($user->close_time != null) {
                $date = Carbon\Carbon::createFromFormat('H:i:s', $user->close_time, 'Asia/Kolkata')->format('h:i A');
              }
              ?>
              <input type="text" class="form-control" name="close_time" id="close_time" value="<?php echo $date; ?>" placeholder="Enter Close Time" required>
            </div>
          </div>
        <?php } ?>
        <div class="box-footer">
          <a href="<?php echo $config['site_url'] ?>/index.php?view=master_users" class="btn btn-default">Cancel</a>
          <button type="submit" class="btn btn-info pull-right">Update User</button>
        </div>
      </div>
    </div>
  </div>
</form>