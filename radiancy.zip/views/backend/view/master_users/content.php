 <!-- Main content -->
 <section class="content">
   <!-- Small boxes (Stat box) -->
   <div class="row">
     <?php

      if ($view_mode == 'list') {
        include('list/content.php');
      }
      if ($view_mode == 'add') {
        include('add/content.php');
      }
      if ($view_mode == 'add_admin') {
        include('add_admin/content.php');
      }
      if ($view_mode == 'edit') {
        include('edit/content.php');
      }
      if ($view_mode == 'enable_permission') {
        include('add_permission.php');
      }

      ?>

   </div>
   <!-- /.row -->
   <!-- Main row -->
   <div class="row">

   </div>
   <!-- /.row (main row) -->
 </section>
 <!-- /.content -->