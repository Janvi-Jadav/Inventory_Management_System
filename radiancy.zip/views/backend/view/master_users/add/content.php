<div class="col-xs-12">
  <div class="box box-info">
    <div class="box-header with-border">
      <h3 class="box-title">New Shop User</h3>
      <a href="<?php echo $config['site_url'] ?>/index.php?view=master_users" class="btn btn-md btn-primary pull-right">Shop List</a>
    </div>
    <div class="box-body">

      <form class="form-horizontal" action="<?php echo $config['form_action_url'] ?>/add_master_user.php" method="post">

        <div class="form-group">
          <label for="first_name" class="col-sm-2 control-label">First Name</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="first_name" id="first_name" placeholder="Enter First Name" required>
          </div>
        </div>

        <div class="form-group">
          <label for="last_name" class="col-sm-2 control-label">Last Name</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Enter Last Name">
          </div>
        </div>

        <div class="form-group">
          <label for="email" class="col-sm-2 control-label">UserName</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="email" id="email" placeholder="Enter Username as Email-Id" required>
          </div>
        </div>

        <div class="form-group">
          <label for="password" class="col-sm-2 control-label">Password</label>
          <div class="col-sm-10">
            <input type="password" class="form-control" name="password" id="password" placeholder="Enter password" required>
          </div>
        </div>

        <div class="form-group">
          <label for="contact_no" class="col-sm-2 control-label">Contact No</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="contact_no" id="contact_no" placeholder="Enter Contact No">
          </div>
        </div>

        <div class="form-group">
          <label for="contact_no" class="col-sm-2 control-label">Permission</label>
          <div class="col-sm-10">
            <div class="checkbox">
              <div class="row">
                <?php

                foreach ($shop_permission_list as $p) {
                ?>
                  <div class="col-sm-4">
                    <label><input type="checkbox" name="permission[]" id="permission" value="<?php echo $p; ?>" /> <?php echo ucwords(str_replace('_', ' ', $p)); ?></label>
                  </div>

                <?php } ?>
              </div>
            </div>
          </div>
        </div>

        <hr>

        <h4 class="box-title">Invoice Details</h4>
        <div class="form-group">
          <label for="title" class="col-sm-2 control-label">Title</Title></label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="title" id="title" placeholder="Enter Title">
          </div>
        </div>

        <div class="form-group">
          <label for="vat_no" class="col-sm-2 control-label">Vat No.</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="vat_no" id="vat_no" placeholder="Enter VAT no.">
          </div>
        </div>

        <div class="form-group">
          <label for="address" class="col-sm-2 control-label">Address</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="address" id="address" placeholder="Enter Address">
          </div>
        </div>

        <div class="form-group">
          <label for="map" class="col-sm-2 control-label">Map Link</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="map_link" id="map_link" placeholder="Enter Map Link" required>
          </div>
        </div>

        <div class="form-group">
          <label for="close_time" class="col-sm-2 control-label">Close Time</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" name="close_time" id="close_time" placeholder="Enter Close Time" required>
          </div>
        </div>

        <div class="box-footer">
          <a href="<?php echo $config['site_url'] ?>/index.php?view=master_users" class="btn btn-default">Cancel</a>
          <button type="submit" class="btn btn-info pull-right">Add User</button>
        </div>

      </form>

    </div>
  </div>
</div>