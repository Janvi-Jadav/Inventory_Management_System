<?php

if ($user_acc_type == 'master_admin' || $user_acc_type == 'super_admin') {
  $menu = $master_admin_permissions;
}
if ($user_acc_type == 'admin') {
  $menu = $master_admin_permissions;
}
?>
<form id="all_permission" action="<?php echo $config['form_action_url'] ?>/update_permission.php" method="post" style="display: inline;">
  <input type="hidden" name="master_user" value="<?php echo $user->user_id; ?>">
  <div class="col-md-12">
    <div class="box box-info">
      <div class="box-header with-border">
        <h3 class="box-title">Set Permission For <span class="text-danger"><?php echo strtoupper($user_name); ?></span></h3>
        <div class="pull-right">
          <button type="submit" class="btn btn-md btn-info">Update Permission</button>
        </div>
      </div>
      <div class="box-body">
        <div class="col-sm-12">
          <div class="pull-right">
            <label><input type="checkbox" id="checkbox-all" /> All Permission</label>
          </div>
        </div>

        <br>
        <!-- <input type="checkbox" id="checkbox-all" />All Permission -->
        <div id="table-body">
          <?php foreach ($menu as $m) {

            if (in_array($m, $user_allowed_permission)) {
              $cls = 'checked="checked"';
            } else {
              $cls = '';
            }

          ?>
            <div class="col-sm-3">
              <label><input type="checkbox" name="permission[]" <?php echo $cls; ?> id="permission" value="<?php echo $m; ?>" /> <?php echo ucwords(str_replace('_', ' ', $m)); ?></label>
            </div>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>
</form>