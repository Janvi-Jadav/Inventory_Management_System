<?php

if ($user_acc_type == 'master_admin' || $user_acc_type == 'super_admin') {
  $menu = $data['master_sidebar'];
}
if ($user_acc_type == 'shop') {
  $menu = [];
  foreach ($shop_permission_list as $p) {
    array_push($menu, ['text' => ucwords(str_replace('_', ' ', $p)), 'permission' => $p]);
  }
}
?>
<form id="all_permission" action="<?php echo $config['form_action_url'] ?>/update_permission.php" method="post" style="display: inline;">
  <input type="hidden" name="master_user" value="<?php echo $user->user_id; ?>">
  <div class="col-md-12">
    <div class="box box-info">
      <div class="box-header with-border">
        <h3 class="box-title">Set Permission For <span class="text-danger"><?php echo strtoupper($user_name); ?></span></h3>
        <div class="pull-right">
          <button type="submit" class="btn btn-md btn-info">Update Permission</button>
        </div>
      </div>
      <div class="box-body">
        <table class="table table-bordered mb-0">
          <thead>
            <tr>
              <th style="width: 10px">#</th>
              <th>Menu</th>

              <th>Permission Name
                <div class="pull-right" style="margin-right: 9.5%;"><input type="checkbox" id="checkbox-all" />
                </div>
              </th>

            </tr>
          </thead>
          <tbody id="table-body">
            <?php

            foreach ($menu as $key => $p) {
              $permission = isset($p['permission']) ? $p['permission'] : '';
              if (in_array($permission, $user_allowed_permission)) {
                $cls = 'checked="checked"';
              } else {
                $cls = '';
              }
              if ($p['text'] != "Company / Shop") {
            ?>
                <tr>
                  <td><?php echo $key + 1; ?></td>
                  <th><?php echo $p['text']; ?></th>
                  <td>
                    <?php

                    if (isset($p['sub_menu'])) {

                      echo '<table class="table table-bordered mb-0">';
                      foreach ($p['sub_menu'] as $s) {
                        $sub_permission = isset($s['permission']) ? $s['permission'] : '';
                        if (in_array($sub_permission, $user_allowed_permission)) {
                          $sub_cls = 'checked="checked"';
                        } else {
                          $sub_cls = '';
                        }
                        if (isset($s['permission'])) {
                    ?>
                <tr>
                  <th style="width: 80%">
                    <?php

                    ?>

                    <?php echo isset($s['permission']) ? ucwords(str_replace('_', ' ', $s['permission'])) : ''; ?>
                    <?php


                    ?>
                  </th>
                  <td style="text-align: center;">
                    <?php echo isset($s['permission']) ? '<input type="checkbox" name="permission[]" id="permission"' . $sub_cls . ' value="' . $s['permission'] . '" />' : '' ?>

                  </td>
                </tr>
            <?php
                        }
                      }
                      echo '</table>';
                    } else {
            ?>
            <table class="table table-bordered mb-0">
              <th style="width: 80%">
                <?php echo isset($p['permission']) ? ucwords(str_replace('_', ' ', $p['permission'])) : ''; ?>
              </th>
              <td style="text-align: center;">
                <?php echo isset($p['permission']) ? '<input type="checkbox" name="permission[]" id="permission"' . $cls . ' value="' . $p['permission'] . '" />' : '' ?>
              </td>

            </table>

          <?php
                    }
          ?>


          </td>
          </tr>


      <?php
              }
            }


      ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</form>