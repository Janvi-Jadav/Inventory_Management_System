<?php
$data['page'] = 'company_shop';
$view_mode     = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : 'list';
$type     = (isset($_GET['type']) && $_GET['type'] != '') ? $_GET['type'] : 'master_admin';
$item_per_page = 10;
$user_type = getSessionUserType();

if ($user_type != 'master_admin') {
    FlashMessage::set('Page not allowed to Access', 'error');
    redirect('/index.php');
}

if ($view_mode == 'disable_user') {
    $user_id         = get_form_value('user_id');
    $user            = User::find($user_id);
    $user->is_active = 0;
    $user->save();
    FlashMessage::set('User Has Been Disabled', 'success');
    redirect($_SERVER['HTTP_REFERER'], 'full');
}

if ($view_mode == 'enable_user') {
    $user_id         = get_form_value('user_id');
    $user            = User::find($user_id);
    $user->is_active = 1;
    $user->save();
    FlashMessage::set('User Has Been Enabled', 'success');
    redirect($_SERVER['HTTP_REFERER'], 'full');
}

if ($view_mode == 'list') {
    if ($type == 'shop') {
        $data['sub_page'] = 'users';
        $users = User::whereIn('user_type', array('shop'))->get();
    }
    if ($type == "master_admin") {
        $data['sub_page'] = 'all_users';
        $users = User::whereIn('user_type', array('master_admin', 'admin'))->get();
    }
}
if ($view_mode == 'add') {
    $data['sub_page'] = 'users';
}

if ($view_mode == 'add_admin') {
    $data['sub_page'] = 'all_users';
}

if ($view_mode == 'edit') {
    if ($type == 'shop') {
        $data['sub_page'] = 'users';
    }
    if ($type == "master_admin") {
        $data['sub_page'] = 'all_users';
    }
    $user_id      = get_form_value('user_id');
    $user         = User::find($user_id);
    $user_acc_type = $user->user_type;
    $user_permission = Permission::where(array('user_id' => $user_id, 'is_active' => 1))->get();
    $user_allowed_permission = array();
    if (isset($user_permission) && $user_permission != "") {
        foreach ($user_permission as $p) {
            $user_allowed_permission[] = $p->permission;
        }
    }
}

if ($view_mode == 'enable_permission') {
    $user_id      = get_form_value('user_id');
    $user  = User::find($user_id);

    if ($user->user_type == 'admin') {
        $data['sub_page'] = 'all_users';
    }
    if ($user->user_type == "master_admin") {
        $data['sub_page'] = 'all_users';
    }
    $user_name = $user->email;
    $user_acc_type = $user->user_type;
    $user_permission = Permission::where(array('user_id' => $user_id, 'is_active' => 1))->get();
    $user_allowed_permission = array();
    if (isset($user_permission) && $user_permission != "") {
        foreach ($user_permission as $p) {
            $user_allowed_permission[] = $p->permission;
        }
    }
}
