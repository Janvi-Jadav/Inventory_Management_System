<div class="col-xs-12">
  <div class="box box-info">
    <div class="box-header with-border">
      <h3 class="box-title">New Admin User</h3>
      <a href="<?php echo $config['site_url'] ?>/index.php?view=master_users&type=master_admin" class="btn btn-md btn-primary pull-right">Admin List</a>
    </div>
    <div class="box-body">

      <form class="form-horizontal" action="<?php echo $config['form_action_url'] ?>/add_admin_user.php" method="post">

        <div class="form-group">
          <label for="first_name" class="col-sm-2 control-label">First Name</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="first_name" id="first_name" placeholder="Enter First Name" required>
          </div>
        </div>

        <div class="form-group">
          <label for="last_name" class="col-sm-2 control-label">Last Name</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Enter Last Name">
          </div>
        </div>

        <div class="form-group">
          <label for="email" class="col-sm-2 control-label">UserName</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="email" id="email" placeholder="Enter Username as Email-Id" required>
          </div>
        </div>

        <div class="form-group">
          <label for="password" class="col-sm-2 control-label">Password</label>
          <div class="col-sm-10">
            <input type="password" class="form-control" name="password" id="password" placeholder="Enter password" required>
          </div>
        </div>

        <div class="form-group">
          <label for="contact_no" class="col-sm-2 control-label">Contact No</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="contact_no" id="contact_no" placeholder="Enter Contact No">
          </div>
        </div>

        <div class="box-footer">
          <a href="<?php echo $config['site_url'] ?>/index.php?view=master_users" class="btn btn-default">Cancel</a>
          <button type="submit" class="btn btn-info pull-right">Add User</button>
        </div>

      </form>

    </div>
  </div>
</div>