<section class="content">
	<div class="row">
		<div class="col-md-8">
			<div class="box box-info">
				<div class="box-header with-border">
					<h3 class="box-title">Product List</h3>
					<div class="pull-right">
						<a href="<?php echo $config['site_url'] ?>/index.php?view=product&filter=active" class="btn btn-primary">Active</a>
						<a href="<?php echo $config['site_url'] ?>/index.php?view=product&filter=deactive" class="btn btn-danger">Inactive</a>

					</div>

				</div>
				<div class="box-body">
					<table id="example1" class="table table-bordered table-reponsive table-hover">
						<thead>
							<tr>
								<th scope="col">No</th>
								<th scope="col">Name</th>
								<th scope="col">Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $i = 1;
							foreach ($products as $product) {
							?>
								<tr>
									<td data-label="No"><?php echo $i; ?></td>
									<td data-label="Name"><?php echo $product->name; ?></td>
									<td><?php
											if ($product->is_active == 1) {
												$txt = 'Inactive';
												$urll = $config['site_url'] . '/index.php?view=product&action=enable&p_id=' . $product->id;
												$cls = 'btn-danger';
											} else {
												$txt = 'Active';
												$urll = $config['site_url'] . '/index.php?view=product&action=disable&p_id=' . $product->id;
												$cls = 'btn-success';
											}
											echo '<a class="btn ' . $cls . ' btn-xs" href="' . $urll . '" >' . $txt . '</a> '; ?>
										<!-- <a class="btn btn-primary btn-xs" href="<?php echo $config['site_url']; ?>/index.php?view=product&action=edit&size_id=<?php echo $size->id; ?>">Edit</a> -->
									</td>
								</tr>
							<?php $i++;
							} ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="box box-info">
				<div class="box-header with-border">
					<h3 class="box-title"><?php echo $view_mode == 'list' ? 'New' : 'Edit'; ?> Product</h3>
				</div>
				<div class="box-body">
					<form class="form-horizontals" action="<?php echo $config['form_action_url'] ?>/products.php" method="post" enctype="multipart/form-data">
						<input type="hidden" class="form-control" name="crud" value="<?php echo $view_mode == 'list' ? 'add_product' : 'update_product'; ?>" />
						<input type="hidden" class="form-control" name="id" value="<?php echo $view_mode == 'list' ? '' : $edit_size->id; ?>" />
						<div class="form-group">
							<input type="text" class="form-control" name="name" id="name" value="<?php echo $view_mode == 'list' ? '' : $edit_size->name; ?>" placeholder="Product Name *" required>
						</div>

						<div class="form-group">
							<input type="text" class="form-control" name="brand" id="brand" value="<?php echo $view_mode == 'list' ? '' : $edit_size->brand; ?>" placeholder="Brand Name">
						</div>

						<div class="form-group">
							<input type="text" class="form-control" name="color" id="color" value="<?php echo $view_mode == 'list' ? '' : $edit_size->color; ?>" placeholder="Color Name">
						</div>

						<div class="form-group">
							<input type="text" class="form-control" name="part_no" id="part_no" value="<?php echo $view_mode == 'list' ? '' : $edit_size->part_no; ?>" placeholder="Part No">
						</div>

						<div class="form-group">
							<input type="text" class="form-control" name="size" id="size" value="<?php echo $view_mode == 'list' ? '' : $edit_size->size; ?>" placeholder="Size">
						</div>

						<div class="form-group">
							<input type="number" class="form-control" name="opening_stock" id="opening_stock" value="<?php echo $view_mode == 'list' ? '' : $edit_size->opening_stock; ?>" placeholder="Opening Stock" <?php echo $view_mode == 'list' ? '' : 'readonly'; ?>>
						</div>

						<div class="form-group">
							<button type="submit" class="btn btn-primary"><?php echo $view_mode == 'list' ? 'Save' : 'Update'; ?></button>
							<a href="<?php echo $config['site_url'] ?>/index.php?view=product" class="btn btn-default">Cancel</a>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</section>