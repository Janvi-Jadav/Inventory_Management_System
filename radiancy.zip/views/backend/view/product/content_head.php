<?php

$view_mode = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : 'list';
$filter = (isset($_GET['filter']) && $_GET['filter'] != '') ? $_GET['filter'] : 'active';
$item_per_page = 10;

if (!checkPermition('product_managment')) {
	FlashMessage::set('Page not allowed to Access', 'error');
	redirect('/index.php');
}

$data['page'] = 'product_managment';
$data['sub_page'] = 'product';

if ($view_mode == 'list') {
	if ($filter == 'active') {
		$products = Product::where('is_active', 1)->orderBy('id', 'DESC')->get();
	} else {
		$products = Product::where('is_active', 0)->orderBy('id', 'DESC')->get();
	}
}

if ($view_mode == 'enable') {
	$p_id  = get_form_value('p_id');
	$p = Product::find($p_id);
	$p->is_active = 0;
	$p->save();
	FlashMessage::set('Product Has Been Disabled', 'success');
	redirect($_SERVER['HTTP_REFERER'], 'full');
}

if ($view_mode == 'disable') {
	$p_id  = get_form_value('p_id');
	$p = Product::find($p_id);
	$p->is_active = 1;
	$p->save();
	FlashMessage::set('Product Has Been Enable', 'success');
	redirect($_SERVER['HTTP_REFERER'], 'full');
}

// if ($view_mode == 'edit') {
// 	$id  = get_form_value('size_id');
// 	$edit_size = Size::find($id);

// 	if ($filter == 'active') {
// 		$sizes = Size::where('is_active', 1)->orderBy('id', 'DESC')->get();
// 	} else {
// 		$sizes = Size::where('is_active', 0)->orderBy('id', 'DESC')->get();
// 	}
// }
