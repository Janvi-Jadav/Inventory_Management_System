<script>
  function openLink(page) {
    if (page == 'user') {
      location.href = '<?php echo $config['site_url']; ?>/index.php?view=master_users';
    }
    if (page == 'party') {
      location.href = '<?php echo $config['site_url']; ?>/index.php?view=party&action=new';
    }
    if (page == 'product') {
      location.href = '<?php echo $config['site_url']; ?>/index.php?view=product';
    }
    if (page == 'product_stock') {
      location.href = '<?php echo $config['site_url']; ?>/index.php?view=product_stock';
    }
    if (page == 'purchase') {
      location.href = '<?php echo $config['site_url']; ?>/index.php?view=purchase&action=new';
    }

    if (page == 'sales') {
      location.href = '<?php echo $config['site_url']; ?>/index.php?view=sales&action=new';
    }
  }
</script>
<style>
  .box.collapsed-box {
    border-top: none;
  }

  .dashboard.img-responsive {
    width: 15%;
  }

  /* .modal-dialog #product_modal {
    width: fit-content;
  } */
</style>