<!-- <section class="content-header">
  <div class="row">
    <div class="col-lg-5">
      <h3>Dashboard</h3>
    </div>
  </div>
</section> -->
<section class="content">
  <div class="row">
    <?php if ($user_type == 'admin') {
      require_once('content_admin.php');
    } elseif ($user_type == 'master_admin') {
      require_once('content_master_admin.php');
    } ?>
  </div>
</section>