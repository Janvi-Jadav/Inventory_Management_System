<?php

use Carbon\Carbon;

$user_type = getSessionUserType();

$totalParty = Party::where('is_active', 1)->count();
$totalProduct = Product::where('is_active', 1)->count();
$currentStock = Product::where('is_active', 1)->sum('curr_stock');
$totalPurchaseBill = Purchase::where('is_active', 1)->count();
$totalSalesBill = Sales::where('is_active', 1)->count();
