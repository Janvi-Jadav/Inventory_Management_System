<?php
include('view/' . $view_folder . '/content_head.php');
?>
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $config['site_name']; ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="icon" type="image/x-icon" href="<?php echo $config['site_url']; ?>/images/fevicon.png" />

  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/bower_components/bootstrap/dist/css/bootstrap.min.css'; ?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/bower_components/font-awesome/css/font-awesome.min.css'; ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/bower_components/Ionicons/css/ionicons.min.css'; ?>">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css'; ?>">

  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/dist/css/AdminLTE.min.css'; ?>">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/dist/css/skins/_all-skins.min.css'; ?>">
  <!-- Morris chart -->
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/bower_components/morris.js/morris.css'; ?>">
  <!-- jvectormap -->
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/bower_components/jvectormap/jquery-jvectormap.css'; ?>">
  <!-- Date Picker -->
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css'; ?>">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/bower_components/bootstrap-daterangepicker/daterangepicker.css'; ?>">
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/plugins/iCheck/all.css'; ?>">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="<?php echo $config['site_url'] . '/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css'; ?>">

  <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">

  <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/buttons/1.5.6/css/buttons.dataTables.min.css">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <style type="text/css">
    .inline {
      display: inline;
    }

    .product_table th {
      padding: 5px;
      border: 1px solid #ccc;
    }

    .product_table td {
      padding: 5px;
      border: 1px solid #ccc;
      min-width: 70px;
    }

    .img-responsive {
      width: 100%;
      max-width: 100%;
    }

    .dashboard.img-responsive {
      width: 40%;
      max-width: 100%;
    }

    .select2-container--default .select2-selection--single,
    .select2-selection .select2-selection--single {
      height: 34px !important;
    }

    .info-box {
      text-align: center;
    }

    .nav-tabs-custom>.nav-tabs>li.active>a {
      background: #3c8dbc;
      color: #fff;
      font-weight: 600;
    }

    .nav-tabs-custom>.nav-tabs>li {
      border-top: none;
    }

    li.page-item-box {
      line-height: 35px;
    }

    .current_page {
      line-height: 25px;
      border-radius: 3px;
      text-align: center;
    }
  </style>
  <!-- jQuery 3 -->
  <script src="<?php echo $config['site_url'] . '/bower_components/jquery/dist/jquery.min.js'; ?>"></script>
  <script>
    $(document).ready(function() {
      $('.select2').select2();


      <?php if ($is_loader == 'show') { ?>
        $(document).ajaxStart(function() {
          $('.loader').show();
        });
        $(document).ajaxComplete(function() {
          $('.loader').hide();
        });
      <?php } ?>

      if ($(window).width() < 600) {
        $("[id=scan_code]").attr('inputmode', 'none');
      } else {
        $("[id=scan_code]").prop("inputmode", 'none');
      }

    });
  </script>
</head>

<body class="hold-transition skin-blue sidebar-mini">
  <div class="loader">
    <div class="m-loader"></div>
  </div>
  <div class="wrapper">
    <header class="main-header">
      <?php if ($simple_display_mode != 1) { ?>
        <!-- Logo -->
        <a href="#" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini">
            <img src="<?php echo $config['site_url'] . '/images/large-logo.png'; ?>" class="img img-responsive" style="width: 100%">
          </span>
          <!-- logo for regular state and mobile devices -->
          <span class=" logo-lg"><b><?php echo $config['site_name']; ?></b></span>
        </a>
      <?php } ?>
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <?php if (isset($simple_display_mode) || !$simple_display_mode) { ?>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <!-- custom naviagation menu -->
          <?php include('custom_navigation.php'); ?>
          <!-- end custom navigation menu -->
        </nav>
      <?php } ?>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <?php
    if (!isset($simple_display_mode) || !$simple_display_mode) { ?>
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->

          <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo $config['site_url'] . '/dist/img/user2-160x160.jpg'; ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p>Hi <?php echo $user_name; ?></p>
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
          <?php include('sidebar.php'); ?>
        </section>
        <!-- /.sidebar -->
      </aside>
    <?php } ?>
    <div class="content-wrapper">
      <?php include('view/' . $view_folder . '/content_header.php'); ?>
      <?php include('view/' . $view_folder . '/content.php'); ?>
      <div id="notify" class="modal fade" role="dialog">
        <div class="modal-dialog modal-md">
          <div class="modal-content">
            <div class="modal-header" style="padding: 10px;">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">You Have New Order</h4>
            </div>
            <div class="modal-footer" style="padding: 10px;text-align: left;">
              <button class="btn btn-sm btn-primary" id="remove_order_itm">Yes</button>
            </div>
          </div>
        </div>
      </div>
      <div id="sesion_popup" class="modal fade" role="dialog">
        <div class="modal-dialog  modal-dialog-centered modal-md">
          <div class="modal-content">
            <div class="modal-header" style="padding: 10px;">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Are you sure want to redirect page ?</h4>
            </div>
            <div class="modal-footer" style="padding: 10px;text-align: left;">
              <button class="btn btn-lg btn-primary" onclick="Clickyes()">YES</button>
              <button class="btn btn-lg btn-secondary" onclick="Clickno()">NO</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <footer class="main-footer">
      <div class="pull-right hidden-xs">
        <b>Version</b> <?php echo $config['site_version']; ?>
      </div>
      Developed By <a href="https://hitechmorbi.in/" target="_blank">Hi-Tech Computer</a>
    </footer>
    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
  </div>
  <!-- ./wrapper -->
  <!-- jQuery 3 -->
  <!-- <script src="<?php echo $config['site_url'] . '/bower_components/jquery/dist/jquery.min.js'; ?>"></script> -->
  <!-- jQuery UI 1.11.4 -->
  <script src="<?php echo $config['site_url'] . '/bower_components/jquery-ui/jquery-ui.min.js'; ?>"></script>
  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
  <script>
    $.widget.bridge('uibutton', $.ui.button);
  </script>
  <!-- Bootstrap 3.3.7 -->
  <script src="<?php echo $config['site_url'] . '/bower_components/bootstrap/dist/js/bootstrap.min.js'; ?>"></script>
  <script src="<?php echo $config['site_url'] . '/bower_components/chart.js/Chart.js'; ?>"></script>
  <!-- DataTables -->
  <script src="<?php echo $config['site_url'] . '/bower_components/datatables.net/js/jquery.dataTables.min.js'; ?>"></script>
  <script src="<?php echo $config['site_url'] . '/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js'; ?>"></script>
  <!-- Morris.js charts -->
  <script src="<?php echo $config['site_url'] . '/bower_components/raphael/raphael.min.js'; ?>"></script>
  <script src="<?php echo $config['site_url'] . '/bower_components/morris.js/morris.min.js'; ?>"></script>
  <!-- Sparkline -->
  <script src="<?php echo $config['site_url'] . '/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js'; ?>"></script>
  <!-- jvectormap -->
  <script src="<?php echo $config['site_url'] . '/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js'; ?>"></script>
  <script src="<?php echo $config['site_url'] . '/plugins/jvectormap/jquery-jvectormap-world-mill-en.js'; ?>"></script>
  <!-- jQuery Knob Chart -->
  <script src="<?php echo $config['site_url'] . '/bower_components/jquery-knob/dist/jquery.knob.min.js'; ?>"></script>
  <!-- daterangepicker -->
  <script src="<?php echo $config['site_url'] . '/bower_components/moment/min/moment.min.js'; ?>"></script>
  <script src="<?php echo $config['site_url'] . '/bower_components/bootstrap-daterangepicker/daterangepicker.js'; ?>"></script>
  <!-- datepicker -->
  <script src="<?php echo $config['site_url'] . '/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js'; ?>"></script>
  <!-- iCheck 1.0.1 -->
  <script src="<?php echo $config['site_url'] . '/plugins/iCheck/icheck.min.js'; ?>"></script>
  <!-- Bootstrap WYSIHTML5 -->
  <script src="<?php echo $config['site_url'] . '/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js'; ?>"></script>
  <!-- Slimscroll -->
  <script src="<?php echo $config['site_url'] . '/bower_components/jquery-slimscroll/jquery.slimscroll.min.js'; ?>"></script>
  <!-- FastClick -->
  <script src="<?php echo $config['site_url'] . '/bower_components/fastclick/lib/fastclick.js'; ?>"></script>
  <!-- AdminLTE App -->
  <script src="<?php echo $config['site_url'] . '/dist/js/adminlte.min.js'; ?>"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <!-- <script src="dist/js/pages/dashboard.js"></script> -->
  <!-- AdminLTE for demo purposes -->
  <script src="<?php echo $config['site_url'] . '/dist/js/demo.js'; ?>"></script>
  <!-- Page script -->
  <script>
    $(function() {
      //iCheck for checkbox and radio inputs
      $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
        checkboxClass: 'icheckbox_minimal-blue',
        radioClass: 'iradio_minimal-blue'
      })
      //Red color scheme for iCheck
      $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
        checkboxClass: 'icheckbox_minimal-red',
        radioClass: 'iradio_minimal-red'
      })
      //Flat red color scheme for iCheck
      $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
        checkboxClass: 'icheckbox_flat-green',
        radioClass: 'iradio_flat-green'
      })
    })
  </script>
  <script>
    $(function() {
      $('#example1').DataTable({
        lengthMenu: [
          [100, 250, 500],
          [100, 250, 500],
        ],
      });

    })
  </script>
  <script>
    $(function() {
      //Add text editor
      $(".textareaediter").wysihtml5();
    });
  </script>
  <script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css">

  <link href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/toasty.css" rel="stylesheet" />
  <script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/toasty.js"></script>
  <link href="<?php echo $config['site_url'] . '/dist/select2/select2.min.css'; ?>" rel="stylesheet" />
  <script src="<?php echo $config['site_url'] . '/dist/select2/select2.min.js'; ?>"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('.select2').select2();
    });
  </script>
  <!-- InputMask -->
  <script src="<?php echo $config['site_url']; ?>/plugins/input-mask/jquery.inputmask.js"></script>
  <script src="<?php echo $config['site_url']; ?>/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
  <script src="<?php echo $config['site_url']; ?>/plugins/input-mask/jquery.inputmask.extensions.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('[data-mask]').inputmask();
      $('[data-dates]').datepicker({
        autoclose: true
      })
    });
  </script>
  <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.flash.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('.table_data_table1').DataTable({
        dom: 'Bfrtip',
        buttons: [
          'excel', 'pdf', 'print'
        ]
      });
      $('.table_data_table').DataTable();
      $('.datepicker').datepicker({
        autoclose: true
      });
    });
  </script>
  <?php include('view/' . $view_folder . '/content_footer.php'); ?>
  <style>
    .toast-container--fade {

      top: 0;
      bottom: auto;
    }
  </style>
  <script type="text/javascript">
    var options = {
      autoClose: true,
      duration: 1000,
      progressBar: true,
      enableSounds: true,
      sounds: {
        info: "https://res.cloudinary.com/dxfq3iotg/video/upload/v1557233294/info.mp3",
        // path to sound for successfull message:
        success: '<?php echo $config['site_url']; ?>/uploads/sound/success.mp3',
        // path to sound for warn message:
        warning: '<?php echo $config['site_url']; ?>/uploads/sound/warning.mp3',
        // path to sound for error message:
        // error: "https://res.cloudinary.com/dxfq3iotg/video/upload/v1557233574/error.mp3",
        error: '<?php echo $config['site_url']; ?>/uploads/sound/error_2.mp3',
      },
      position: "left",
    };
    var toastr = new Toasty(options);
    toastr.configure(options);
    <?php if (isset($_SESSION['flash'])) {
      if (isset($_SESSION['flash']['type'])) {  ?>
        var type = "<?php echo (isset($_SESSION['flash']['type'])) ? $_SESSION['flash']['type'] : 'info' ?>";
        switch (type) {
          case 'info':
            //toastr.info("<?php echo $_SESSION['flash']['message'] ?>");
            toastr.info("<?php echo $_SESSION['flash']['message'] ?>");
            break;
          case 'warning':
            //toastr.warning("<?php echo $_SESSION['flash']['message'] ?>");
            toastr.warning("<?php echo $_SESSION['flash']['message'] ?>");
            break;
          case 'success':
            //toastr.success("<?php echo $_SESSION['flash']['message'] ?>");
            toastr.success("<?php echo $_SESSION['flash']['message'] ?>");
            break;
          case 'error':
            //toastr.error("<?php echo $_SESSION['flash']['message'] ?>");
            toastr.error("<?php echo $_SESSION['flash']['message'] ?>");
            break;
        }
        <?php } else {
        if (is_array($_SESSION['flash']) && count($_SESSION['flash']) > 0 && $_SESSION['flash'] != '') {
          foreach ($_SESSION['flash'] as $flash) {
            $rno = rand(123, 999);
        ?>
            var type_<?php echo $rno; ?> = "<?php echo (isset($flash['type'])) ? $flash['type'] : 'info'; ?>";
            switch (type_<?php echo $rno; ?>) {
              case 'info':
                //toastr.info("<?php echo $flash['message'] ?>");
                toastr.info("<?php echo $flash['message'] ?>");
                break;
              case 'warning':
                //toastr.warning("<?php echo $flash['message'] ?>");
                toastr.warning("<?php echo $flash['message'] ?>");
                break;
              case 'success':
                //toastr.success("<?php echo $flash['message'] ?>");
                toastr.success("<?php echo $flash['message'] ?>");
                break;
              case 'error':
                //toastr.error("<?php echo $flash['message'] ?>");
                toastr.error("<?php echo $flash['message'] ?>");
                break;
            }
      <?php }
        }
      }
      ?>
    <?php unset($_SESSION['flash']);
    } ?>
  </script>
  <script type="text/javascript">
    function syntaxHighlight(json) {
      json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
      return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function(match) {
        var cls = 'number';
        if (/^"/.test(match)) {
          if (/:$/.test(match)) {
            cls = 'key';
          } else {
            cls = 'string';
          }
        } else if (/true|false/.test(match)) {
          cls = 'boolean';
        } else if (/null/.test(match)) {
          cls = 'null';
        }
        return '<span class="' + cls + '">' + match + '</span>';
      });
    }

    function checkFieldError(checkField, dspId, msg, isnumber = '') {
      if (checkField == '') {
        toastr.error(msg);
        $('#' + dspId).focus();
        $('#' + dspId).css("border", "1px solid red");
        return 1;
      } else {
        if (isnumber != '') {
          if (!$.isNumeric(checkField)) {
            toastr.error(msg + ' in Numeric');
            $('#' + dspId).focus();
            $('#' + dspId).css("border", "1px solid red");
            return 1;
          } else {
            $('#' + dspId).css("border", "1px solid #d2d6de");
            return 0;
          }

        } else {
          $('#' + dspId).css("border", "1px solid #d2d6de");
          return 0;
        }
      }
    }

    function checkFieldIsNumer(checkField, dspId, msg) {
      if (!$.isNumeric(checkField)) {
        toastr.error(msg);
        $('#' + dspId).focus();
        $('#' + dspId).css("border", "1px solid red");
        return 1;
      } else {
        $('#' + dspId).css("border", "1px solid #d2d6de");
        return 0;
      }
    }

    $(document).on('click', '#remove_order_itm', function() {
      var formData = {
        action: 'order',
        method: 'removenotify'
      }; //Array
      $.ajax({
        url: "<?php echo $config['ajax_url'] ?>",
        type: "POST",
        data: formData,
        global: false,
        success: function(data, textStatus, jqXHR) {
          data = JSON.parse(data);
          if (data.type == 'success') {
            $('#notify').modal('toggle');
          }
        },
      });
    });

    $(document).on('change', '#scan_code', function() {
      var audio = new Audio('<?php echo $config['site_url']; ?>/uploads/sound/warning.mp3');
      audio.play();
    });

    $(document).on('change', '#manual_scan_code', function() {
      var audio = new Audio('<?php echo $config['site_url']; ?>/uploads/sound/warning.mp3');
      audio.play();
    });
    <?php if ($is_check_login == 'check') { ?>
      setInterval(function() {
        var formData = {
          action: 'check_login'
        }; //Array
        $.ajax({
          url: "<?php echo $config['ajax_url'] ?>",
          type: "POST",
          data: formData,
          global: false,
          success: function(data, textStatus, jqXHR) {
            data = JSON.parse(data);
            if (data.type == 'success') {
              if (data.status == 1) {
                location.href = '<?php echo $config['site_url']; ?>/index.php';
              }
            }
          },
        });
      }, 1000 * 60 * 1); // where X is your every X minutes
    <?php } ?>
    <?php
    $shop_id = null;
    $user_type = getSessionUserType();
    if ($user_type != 'master_admin') {
      $shop_id = getSessionUserID();
    }
    $order_count = 0;
    if ($order_count > 0) { ?>
      $('#notify').modal('toggle');
    <?php }
    ?>
  </script>
</body>

</html>