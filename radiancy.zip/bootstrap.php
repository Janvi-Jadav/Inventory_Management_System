<?php
ini_set('max_execution_time', -1);
ob_start();
@session_start();
date_default_timezone_set('Asia/Kolkata');
require_once('config.php');
require "vendor/autoload.php";
$config                    = array();
$config['site_url']        = $sit_url;
$config['site_name']       = 'RADIANCY ENTERPRISE';
$config['form_action_url'] = $config['site_url'] . '/form_action';
$config['ajax_url']        = $config['site_url'] . '/ajax/ajax.php';
$config['image_dir']        = 'uploads';
$config['doc_rt_url']        = $doc_rt_url;
$config['server_host'] = $server_host;
$config['server_db'] = $server_db;
$config['server_user'] = $server_user;
$config['server_pass'] = $server_pass;
$config['sender_email'] = 'email@ourbulkshop.com';
$config['sender_name'] = 'Delivermyvape.co.uk';
$config['currency'] = '&#x20b9;';
$config['site_version'] = '0.0.2';
$simple_display_mode = 0;
$main_root_path = $doc_rt_url;
global $user_name, $user_email, $user_contact_no, $user_type, $parent_admin_user_id;
$is_loader = 'show'; //show || hide
$is_check_login = 'check'; //check || skip
$is_session_clear = 'on'; //on for active clear session | off for deactive
include_once $main_root_path . "/class/Auth.php";
if (!isset($db_mode)) {
  if (!preg_match('/login\.php/', $_SERVER['REQUEST_URI'])) {
    Auth::check_login();
  }
}

use Illuminate\Database\Capsule\Manager as Capsule;

$capsule = new Capsule;
$capsule->addConnection([
  "driver"   => "mysql",
  "host"     => $server_host,
  "database" => $server_db,
  "username" => $server_user,
  "password" => $server_pass,
]);
$capsule->setAsGlobal();
$capsule->bootEloquent();

include_once $main_root_path . "/assets/phpqrcode/qrlib.php";
include_once $main_root_path . "/Functions/site_functions.php";
include_once $main_root_path . "/class/Crontab.php";
include_once $main_root_path . "/class/SidebarMenu.php";
include_once $main_root_path . "/class/FlashMessage.php";
include_once $main_root_path . "/class/GneratePDF.php";
include_once $main_root_path . "/class/BarcodeGenerate.php";
include_once($main_root_path . "/newfpdf/fpdf.php");
include_once($main_root_path . "newfpdf/pdf-with-table/easyTable.php");
include_once($main_root_path . "newfpdf/pdf-with-table/exfpdf.php");
include_once($main_root_path . "newfpdf/pdf-with-table/formatedstring.php");
$currency_icon = getCurrency();



$master_admin_permissions = array('product_managment', 'party_managment', 'purchase_managment', 'sales_managment');

$shop_permission_list = array();

$shop_user_permission_list = array();

asort($master_admin_permissions);
asort($shop_permission_list);
asort($shop_user_permission_list);
