<?php

use Illuminate\Support\Str;

function getSessionUserID()
{
  //return (isset($_SESSION['user_data']['user_id']) && $_SESSION['user_data']['user_id'] != '' ? $_SESSION['user_data']['user_id'] : '');
  return (isset($_SESSION['shop_user_id']) && $_SESSION['shop_user_id'] != '' ? $_SESSION['shop_user_id'] : '');
}

function getSessionLoginUserID()
{
  return (isset($_SESSION['user_data']['user_id']) && $_SESSION['user_data']['user_id'] != '' ? $_SESSION['user_data']['user_id'] : '');
}

function getSessionUserType()
{
  return (isset($_SESSION['user_data']['user_type']) && $_SESSION['user_data']['user_type'] != '' ? $_SESSION['user_data']['user_type'] : '');
}
function getCurrency()
{
  $c = '&#x20b9;';
  return $c;
}

function getvar($var)
{
  return ($var != null) ? $var : '';
}

function clean($string)
{
  return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
}

function redirect($url, $full_url = '')
{
  global $config;
  if ($full_url == '') {
    header('Location:' . $config['site_url'] . $url);
  } else {
    header('Location:' . $url);
  }
  die;
}

function get_form_value($name)
{

  if (isset($_REQUEST[$name]) && $_REQUEST[$name] != '') {
    return $_REQUEST[$name];
  } else {
    return null;
  }
}
function checkPermition($permition)
{
  $user_id    = $_SESSION['user_data']['user_id'];
  $check_perm = Permission::where(array('user_id' => $user_id, 'permission' => $permition, 'is_active' => 1))->first();
  if ($check_perm == null) {
    return false;
  } else {
    return true;
  }
}

function searchForId($id, $array, $keys)
{
  foreach ($array as $key => $val) {
    if ($val[$keys] == $id) {
      return $key;
    }
  }
  return 'add';
}
function reArrayFiles(&$file_post)
{
  $file_ary   = array();
  $file_count = count($file_post['name']);
  $file_keys  = array_keys($file_post);
  for ($i = 0; $i < $file_count; $i++) {
    foreach ($file_keys as $key) {
      $file_ary[$i][$key] = $file_post[$key][$i];
    }
  }
  return $file_ary;
}
function getLast24Month()
{
  for ($i = 0; $i < 12; $i++) {
    $months[] = date("Y-m", strtotime(date('Y-m-01') . " -$i months"));
  }
  return array_reverse($months);
}
function getColor($k)
{
  $color    = array();
  $color[0] = array('r' => 60, 'g' => 141, 'b' => 188);
  $color[1] = array('r' => 210, 'g' => 214, 'b' => 222);
  $color[2] = array('r' => 245, 'g' => 105, 'b' => 84);
  $color[3] = array('r' => 0, 'g' => 166, 'b' => 90);
  $color[4] = array('r' => 0, 'g' => 192, 'b' => 239);
  $color[5] = array('r' => 145, 'g' => 135, 'b' => 31);

  if (array_key_exists($k, $color)) {
    $final_rgbColor = $color[$k];
  } else {
    $rgbColor = array();
    foreach (array('r', 'g', 'b') as $color) {
      $rgbColor[$color] = mt_rand(0, 255);
    }
    $final_rgbColor = $rgbColor;
  }
  return $final_rgbColor;
}
function searchArray($id, $array, $key_name = null)
{

  if ($key_name == null) {
    $key_name = 'product_id';
  }
  foreach ($array as $key => $val) {
    if ($val[$key_name] == $id) {
      return $key;
    }
  }
  return 'add';
}
function array_key_max_value($array, $key_name)
{

  $max = null;

  $result = null;

  foreach ($array as $key => $value) {

    if ($max === null || $value[$key_name] > $max) {

      $result = $key;

      $max = $value[$key_name];
    }
  }

  return $result;
}
function get_float_num($num)
{
  return number_format($num, 2);
}
function CheckYearFormat($year)
{
  $rtn = 0;
  $data = explode('-', $year);
  //dd($data[0]);
  if (isset($data[0]) && $data[0] != null && isset($data[1]) && $data[1] != null) {
    $rtn = 1;
  }
  return $rtn;
}
function csvToArrayByPath($path)
{
  $importData_arr = array();

  if (file_exists($path)) {
    $file = fopen($path, "r");
    $i = 0;

    while (($file_data = fgetcsv($file)) !== FALSE) {
      $num = count($file_data);
      if ($i == 0) {
        $i++;
        continue;
      }
      for ($c = 0; $c < $num; $c++) {
        $fls = excelAllProductRowtoArray($file_data);
        $error_list = validateImportCsvData($i, $fls);
        if (count($error_list) > 0) {
          $fls['error_msg'] = $error_list;
        }
        $importData_arr[$i] = $fls;
      }
      $i++;
    }
    fclose($file);
  }
  return $importData_arr;
}
function excelAllProductRowtoArray($data)
{
  $rtn = [];
  if (isset($data) && count($data) > 0) {
    $rtn['category'] = trim($data[0]);
    $rtn['brand'] = trim($data[1]);
    $rtn['product'] = trim($data[2]);
    $rtn['mrp'] = (float)trim($data[3]);
    $rtn['unit_price'] = (float)trim($data[4]);
    $rtn['minimum_qty'] = (float)trim($data[5]);
    $rtn['wr_to_shop_send_qty'] = (float)trim($data[6]);
    $rtn['group'] = trim($data[7]);
    $rtn['images'] = trim($data[8]);
    $rtn['barcode'] = trim($data[9]);
    $rtn['active'] = trim($data[10]);
    $rtn['new_name'] = trim($data[11]);
  }
  return $rtn;
}
function validateImportCsvData($row, $dt)
{
  $error = [];

  if ($dt['category'] == null) {
    $error[] = ['type' => 'empty', 'msg' => 'Row ' . $row . ' -> Missing Category In Excel'];
    //$error[] = array('type'=>'error', 'msg'=>'Row '.$row.' -> Missing Category In Excel');
  }
  if ($dt['brand'] == null) {
    //$error[] = 'Row '.$row.' -> Missing Brand In Excel';
    $error[] = ['type' => 'empty', 'msg' => 'Row ' . $row . ' -> Missing Brand In Excel'];
    //$error[] = array('type'=>'error', 'msg'=>'Row '.$row.' -> Missing Brand In Excel');
  }
  if ($dt['product'] == null) {
    //$error[] = 'Row '.$row.' -> Missing Product In Excel';
    $error[] = ['type' => 'empty', 'msg' => 'Row ' . $row . ' -> Missing Product In Excel'];
    //$error[] = array('type'=>'error', 'msg'=>'Row '.$row.' -> Missing Product In Excel');
  }
  if ($dt['group'] == null) {
    //$error[] = 'Row '.$row.' -> Missing Product In Excel';
    $error[] = ['type' => 'empty', 'msg' => 'Row ' . $row . ' -> Missing Group In Excel'];
    //$error[] = array('type'=>'error', 'msg'=>'Row '.$row.' -> Missing Product In Excel');
  }
  if ($dt['mrp'] == null && $dt['mrp'] == 0) {
    //$error[] = 'Row '.$row.' -> Missing MRP In Excel';
    $error[] = ['type' => 'empty', 'msg' => 'Row ' . $row . ' -> Missing MRP In Excel'];
    //$error[] = array('type'=>'error', 'msg'=>'Row '.$row.' -> Missing MRP In Excel');
  }
  if ($dt['unit_price'] == null && $dt['unit_price'] == 0) {
    //$error[] = 'Row '.$row.' -> Missing Unit Price In Excel';
    $error[] = ['type' => 'empty', 'msg' => 'Row ' . $row . ' -> Missing Unit Price In Excel'];
    //$error[] = array('type'=>'error', 'msg'=>'Row '.$row.' -> Missing Unit Price In Excel');
  }

  //dd($error);
  if (count($error) <= 0) {
    $pdr = Product::checkProductExiest($dt);
    if ($pdr != null) {
      Product::ImageUploader($pdr->id, $dt);
    }
  }
  return $error;
}

function validateAllProductImport($check_typem, $row, $dt)
{
  $error = [];
  if ($dt['category'] == null) {
    $error[] = ['type' => 'empty', 'msg' => 'Row ' . $row . ' -> Missing Category In Excel'];
  }
  if ($dt['brand'] == null) {
    $error[] = ['type' => 'empty', 'msg' => 'Row ' . $row . ' -> Missing Brand In Excel'];
  }
  if ($dt['group'] == null) {
    $error[] = ['type' => 'empty', 'msg' => 'Row ' . $row . ' -> Missing Group In Excel'];
  }
  /* if($dt['flavour'] == null){
    $error[] = ['type'=>'empty','msg'=>'Row '.$row.' -> Missing Flavour In Excel'];
  }  */
  if ($check_typem == 'new_row') {
    if ($dt['product_new_name'] == null) {
      $error[] = ['type' => 'empty', 'msg' => 'Row ' . $row . ' -> Missing Product New Name In Excel'];
    } else {
      $product = Product::getProductByName($dt['product_new_name']);
      if ($product != null) {
        $error[] = ['type' => 'empty', 'msg' => 'Row ' . $row . ' -> Product Name Already Exists'];
      }
    }
  } else {
    if ($dt['product_name'] == null) {
      $error[] = ['type' => 'empty', 'msg' => 'Row ' . $row . ' -> Missing Product Name In Excel'];
    }
  }
  //name exists check
  if ($dt['mrp'] == null || $dt['mrp'] == 0) {
    $error[] = ['type' => 'empty', 'msg' => 'Row ' . $row . ' -> Missing MRP In Excel'];
  }
  if ($dt['unit_price'] == null || $dt['unit_price'] == 0) {
    $error[] = ['type' => 'empty', 'msg' => 'Row ' . $row . ' -> Missing Unit Price In Excel'];
  }
  /* if($dt['minimum_qty'] == null && $dt['minimum_qty'] == 0){
    $error[] = ['type'=>'empty','msg'=>'Row '.$row.' -> Missing Minimum qty In Excel'];
  } */
  /* if($dt['wr_to_shop_send_qty'] == null && $dt['wr_to_shop_send_qty'] == 0){
    $error[] = ['type'=>'empty','msg'=>'Row '.$row.' -> Missing Wr to Shop Send Qty In Excel'];
  } */
  /* if($dt['images'] == null && $dt['images'] == 0){
    $error[] = ['type'=>'empty','msg'=>'Row '.$row.' -> Missing Images In Excel'];
  }
  if($dt['barcode'] == null && $dt['barcode'] == 0){
    $error[] = ['type'=>'empty','msg'=>'Row '.$row.' -> Missing Barcode In Excel'];
  }
  if($dt['active'] == null && $dt['active'] == 0){
    $error[] = ['type'=>'empty','msg'=>'Row '.$row.' -> Missing Active In Excel'];
  }*/
  return $error;
}


function getnewBillQRQty($prd_id, $type, $prd_type)
{
  $session = $_SESSION[$type];

  $sesssion_qty = 0;
  if ($session != '') {
    $key = getnewBillQRKey($prd_id, $session, $prd_type);
    if (count($key) > 0) {
      foreach ($key as $k) {
        $sesssion_qty += $session[$k]['qty'];
      }
    }
  }
  return $sesssion_qty;
}

function getnewBillQRKey($prd_id, $sesssion_data, $prd_type)
{
  $chk_arrr = [];
  if (isset($sesssion_data) && $sesssion_data != '') {
    foreach ($sesssion_data as $key => $val) {
      if ($val['itm_id'] == $prd_id && $val['p_type'] == $prd_type) {
        $chk_arrr[] = $key;
      }
    }
  }
  return $chk_arrr;
}

function getBillQRQty($prd_id, $type)
{
  $session = $_SESSION[$type];

  $sesssion_qty = 0;
  if ($session != '') {
    $key = getBillQRKey($prd_id, $session);
    if (count($key) > 0) {
      foreach ($key as $k) {
        $sesssion_qty += $session[$k]['qty'];
      }
    }
  }
  return $sesssion_qty;
}

function getExchangeQRQty($prd_id, $session, $type)
{
  $session = $_SESSION[$session];

  $sesssion_qty = 0;
  if ($session != '') {
    $key = getBillQRKey($prd_id, $session);
    if (count($key) > 0) {
      foreach ($key as $k) {
        if ($session[$k]['type'] == $type) {
          $sesssion_qty += $session[$k]['qty'];
        }
      }
    }
  }
  return $sesssion_qty;
}

function getStockUpdate($prd_id, $type)
{
  $session = $_SESSION[$type];

  $sesssion_qty = 0;
  if ($session != '') {
    $key = getBillQRKey($prd_id, $session);
    if (count($key) > 0) {
      foreach ($key as $k) {
        $sesssion_qty += $session[$k]['update_stock'];
      }
    }
  }
  return $sesssion_qty;
}

function shopQuickOrderPDAShort($session_data)
{
  $short_itm_arr = array_unique(array_column($session_data, 'itm_id'));
  $final_array = array();
  foreach ($short_itm_arr as $itm_id) {
    $tmp = array();
    foreach ($_SESSION['shop_quick_order_pda_cron'] as $k => $s) {
      if ($s['itm_id'] == $itm_id) {
        $order_qty = (isset($tmp['order_qty']) && $tmp['order_qty'] != '' ? $tmp['order_qty'] : 0);
        $code = $s['barcode'];
        $qty = $s['qty'];

        $tmps = array();
        $tmps['code'] = $code;
        $tmps['qty'] = $qty;
        $tmp['scan_start'] = $s['scan_start'];
        $tmp['scan_end'] = $s['scan_end'];
        $tmp['skip_id'] = null;
        $tmp['product_id'] = $s['itm_id'];
        $tmp['itm'] = $s['itm'];
        $tmp['price'] = $s['price'];
        $tmp['category'] = $s['category'];
        $tmp['order_qty'] = ($order_qty + $qty);
        $tmp['barcode'][] = $tmps;
      }
    }
    $final_array[] = $tmp;
  }
  return $final_array;
}

function getBillQRKey($prd_id, $sesssion_data)
{
  $chk_arrr = [];
  if (isset($sesssion_data) && $sesssion_data != '') {
    foreach ($sesssion_data as $key => $val) {
      if ($val['itm_id'] == $prd_id) {
        $chk_arrr[] = $key;
      }
    }
  }
  return $chk_arrr;
}

function getSessionKey($prd_id, $sesssion_data)
{
  $chk_arrr = -1;
  if (isset($sesssion_data) && $sesssion_data != '') {
    foreach ($sesssion_data as $key => $val) {
      if ($val['itm_id'] == $prd_id) {
        $chk_arrr = $key;
      }
    }
  }
  return $chk_arrr;
}


function getTodayQty($prd_id, $type, $field)
{
  $session = $_SESSION[$type];

  $sesssion_qty = 0;
  if ($session != '') {
    $key = getTodaySessionKey($prd_id, $session);
    if (count($key) > 0) {
      foreach ($key as $k) {
        $sesssion_qty += $session[$k][$field];
      }
    }
  }
  return $sesssion_qty;
}

function getTodaySessionKey($prd_id, $sesssion_data)
{
  $chk_arrr = [];
  if (isset($sesssion_data) && $sesssion_data != '') {
    foreach ($sesssion_data as $key => $val) {
      if ($val['product_id'] == $prd_id) {
        $chk_arrr[] = $key;
      }
    }
  }
  return $chk_arrr;
}

function checkPrefixPostfix($qrcode = null)
{
  global $config;
  if ($qrcode != null) {
    if (substr($qrcode, 0, 2) != $config['pre']) {
      $qrcode = $config['pre'] . $qrcode;
    }
    if (substr($qrcode, -2) != $config['post']) {
      $qrcode = $qrcode . $config['post'];
    }
  }
  return $qrcode;
}

function removePrifixPostfix($qrcode)
{
  global $config;
  $qrcode = trim(str_replace($config['pre'], '', $qrcode));
  $qrcode = trim(str_replace($config['post'], '', $qrcode));
  return $qrcode;
}

function getProductDataFromCode($barcode)
{
  $rtn = ['product' => '', 'type' => ''];
  $shop_id = getSessionUserID();
  if ($barcode != null) {

    $phone = Devices::where(array('shop_id' => $shop_id, 'barcode' => $barcode, 'is_active' => 1))->first();
    if ($phone != null) {
      $rtn['product'] = $phone;
      $rtn['type'] = 'shop_product';
    } else {
      //$barcode = ShopStock_item::with('product')->where(array('barcode'=>$barcode,'shop_id'=>$shop_id))->first();
      $barcode = ProductBarcode::with('product')->where(array('barcode' => $barcode, 'is_active' => 1))->first();
      if ($barcode != null) {
        $rtn['product'] = $barcode->product;
        $rtn['code'] = $barcode->barcode;
        $rtn['type'] = 'warehouse_product';
      }
    }
  }
  return $rtn;
}

function getProductDataForFreeProduct($prd_id)
{
  $rtn = ['product' => '', 'type' => ''];
  $shop_id = getSessionUserID();
  if ($prd_id != null) {

    $barcode = ProductBarcode::with('product')->where(array('pdr_id' => $prd_id, 'is_active' => 1))->orderBy('id', 'DESC')->first();
    if ($barcode != null) {
      $rtn['product'] = $barcode->product;
      $rtn['type'] = 'warehouse_product';
    }
  }
  return $rtn;
}

function getProductListFromCode($barcode)
{
  $rtn = [];
  $shop_id = getSessionUserID();
  if ($barcode != null) {
    $phone = Devices::where('name', 'like', '%' . $barcode . '%')->where(array('shop_id' => $shop_id, 'is_sales' => 0))->select('name', 'barcode')->get();
    if ($phone->count() > 0) {
      foreach ($phone as $ph) {
        $tmp = [];
        $tmp['name'] = $ph->name;
        $tmp['barcode'] = $ph->barcode;
        $rtn[] = $tmp;
      }
    }
    $shop_product = (new SpBillItem($shop_id))::getShopstockItembyName($shop_id, $barcode);
    if ($shop_product != []) {
      $rtn = array_merge($rtn, $shop_product);
    }
  }
  return $rtn;
}


function checkBarcodeExists($barcode)
{
  $rtn = null;
  if ($barcode != null) {
    $rtn = ProductBarcode::CheckExists($barcode);
    if ($rtn == null) {
      //$rtn = BuyProduct::CheckExists($barcode);
      $rtn = BuyPhone::CheckExists($barcode);
    }
  }
  return $rtn;
}


function GetLoginTimeset()
{
  $rtn = 0;
  if (isset($config['login_time']) && $config['login_time'] != 0) {
    $rtn = $config['login_time'];
  }
  return $rtn;
}

function WritetxtFile()
{
  global $config;

  $dir_name = $config['doc_rt_url'] . "/uploads/stockFile";
  if (!file_exists($dir_name)) {
    mkdir($dir_name, 0777, true);
  }
  $file_url = $dir_name . "/stock_update.txt";
  if (!file_exists($file_url)) {
    fopen($file_url, "w");
  }

  if (isset($_SESSION['Stockupdate']) && $_SESSION['Stockupdate'] != '') {
    $data = json_encode($_SESSION['Stockupdate']);
    if (file_exists($file_url)) {
      $myfile = fopen($file_url, "w") or die("Unable to open file!");
      fwrite($myfile, $data);
      fclose($myfile);
    }
  }
}

function EmptyFile()
{
  global $config;
  $dir_name = $config['doc_rt_url'] . "/uploads/stockFile";
  if (!file_exists($dir_name)) {
    mkdir($dir_name, 0777, true);
  }
  $file_url = $dir_name . "/stock_update.txt";
  if (!file_exists($file_url)) {
    fopen($file_url, "w");
  }

  $data = '';
  if (file_exists($file_url)) {
    $myfile = fopen($file_url, "w") or die("Unable to open file!");
    fwrite($myfile, $data);
    fclose($myfile);
  }
}

function ReadtxtFile()
{
  $data = '';
  global $config;
  $dir_name = $config['doc_rt_url'] . "/uploads/stockFile";
  if (!file_exists($dir_name)) {
    mkdir($dir_name, 0777, true);
  }
  $file_url = $dir_name . "/stock_update.txt";
  if (!file_exists($file_url)) {
    fopen($file_url, "w");
  }


  if (file_exists($file_url)) {
    $myfile = fopen($file_url, "r") or die("Unable to open file!");
    if ($myfile && filesize($file_url) > 0) {
      $data = fread($myfile, filesize($file_url));
    }
    fclose($myfile);
    $_SESSION['Stockupdate'] = json_decode($data, true);
  }
}

function SetLocalData()
{
}
function getExchangeSum()
{
  $tmp = array('change' => 0, 'sell' => 0);
  if (isset($_SESSION['Exchange']) && $_SESSION['Exchange'] != '') {

    foreach ($_SESSION['Exchange'] as $dt) {
      if ($dt['type'] == 'change') {
        $tmp['change'] += $dt['qty'];
      } else {
        $tmp['sell'] += $dt['qty'];
      }
    }
  }
  return $tmp;
}
function getPDARedirectLink($url_str)
{
  global $config;
  $get_array = array();

  $url_str = $config['site_url'] . $url_str;

  $url_components = parse_url($url_str);
  $query = (isset($url_components['query']) && $url_components['query'] != '' ? $url_components['query'] : '');
  if ($query != '') {
    parse_str($url_components['query'], $get_array);
    echo $last_key = array_key_last($get_array);;
    $last_value = (end($get_array));

    $shop_id = (isset($_SESSION['sp_id']) && $_SESSION['sp_id'] != '' ? $_SESSION['sp_id'] : '');

    if ($last_value == '' && $shop_id != '') {
      $url_str .= $shop_id;
    }
  }

  return $url_str;
}

function getCancelorderTemplate($order, $name, $note)
{
  global $config;
  $string = '';
  $common = Setting::getSettingByType($type = 'common_mail');
  $image = $config['doc_rt_url'] . 'uploads/logo/logo.png';
  ob_start();
?>
  <!DOCTYPE html>
  <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">

  <head>
    <meta charset="utf-8"> <!-- utf-8 works for most cases -->
    <meta name="viewport" content="width=device-width"> <!-- Forcing initial-scale shouldn't be necessary -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
    <meta name="x-apple-disable-message-reformatting"> <!-- Disable auto-scale in iOS 10 Mail entirely -->
    <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->

    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700" rel="stylesheet">

    <!-- CSS Reset : BEGIN -->
    <style>
      /* What it does: Remove spaces around the email design added by some email clients. */
      /* Beware: It can remove the padding / margin and add a background color to the compose a reply window. */
      html,
      body {
        margin: 0 auto !important;
        padding: 0 !important;
        height: 100% !important;
        width: 100% !important;
        background: #f1f1f1;
      }

      /* What it does: Stops email clients resizing small text. */
      * {
        -ms-text-size-adjust: 100%;
        -webkit-text-size-adjust: 100%;
      }

      /* What it does: Centers email on Android 4.4 */
      div[style*="margin: 16px 0"] {
        margin: 0 !important;
      }

      /* What it does: Stops Outlook from adding extra spacing to tables. */
      table,
      td {
        mso-table-lspace: 0pt !important;
        mso-table-rspace: 0pt !important;
      }

      /* What it does: Fixes webkit padding issue. */
      table {
        border-spacing: 0 !important;
        border-collapse: collapse !important;
        table-layout: fixed !important;
        margin: 0 auto !important;
      }

      /* What it does: Uses a better rendering method when resizing images in IE. */
      img {
        -ms-interpolation-mode: bicubic;
      }

      /* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
      a {
        text-decoration: none;
      }

      /* What it does: A work-around for email clients meddling in triggered links. */
      *[x-apple-data-detectors],
      /* iOS */
      .unstyle-auto-detected-links *,
      .aBn {
        border-bottom: 0 !important;
        cursor: default !important;
        color: inherit !important;
        text-decoration: none !important;
        font-size: inherit !important;
        font-family: inherit !important;
        font-weight: inherit !important;
        line-height: inherit !important;
      }

      /* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
      .a6S {
        display: none !important;
        opacity: 0.01 !important;
      }

      /* What it does: Prevents Gmail from changing the text color in conversation threads. */
      .im {
        color: inherit !important;
      }

      /* If the above doesn't work, add a .g-img class to any image in question. */
      img.g-img+div {
        display: none !important;
      }

      /* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */
      /* Create one of these media queries for each additional viewport size you'd like to fix */

      /* iPhone 4, 4S, 5, 5S, 5C, and 5SE */
      @media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
        u~div .email-container {
          min-width: 320px !important;
        }
      }

      /* iPhone 6, 6S, 7, 8, and X */
      @media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
        u~div .email-container {
          min-width: 375px !important;
        }
      }

      /* iPhone 6+, 7+, and 8+ */
      @media only screen and (min-device-width: 414px) {
        u~div .email-container {
          min-width: 414px !important;
        }
      }
    </style>

    <!-- CSS Reset : END -->

    <!-- Progressive Enhancements : BEGIN -->
    <style>
      .primary {
        background: #17bebb;
      }

      .bg_white {
        background: #ffffff;
      }

      .bg_light {
        background: #f7fafa;
      }

      .bg_black {
        background: #000000;
      }

      .bg_dark {
        background: rgba(0, 0, 0, .8);
      }

      .email-section {
        padding: 0.5em 0.5em 0.2em 1.2em;
      }

      /*BUTTON*/
      .btn {
        padding: 5px 15px;
        display: inline-block;
      }

      .btn.btn-primary {
        border-radius: 5px;
        background: linear-gradient(to bottom, #FF7DB1 0%, #FF1A68 50%, #8900AA 100%);
        color: #ffffff;
      }

      .btn.btn-white {
        border-radius: 5px;
        background: #ffffff;
        color: #000000;
      }

      .btn.btn-white-outline {
        border-radius: 5px;
        background: transparent;
        border: 1px solid #fff;
        color: #fff;
      }

      .btn.btn-black-outline {
        border-radius: 0px;
        background: transparent;
        border: 2px solid #000;
        color: #000;
        font-weight: 700;
      }

      .btn-custom {
        color: rgba(0, 0, 0, .3);
        text-decoration: underline;
      }

      h1,
      h2,
      h3,
      h4,
      h5,
      h6 {
        font-family: 'Poppins', sans-serif;
        color: #000000;
        margin-top: 0;
        font-weight: 400;
      }

      body {
        font-family: 'Poppins', sans-serif;
        font-weight: 600;
        color: #000000a3;
        font-size: 14px;
        line-height: 2.0;
      }

      a {
        color: #17bebb;
      }

      .mytable {
        width: 100%;
        text-align: center;
      }

      .mytable tr td {
        border: 1px solid;
      }

      /*LOGO*/

      .logo h1 {
        margin: 0;
      }

      .logo h1 a {
        color: #17bebb;
        font-size: 24px;
        font-weight: 700;
        font-family: 'Poppins', sans-serif;
      }

      /*HERO*/
      .hero {
        position: relative;
        z-index: 0;
      }

      .hero .text {
        color: rgba(0, 0, 0, .3);
      }

      .hero .text h2 {
        color: #000;
        font-size: 34px;
        margin-bottom: 0;
        font-weight: 200;
        line-height: 1.4;
      }

      .hero .text h3 {
        font-size: 24px;
        font-weight: 300;
      }

      .hero .text h2 span {
        font-weight: 600;
        color: #000;
      }

      .text-author {
        max-width: 85%;
        margin: 0 auto;
        padding: 1em;
      }

      .text-author img {
        border-radius: 50%;
        padding-bottom: 20px;
      }

      .text-author h3 {
        margin-bottom: 0;
      }

      ul.social {
        padding: 0;
      }

      ul.social li {
        display: inline-block;
        margin-right: 10px;
      }

      /*FOOTER*/

      .footer {
        border-top: 1px solid #b106bc;
        color: rgba(0, 0, 0, .5);
      }

      .footer .heading {
        color: #000;
        font-size: 20px;
      }

      .footer ul {
        margin: 0;
        padding: 0;
      }

      .footer ul li {
        list-style: none;
        margin-bottom: 5px;
      }

      .footer ul li a {
        color: rgba(0, 0, 0, 1);
      }

      .text-left {
        float: left;
      }

      .b-0 {
        border: 0px;
        cursor: pointer;
      }

      .mb-5 {
        margin-bottom: 5px;
      }

      .mt-5 {
        margin-top: 5px;
      }
    </style>
  </head>

  <body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #f1f1f1;">
    <center style="width: 100%; background-color: #f1f1f1;">
      <div style="display: none; font-size: 1px;max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden; mso-hide: all; font-family: sans-serif;">
        &zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;
      </div>
      <div style="max-width: 600px; margin: 0 auto;" class="email-container">
        <!-- BEGIN BODY -->
        <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;">
          <tr style="border-bottom: 1px solid #b106bc;">
            <td valign="top" class="bg_white" style="padding: 0em 2.5em 0 2.5em;">
              <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                  <td class="logo" style="text-align: center;">
                    <h2 style="margin:0px;"><img src="<?php echo $image; ?>" alt="" style="width: 50px; max-width: 600px; height: auto; margin: auto; display: block;">
                      <h3 style="margin-bottom:5px;">delivermyvape.co.uk</h3>
                    </h2>
                  </td>
                </tr>
              </table>
            </td>
          </tr><!-- end tr -->
          <tr>
            <td valign="middle" class="hero bg_white">
              <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                  <td style="padding: 0 2.5em; text-align: center;">
                    <div class="text">
                      <h3 style="margin-top: 20px;">Order Cancel</h3>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div class="text-author">
                      <!-- <img src="../images/person_2.jpg" alt="" style="width: 100px; max-width: 600px; height: auto; margin: auto; display: block;"> -->
                      <h3 class="name">Dear <?php echo $name; ?>,</h3><br>


                      <span class="position">

                        Your <b style="color:black;">Order No.<?php echo $order->order_no; ?></b> Has Been Canceled delivermyvape.co.uk<br>

                        <h4 class="name" style="margin-top:20px;margin-bottom:1px;"><b>Order No. </b>: <?php echo $order->order_no; ?></h4>
                        <h4 class="name mb-5"><b>Order Date </b>: <?php echo $order->formatdate; ?></h4>

                        <b>Reason : </b><?php echo $note; ?>

                        <div class="mt-5" style="text-align:center;">
                          <h3 class="name">Order Detail</h3>
                        </div><br>
                        <table class="mytable">
                          <tbody>
                            <tr>
                              <td style="width:60%">Item</td>
                              <td style="width:40%">Amount</td>
                            </tr>
                            <?php foreach ($order->orderitem as $item) {
                              $amount = $item->qty . 'x' . $item->price . ' = ' . get_float_num($item->qty * $item->price);
                            ?>
                              <tr>
                                <td><?php echo $item->product->name; ?></td>
                                <td><?php echo $amount; ?></td>
                              </tr>
                            <?php } ?>
                          </tbody>
                        </table>
                    </div>
                  </td>
                </tr>
              </table>
            </td>
          </tr><!-- end tr -->
          <!-- 1 Column Text + Button : END -->
        </table>
        <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;">
          <tr style=" ">
            <td valign="middle" class="bg_light footer email-section">
              <table>
                <tr>
                  <td valign="top" width="66.666%" style="padding-top: 5px;">
                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                      <tr>
                        <td>
                          <ul>
                            <li><span class="text"><?php echo $common[0]->value; ?> <br><?php echo $common[1]->value; ?></span></li>
                          </ul>
                        </td>
                      </tr>
                    </table>
                  </td>
                  <td valign="top" width="33.333%">
                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                      <tr>
                        <td style="text-align: center; padding-left: 5px; padding-right: 5px;">
                          <p><a href="<?php echo $common[2]->value; ?>" class="btn btn-primary"><?php echo $common[3]->value; ?></a></p>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </div>
    </center>
  </body>

  </html>
<?php
  $string = ob_get_contents();
  ob_clean();
  return $string;
}



function getRandomNo($no, $type)
{
  $random_no = str_pad(mt_rand(11111111, 99999999), $no, '0', STR_PAD_LEFT);
  $data = getIdFromCode($random_no, $type);
  if ($data != null) {
    getRandomNo($no, $type);
  }
  return $random_no;
}

function getIdFromCode($code, $type)
{
  $data = null;
  if ($type == 'user') {
    $data = User::where('code', $code)->first();
  }
  if ($type == 'category') {
    $data = Category::where('code', $code)->first();
  }
  if ($type == 'product') {
    $data = Product::where('code', $code)->first();
  }
  return $data;
}

function GenerateCode($type)
{
  if ($type == 'user') {
    $datas = User::where('code', null)->get();
  }
  if ($type == 'category') {
    $datas = Category::where('code', null)->get();
  }
  if ($type == 'product') {
    $datas = Product::where('code', null)->get();
  }

  if ($type != null) {
    foreach ($datas as $data) {
      $random_code = getRandomNo(6, $type);
      $data->code = $random_code;
      $data->Save();
    }
  }
}

//for barcode generate
function imageGenereaterBlock($txt_sku, $br_code_str, $filename, $txt_save, $resize_width, $resize_height, $path)
{
  //$path = 'qr_data';
  // Replace path by your own font path
  $font = $path . '/ariblk.ttf';

  strCodeGenerate($br_code_str, $filename, $resize_width, $resize_height, $path);

  $fontSize = 120;
  $backgroundImg = "txt-block.png";
  $padding = 100; //from edges
  //$txt_save = "str-block.png";

  textBlockGenerate($txt_sku, $font, $fontSize, $backgroundImg, $padding, $txt_save, $path);
}
function strCodeGenerate($code_str, $filename, $width, $height, $path = null)
{
  //$file_nm = $path .'/' .$file_nm;

  imageGenerate($code_str, $filename, $height, $path);
  imageResize($filename, $width, $height, $path);
}
function imageGenerate($code, $file_nm, $height, $path = null)
{
  //require 'vendor/autoload.php';

  $generator = new Picqer\Barcode\BarcodeGeneratorPNG();
  $br_img = $generator->getBarcode($code, $generator::TYPE_CODE_128, 3, $height);

  $file_nm = $path . '/' . $file_nm;

  file_put_contents($file_nm, $br_img);
}
function imageResize($filename, $width, $height, $path = null)
{
  $filename = $path . '/' . $filename;

  $image = imagecreatefrompng($filename);
  $new_image = imagecreatetruecolor($width, $height); // new wigth and height
  imagealphablending($new_image, false);
  imagesavealpha($new_image, true);
  imagecopyresampled($new_image, $image, 0, 0, 0, 0, $width, $height, imagesx($image), imagesy($image));
  $image = $new_image;

  // saving
  imagealphablending($image, false);
  imagesavealpha($image, true);
  imagepng($image, $filename);

  imagedestroy($new_image);
  imagedestroy($image);
}

function textBlockGenerate($txt_sku, $font, $fontSize, $backgroundImg, $padding, $save, $path = null)
{
  $save = $path . '/' . $save;
  $backgroundPath = $path . '/' . $backgroundImg;
  //create image
  $im = imagecreatefrompng($backgroundPath);
  $imageSize = getimagesize($backgroundPath);
  $width = $imageSize[0];
  $height = $imageSize[1] + 250;

  //get textRows
  $textRows = GetTextRowsFromText($fontSize, $font, $txt_sku, $width - ($padding * 2));

  //colors
  $colorWhite = imagecolorallocate($im, 255, 255, 255);
  $colorBlack = imagecolorallocate($im, 0, 0, 0);
  $colorGrey = imagecolorallocate($im, 130, 130, 130);

  //border
  //imagerectangle($im, 0, 0, $width - 1, $height - 1, $colorGrey);

  for ($i = 0; $i < count($textRows); $i++) {
    //text size
    $line_box = imagettfbbox($fontSize, 0, $font, $textRows[$i]);
    $text_width = GetTextWidth($fontSize, $font, $textRows[$i]);
    $text_height = GetMaxTextHeight($fontSize, $font, $textRows) * 3;

    //align: center
    $position_center = ceil(($width - $text_width) / 2);

    //valign: middle
    $test = (count($textRows) - $i) - ceil(count($textRows) / 2);
    $position_middle = ceil(($height - ($text_height * $test)) / 2);

    imagettfstroketext($im, $fontSize, 0, $position_center, $position_middle, $colorBlack, $colorGrey, $font, $textRows[$i], 0);
  }

  imagepng($im, $save);
  //imagepng($im);
  imagedestroy($im);
}
function imagettfstroketext(&$image, $size, $angle, $x, $y, &$textcolor, &$strokecolor, $fontfile, $text, $px)
{

  for ($c1 = ($x - abs($px)); $c1 <= ($x + abs($px)); $c1++)
    for ($c2 = ($y - abs($px)); $c2 <= ($y + abs($px)); $c2++)
      $bg = imagettftext($image, $size, $angle, $c1, $c2, $strokecolor, $fontfile, $text);

  return imagettftext($image, $size, $angle, $x, $y, $textcolor, $fontfile, $text);
}

function GetTextWidth($fontSize, $font, $text)
{
  $line_box = imagettfbbox($fontSize, 0, $font, $text);
  return ceil($line_box[0] + $line_box[2]);
}

function GetTextHeight($fontSize, $font, $text)
{
  $line_box = imagettfbbox($fontSize, 0, $font, $text);
  return ceil($line_box[1] - $line_box[7]);
}

function GetMaxTextHeight($fontSize, $font, $textArray)
{
  $maxHeight = 0;
  for ($i = 0; $i < count($textArray); $i++) {
    $height = GetTextHeight($fontSize, $font, $textArray[$i]);
    if ($height > $maxHeight)
      $maxHeight = $height;
  }

  return $maxHeight;
}

function GetTextRowsFromText($fontSize, $font, $text, $maxWidth)
{
  $text = str_replace("\n", "\n ", $text);
  $text = str_replace("\\n", "\n ", $text);
  $words = explode(" ", $text);

  $rows = array();
  $tmpRow = "";
  for ($i = 0; $i < count($words); $i++) {

    //last word
    if ($i == count($words) - 1) {
      $rows[] = $tmpRow . $words[$i];
      break;;
    }


    if (GetTextWidth($fontSize, $font, $tmpRow . $words[$i]) > $maxWidth) //break
    {
      $rows[] = $tmpRow;
      $tmpRow = "";
    } else if (StringEndsWith($tmpRow, "\n ")) //break in text
    {
      $tmpRow = str_replace("\n ", "", $tmpRow);
      $rows[] = $tmpRow;
      $tmpRow = "";
    }

    //add new word to row
    $tmpRow .= $words[$i] . " ";
  }

  return $rows;
}

function StringEndsWith($haystack, $needle)
{
  return $needle === "" || substr($haystack, -strlen($needle)) === $needle;
}

function date_compare($a, $b)
{
  return strtotime($a['date']) <=> strtotime($b['date']);
}
function shopDeviceQuickOrderPDAShort($session_data)
{
  $short_itm_arr = array_unique(array_column($session_data, 'itm_id'));
  $final_array = array();
  foreach ($short_itm_arr as $itm_id) {
    $tmp = array();
    foreach ($_SESSION['device_quick_order_pda'] as $k => $s) {
      if ($s['itm_id'] == $itm_id) {
        $order_qty = (isset($tmp['order_qty']) && $tmp['order_qty'] != '' ? $tmp['order_qty'] : 0);
        $code = $s['barcode'];
        $qty = $s['qty'];

        $tmps = array();
        $tmps['code'] = $code;
        $tmps['qty'] = $qty;
        $tmp['scan_start'] = $s['scan_start'];
        $tmp['scan_end'] = $s['scan_end'];
        $tmp['skip_id'] = null;
        $tmp['product_id'] = $s['itm_id'];
        $tmp['itm'] = $s['itm'];
        $tmp['price'] = $s['price'];
        $tmp['order_qty'] = ($order_qty + $qty);
        $tmp['barcode'][] = $tmps;
      }
    }
    $final_array[] = $tmp;
  }
  return $final_array;
}
