-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2025 at 06:24 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prj1`
--

-- --------------------------------------------------------

--
-- Table structure for table `party`
--

CREATE TABLE `party` (
  `id` int(10) UNSIGNED NOT NULL,
  `cmp_name` varchar(255) DEFAULT NULL,
  `cmp_person_name` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gst_no` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permission`
--

CREATE TABLE `permission` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission` varchar(255) NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `permission`
--

INSERT INTO `permission` (`id`, `user_id`, `permission`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 2, 'all_user', 0, '2024-07-15 06:00:00', '2024-09-06 06:31:05'),
(2, 2, 'brand', 0, '2024-07-15 06:00:00', '2024-09-06 06:31:05'),
(3, 2, 'category', 0, '2024-07-15 06:00:00', '2024-09-06 06:31:05'),
(4, 2, 'company', 0, '2024-07-15 06:00:00', '2024-09-06 06:31:05'),
(5, 3, 'brand', 1, '2024-07-15 06:05:28', '2024-07-15 06:52:46'),
(6, 3, 'category', 1, '2024-07-15 06:05:28', '2024-07-15 06:52:46'),
(7, 3, 'company', 1, '2024-07-15 06:05:28', '2024-07-15 06:52:46'),
(8, 3, 'category_importer', 1, '2024-07-15 06:52:46', '2024-07-15 06:52:46'),
(9, 2, 'category_importer', 0, '2024-07-15 06:54:34', '2024-09-06 06:31:05'),
(10, 4, 'all_user', 1, '2024-07-15 07:13:23', '2024-07-15 07:13:23'),
(11, 4, 'brand', 1, '2024-07-15 07:13:23', '2024-07-15 07:13:23'),
(12, 4, 'category', 1, '2024-07-15 07:13:23', '2024-07-15 07:13:23'),
(13, 4, 'category_importer', 1, '2024-07-15 07:13:23', '2024-07-15 07:13:23'),
(14, 4, 'company', 1, '2024-07-15 07:13:23', '2024-07-15 07:13:23'),
(15, 2, 'all_product', 0, '2024-07-17 01:31:30', '2024-09-06 06:31:05'),
(16, 2, 'new_product', 0, '2024-07-17 01:31:30', '2024-09-06 06:31:05'),
(17, 1, 'product_managment', 1, '2024-09-06 06:31:34', '2024-09-15 05:58:35'),
(18, 1, 'party_managment', 1, '2024-09-07 10:11:50', '2024-09-15 05:58:35'),
(19, 1, 'purchase_managment', 1, '2024-09-07 12:04:50', '2024-09-15 05:58:35'),
(20, 1, 'sales_managment', 1, '2024-09-15 05:58:35', '2024-09-15 05:58:35');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `part_no` varchar(255) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `opening_stock` int(11) NOT NULL DEFAULT 0,
  `curr_stock` int(11) NOT NULL DEFAULT 0,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_stock_history`
--

CREATE TABLE `product_stock_history` (
  `id` int(10) UNSIGNED NOT NULL,
  `pdr_id` int(11) NOT NULL DEFAULT 0,
  `inv_id` int(11) DEFAULT NULL,
  `qty` int(11) NOT NULL DEFAULT 0,
  `old_curr_stock` int(11) NOT NULL DEFAULT 0,
  `new_curr_stock` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `type` varchar(255) DEFAULT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `id` int(10) UNSIGNED NOT NULL,
  `party_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `inv_no` varchar(255) NOT NULL,
  `remark` varchar(255) DEFAULT '',
  `purchase_inv_no` varchar(255) NOT NULL,
  `total_qty` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `purchase_date` datetime NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `purchase_item`
--

CREATE TABLE `purchase_item` (
  `id` int(10) UNSIGNED NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(10) UNSIGNED NOT NULL,
  `party_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `inv_no` varchar(255) NOT NULL,
  `remark` varchar(255) DEFAULT '',
  `sales_inv_no` varchar(255) NOT NULL,
  `sales_date` datetime NOT NULL,
  `total_qty` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales_item`
--

CREATE TABLE `sales_item` (
  `id` int(10) UNSIGNED NOT NULL,
  `sales_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact_no` varchar(255) DEFAULT NULL,
  `user_type` varchar(255) NOT NULL,
  `prefix` varchar(255) DEFAULT NULL,
  `wallet_amount` varchar(255) DEFAULT '0',
  `wallet_limit` varchar(255) DEFAULT '0',
  `parent_admin_user_id` int(11) DEFAULT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `code` varchar(255) DEFAULT NULL,
  `last_login` varchar(255) DEFAULT NULL,
  `invoice_ttl` varchar(255) DEFAULT NULL,
  `invoice_vat` varchar(255) DEFAULT NULL,
  `invoice_address` varchar(255) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `map_link` varchar(255) DEFAULT NULL,
  `last_fetch` datetime DEFAULT NULL,
  `vat` int(11) DEFAULT 20,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `email`, `password`, `contact_no`, `user_type`, `prefix`, `wallet_amount`, `wallet_limit`, `parent_admin_user_id`, `is_active`, `code`, `last_login`, `invoice_ttl`, `invoice_vat`, `invoice_address`, `close_time`, `map_link`, `last_fetch`, `vat`, `created_at`, `updated_at`) VALUES
(1, 'Master', 'Admin', 'rakesh', '25d9da3cf48a1b7730171fb1793c1e36', NULL, 'master_admin', NULL, '0', '0', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-09-14 10:04:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `party`
--
ALTER TABLE `party`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permission`
--
ALTER TABLE `permission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_stock_history`
--
ALTER TABLE `product_stock_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase_item`
--
ALTER TABLE `purchase_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales_item`
--
ALTER TABLE `sales_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_code_unique` (`code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `party`
--
ALTER TABLE `party`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permission`
--
ALTER TABLE `permission`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_stock_history`
--
ALTER TABLE `product_stock_history`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `purchase_item`
--
ALTER TABLE `purchase_item`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales_item`
--
ALTER TABLE `sales_item`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
