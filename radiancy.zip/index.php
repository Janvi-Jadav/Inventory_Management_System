<?php

require "bootstrap.php";
$usr_id = $_SESSION['user_data']['user_id'];

$user_status = User::checkUserStatus($usr_id);
if ($user_status == null) {
  FlashMessage::set('login not allowed retry for login', 'error');
  redirect('/logout.php');
}
//$simple_display_mode = false;
//$user_name = 'Rakesh Gupta';
//$user_type = 'master_admin';


if (isset($_GET['view']) && $_GET['view'] != '') {
  $view_folder = $_GET['view'];
  $data['page'] = $_GET['view'];
} else {
  $view_folder = 'dashboard';
  $data['page'] = 'dashboard';
}
$action = (isset($eod_data['action']) ? $eod_data['action'] : '');


include('views/backend/index.php');
