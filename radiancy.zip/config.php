<?php
$sit_db_data = 'local';
// $sit_db_data = 'live';
if ($sit_db_data == 'local') {
  $sit_url = 'http://localhost/radiancy';
  $doc_rt_url = $_SERVER['DOCUMENT_ROOT'] . '/radiancy/';

  $server_host = "localhost";
  $server_db = 'prj1';
  $server_user = 'root';
  $server_pass = '';
} else {
  $sit_url = 'https://pos.delivermyvape.co.uk';
  $doc_rt_url = $_SERVER['DOCUMENT_ROOT'] . '/';

  $server_host = "localhost";
  $server_db = 'delivery_pos';
  $server_user = 'delivery_pos_user';
  $server_pass = '8Gm*[lBO+jru';
}
