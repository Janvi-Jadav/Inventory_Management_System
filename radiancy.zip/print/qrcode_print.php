<?php session_start(); ?>
<?php require "../bootstrap.php";
$cs_id = get_form_value('cs_id');
if (isset($cs_id) && $cs_id != '') {
	//dd(base64_decode($cs_id));
	$ids = base64_decode($cs_id);
	$data = explode(',', $ids);
	$cs = CurrentStock::whereIn('id', $data)->get();

	if ($cs == null) {
		redirect('/index.php?view=dashboard');
	}
} else {
	redirect('/index.php?view=dashboard');
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link href="style.css" rel="stylesheet">
	<!--<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>-->
	<title>QRcode</title>
	<script type="text/javascript">
		function printDiv(divID) {
			var divElements = document.getElementById(divID).innerHTML;
			var oldPage = document.body.innerHTML;
			document.body.innerHTML = "<html><head><title></title></head><body>" + divElements + "</body>";
			window.print();
			document.body.innerHTML = oldPage;
		}
	</script>
</head>

<body ng-app="myApp" ng-controller="myCtrl">
	<page size="A4" id="mypdf">
		<form action="#" method="post">
			<div class="print" style="margin: 0px;">
				<a href="javascript:void(0);" onClick="javascript:printDiv('DivIdToPrint');" id="print_button1">Print Full Page</a>
				<?php /*?><a href="javascript:void(0);" onClick="javascript:downloadDiv('mypdf','Asian PDF');" id="print_button1">Download Page</a><?php */ ?>
				<div class="mrgn-30 wrapper DivIdToPrint" id="DivIdToPrint">
					<header class="clearfix">
					</header>
					<main class="w-100">
						<div class="hgt mb-10 perfoma">
							<table class="itm_dtl mb-0">
								<tbody>
									<?php $i = 0;
									foreach ($cs as $c) {
										$i++; ?>
										<td><img src="<?php echo $c->barcodeimagepath($c->barcode_img); ?>"><br><b><?php echo $c->barcode ?></b></td>
										<?php if ($i % 4 == 0) {
											echo '<tr>';
										} ?>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</main>
				</div>
			</div>
		</form>
	</page>
</body>

</html>
</script>
<?php if (isset($_POST['print']) && $_POST['print'] == 'Download PDF') { ?>
	<script>
		printDiv('DivIdToPrint');
	</script>
<?php } ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script>
<script>
	function downloadDiv(id, filename) {
		html2canvas([document.getElementById('mypdf')], {
			dpi: 300, // Set to 300 DPI
			scale: 1, // Adjusts your resolution
			onrendered: function(canvas) {
				//document.body.appendChild(canvas);
				var imgData = canvas.toDataURL("image/png");
				var doc = new jsPDF();

				doc.addImage(imgData, 'png', 0, 0);
				doc.save(filename + '.pdf');
			}
		});
		return false;
	}
</script>