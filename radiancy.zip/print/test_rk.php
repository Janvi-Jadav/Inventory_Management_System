<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link href="style.css" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
	<title>Asian Return</title>
	<script type="text/javascript">
		function printDiv(divID) {
			var divElements = document.getElementById(divID).innerHTML;
			var oldPage = document.body.innerHTML;
			document.body.innerHTML = "<html><head><title></title></head><body>" + divElements + "</body>";
			window.print();
			document.body.innerHTML = oldPage;
		}
	</script>
</head>
<body ng-app="myApp" ng-controller="myCtrl">
<page size="A4" id="mypdf">
	<div class="print" style="margin: 15px;">
		<a href="javascript:void(0);" onClick="javascript:printDiv('DivIdToPrint');" id="print_button1">Print Full Page</a>
		<a href="javascript:void(0);" onClick="javascript:downloadDiv('mypdf','Asian Return');" id="print_button1">Download Page</a>
		<div class="mrgn-30 wrapper DivIdToPrint" id="DivIdToPrint" >
			<header class="clearfix">
				<img src="head_img.jpg" style="width: 100%;"/>
				<div class="hd_add">Factory Add :-  At - Virpar(Morbi),  Opp. Ajanta Clock, Morbi-Rajkot Highway. Phone:- (02822)233355</div>
				<div class="hd_add"><b>Delivery Challan ( JOBWORK )</b></div>
			</header>
			<main style="width:100%;" >
				<div class=" hgt mb-10 perfoma">
					<table style="margin-bottom: 0px;">
						<tr>
							<td class="bdr-r-0">
								<b>GSTIN : 24AAHCA7492G1ZJ</b>
							</td>
							<td class="bdr-l-0">
								<div class="head_btm">
									<div class="chln_type">
										<label>ORIGINAL FOR CONSIGNEE :</label>
										<input type="text" />		
									</div>
									<div class="chln_type">
										<label>DUPLICATE FOR TRANSPORTER :</label>
										<input type="text" />		
									</div>
									<div class="chln_type">
										<label>TRIPLICATE FOR CONSIGNOR :</label>
										<input type="text" />		
									</div>
								</div>
							</td>
						</tr>
					</table>
					<table class="" style="margin-bottom: 0px;">
						<tr>
							<td class="lft_dtl">
								<div class="head_dtl">
									<label>Challan No :</label>
									<input type="text" />		
								</div>
							</td>
							<td class="rgt_dtl">
								<div class="head_dtl">
									<label>Transportation Mode :</label>
									<input type="text" value="Road Transport" />		
								</div>
							</td>
						</tr>
						<tr>
							<td class="lft_dtl">
								<div class="head_dtl">
									<label>Challan Date :</label>
									<input type="text" />		
								</div>
							</td>
							<td class="rgt_dtl">
								<div class="head_dtl">
									<label>Vehicle Number :</label>
									<input type="text" value="Road Transport" />		
								</div>
							</td>
						</tr>
						<tr>
							<td class="lft_dtl">
								<div class="head_dtl">
									<label>Driver Name :</label>
									<input type="text" />		
								</div>
							</td>
							<td class="rgt_dtl">
								<div class="head_dtl">
									<label>Place of Supply :</label>
									<input type="text" value="Road Transport" />		
								</div>
							</td>
						</tr>
						<tr>
							<td class="lft_dtl">
								<div class="head_dtl">
									<label>Contact No :</label>
									<input type="text" />		
								</div>
							</td>
							<td class="rgt_dtl">
								<div class="head_dtl">
									<label>Purpose :</label>
									<input type="text" value="Road Transport" />		
								</div>
							</td>
						</tr>
					</table>
					<table class="" style="margin-bottom: 5px;">
						<tr>
							<td class="bold font-18 text-center">Details of Receiver / Jobworker :-</td>
							<td class="bold font-18 text-center">Details of Consignee / Shipped to.</td>
						</tr>
						<tr>
							<td class="">
								<table class="">
									<tr>
										<td>Name:</td>
										<td>
											<div class="head_dtl">
												<input type="text" value="Sarpo Gravures" />		
											</div>
										</td>
									</tr>
									<tr>
										<td>Address :</td>
										<td>
											<div class="head_dtl">
												<textarea>78, 7 Phase-01, Nr.Water Tank, Vatva GIDC, Ahmedabad</textarea>
											</div>
										</td>
									</tr>
									<tr>
										<td>GSTIN:</td>
										<td>
											<div class="head_dtl">
												<input type="text" value="24AAMCS5788E1ZX" />		
											</div>
										</td>
									</tr>
									<tr>
										<td>State:</td>
										<td>
											<div class="head_dtl">
												<input type="text" value="Gujarat" />		
											</div>
										</td>
									</tr>
									<tr>
										<td>State Code:</td>
										<td>
											<div class="head_dtl">
												<input type="text" value="24" />		
											</div>
										</td>
									</tr>
									<tr>
										<td>Purchase Order :</td>
										<td>
											<div class="head_dtl">
												<input type="text" value="" />		
											</div>
										</td>
									</tr>
									<tr>
										<td>Contact Person Name :</td>
										<td>
											<div class="head_dtl">
												<input type="text" value="Amitbhai" />		
											</div>
										</td>
									</tr>
								</table>
							</td>
							<td class="">
								<table class="">
									<tr>
										<td>Name:</td>
										<td>
											<div class="head_dtl">
												<input type="text" value="Sarpo Gravures" />		
											</div>
										</td>
									</tr>
									<tr>
										<td>Address :</td>
										<td>
											<div class="head_dtl">
												<textarea>78, 7 Phase-01, Nr.Water Tank, Vatva GIDC, Ahmedabad</textarea>
											</div>
										</td>
									</tr>
									<tr>
										<td>GSTIN:</td>
										<td>
											<div class="head_dtl">
												<input type="text" value="24AAMCS5788E1ZX" />		
											</div>
										</td>
									</tr>
									<tr>
										<td>State:</td>
										<td>
											<div class="head_dtl">
												<input type="text" value="Gujarat" />	
													
											</div>
										</td>
									</tr>
									<tr>
										<td>State Code:</td>
										<td>
											<div class="head_dtl">
												<input type="text" value="24" />		
												<label>Transporter : Self</label>
											</div>
										</td>
									</tr>
									<tr>
										<td>GR No. & Date :</td>
										<td>
											<div class="head_dtl">
												<input type="text" value="" />		
											</div>
										</td>
									</tr>
									<tr>
										<td>Contact No :</td>
										<td>
											<div class="head_dtl">
												<input type="text" value="98791 83541" />		
											</div>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
					

					<table >

						<thead>

							<tr><th><strong>Size</strong></th><th><strong>Pic/Box</strong></th><th><strong>Design</strong></th><th><strong>Grade</strong></th><th><strong>Qty</strong></th><th><strong>Rate</strong></th><th><strong>Amount</strong></th></tr>

						</thead>

						<tbody>

						<?php 

						$total_qty = 0;

						$total_amt = 0;

						if(isset($size_order) && $size_order !=''){

							foreach($size_order as $k=>$s_ord){

								$size = $obj_fun->getSizeById($s_ord['size_id']);

								$packing = $obj_fun->getPackingById($s_ord['packing_id']);

								$design = $obj_fun->getDesignById($s_ord['design_id']);

								$design_group = $obj_fun->getDesignGroupById($design['group_id']);

								

								$prty_price = $obj_fun->getPriceListGroupandParty($design['group_id'], $party['id']);

								if(isset($prty_price) && ($prty_price['price'] !='' && $prty_price['price'] != 0)){

									$prty_price = $prty_price['price'];

								}else{
									$prty_price = $design_group['price'];

									

								}
									$def_pic_price = $obj_fun->getSettingsType('set_price_per_pic', $s_ord['size_id']);

									//$price_rate = ((($packing['name']*$design_group['price'])/$def_pic_price)*$s_ord['no_of_box']);
									//echo $packing['name'].'<br/>'.$design_group['price'].'<br/>'.$def_pic_price;
									$price_rate = ((($packing['name']*$prty_price)/$def_pic_price));

								//$price_rate = (isset($prty_price) && $prty_price['price'] !='' ? $prty_price['price'] : $design_group['price']);

								

								$total_qty = ($total_qty + $s_ord['no_of_box']);

								$pr_amt = ($s_ord['no_of_box'] * $price_rate);

								$total_amt = ($total_amt + $pr_amt);

						?>

						<tr>

							<td><?php echo $size['name']; ?></td>

							<td><?php echo $packing['name']; ?></td>

							<td><?php echo $design['name']; ?></td>

							<td>PRM</td>

							<td class="txt-right"><?php echo $s_ord['no_of_box']; ?></td>

							<td class="txt-right"><?php echo $price_rate; ?></td>

							<td class="txt-right"><?php echo $pr_amt; ?></td>

						</tr>

						<?php }

						}?>	

							<tr>

								<td rowspan="4" colspan="3"></td>

								<td><strong>Total Qty</strong></td>

								<td class="txt-right"><strong><?php echo $total_qty;?></strong></td>

								<td><strong>Total Amount</strong></td>

								<td class="txt-right"><strong><span id="total_amt" ng-bind="total_amount"></span></strong></td>

							</tr>

							<tr>

								<td><strong>Dis. %</strong></td>

								<td class="p-0" ng-mouseover="show_discount_box()" ng-mouseleave="hide_discount_box()">

									<p ng-bind="discount_percentage" ng-hide="discount_box"></p>

									<?php if(isset($_SESSION['users']['type']) and $_SESSION['users']['type'] == 'master-admin'){?>

									<input type="number" ng-change="discount_change()" ng-model="discount_percentage" ng-show="discount_box" size="5" />

									<?php }?>

								</td>

								<td><strong>Discount</strong></td>

								<td class="txt-right"><strong><p ng-bind="discount"></p></strong></td>

							</tr>

							<tr>

								<td></td>

								<td></td>

								<td><strong>Taxable Amount</strong></td>

								<td class="txt-right"><strong><p ng-bind="taxable_amount"></p></strong></td>

							</tr>

							<tr>

								<td><strong>Fright</strong></td>

								<td class="txt-right p-0" ng-mouseover="show_fright_box()" ng-mouseleave="hide_fright_box()">

									<p ng-bind="fright_amount" ng-hide="fright_box"></p>

									<?php if(isset($_SESSION['users']['type']) and $_SESSION['users']['type'] == 'master-admin'){?>

									<input type="number" ng-change="fright_change()" ng-model="fright_amount" ng-show="fright_box" size="5" />

									<?php }?>

								</td>

								<td><strong>INS.</strong></td>

								<td class="txt-right"><p ng-bind="insurance_amount"></p></td>

							</tr>

							<tr>

								<td colspan="5"><strong>Bank Details</strong></td>

								<td><strong>Total Amount</strong></td>

								<td class="txt-right"><strong><p ng-bind="total_amount_final"></p></strong></td>

							</tr>

							<tr>

								<td colspan="5" rowspan="3" class="p-0">

									<table class="mb-0">

										<tr>

											<td><strong><?php echo $obj_fun->getSettingsType('perfoma', 'company');?></strong></td>

											<td><strong><?php echo $obj_fun->getSettingsType('perfoma', 'company_2');?></strong></td>

										</tr>

										<tr>

											<td><strong><?php echo $obj_fun->getSettingsType('perfoma', 'bank_name');?></strong></td>

											<td><strong><?php echo $obj_fun->getSettingsType('perfoma', 'bank_name_2');?></strong></td>

										</tr>

										<tr>

											<td><strong><?php echo $obj_fun->getSettingsType('perfoma', 'bank_account');?></strong></td>

											<td><strong><?php echo $obj_fun->getSettingsType('perfoma', 'bank_account_2');?></strong></td>

										</tr>

										<tr>

											<td><strong><?php echo $obj_fun->getSettingsType('perfoma', 'bank_ifsc');?></strong></td>

											<td><strong><?php echo $obj_fun->getSettingsType('perfoma', 'bank_ifsc_2');?></strong></td>

										</tr>

										<tr>

											<td><strong><?php echo $obj_fun->getSettingsType('perfoma', 'bank_branch');?></strong></td>

											<td><strong><?php echo $obj_fun->getSettingsType('perfoma', 'bank_branch_2');?></strong></td>

										</tr>

									</table>

								</td>

								<td><strong>IGST <?php echo $obj_fun->getSettingsType('perfoma', 'igst');?>%</strong></td>

								<td class="txt-right"><strong><p ng-bind="igst_amount"></p></strong></td>

							</tr>

							<tr>

								<td><strong>INVOICE AMOUNT</strong></td>

								<td class="txt-right"><strong><p ng-bind="invoice_amount"></p></strong></td>

							</tr>

							

							

						</tbody>

					</table>

				</div>	

			</main>

		</div>

	</div>

</page>

</body>

</html>

<?php 

$discount = $obj_fun->getDiscount($_GET['party_id'], $_GET['order_group_id']); 

$fright = $obj_fun->getFright($_GET['party_id'], $_GET['order_group_id']); 

?>

<script>

var app = angular.module('myApp', []);

app.controller('myCtrl', function($scope,$http) {

	

	$scope.discount_box = 0;

	$scope.fright_box = 0;

	

	$scope.party_id = <?php echo $_GET['party_id']; ?>;

	$scope.order_group_id = <?php echo $_GET['order_group_id']; ?>;

	$scope.total_amount = <?php echo $total_amt;?>;

    $scope.discount_percentage = <?php echo $discount; ?>;

	$scope.discount = (($scope.total_amount * $scope.discount_percentage)/100).toFixed(2);

	$scope.taxable_amount = ($scope.total_amount - $scope.discount).toFixed(2);

	$scope.insurance_rate = <?php echo $obj_fun->getSettingsType('perfoma', 'insurance'); ?>;

	$scope.gst_rate = <?php echo $obj_fun->getSettingsType('perfoma', 'igst'); ?>;

	$scope.insurance_amount = (($scope.taxable_amount * $scope.insurance_rate)/100).toFixed(2);

	$scope.fright_amount = <?php echo $fright; ?>;

	$scope.total_amount_final =  parseFloat($scope.taxable_amount) + parseFloat($scope.insurance_amount) + $scope.fright_amount;

	$scope.igst_amount = (($scope.total_amount_final * $scope.gst_rate)/100).toFixed(2);

	$scope.invoice_amount = (parseFloat($scope.total_amount_final) + parseFloat($scope.igst_amount)).toFixed(2);

	

	$scope.discount_change = function() {

		

	   //$scope.update_in_db();	

       $scope.discount = (($scope.total_amount * $scope.discount_percentage)/100).toFixed(2);

	   $scope.taxable_amount = ($scope.total_amount - $scope.discount).toFixed(2);

	   $scope.insurance_amount = (($scope.taxable_amount * $scope.insurance_rate)/100).toFixed(2);

	   $scope.fright_change();

	   

    };

	

	$scope.fright_change = function(){

	

		$scope.update_in_db();

		$scope.total_amount_final =  parseFloat($scope.taxable_amount) + parseFloat($scope.insurance_amount) + $scope.fright_amount;

		$scope.igst_amount = (($scope.total_amount_final * $scope.gst_rate)/100).toFixed(2);

		$scope.invoice_amount = (parseFloat($scope.total_amount_final) + parseFloat($scope.igst_amount)).toFixed(2);

	}

	

	$scope.update_in_db = function(){

			

			$http.get("ajax_data.php?action=generate_perfoma&party_id="+$scope.party_id+"&order_group_id="+$scope.order_group_id+"&discount="+$scope.discount_percentage+"&fright="+$scope.fright_amount)

			.then(function(response) {

				console.log(response.data);

			});

		

	}

	

	$scope.show_discount_box = function(){

		$scope.discount_box = 1;

	}

	$scope.hide_discount_box = function(){

		$scope.discount_box = 0;

	}

	$scope.show_fright_box = function(){

		$scope.fright_box = 1;

	}

	$scope.hide_fright_box = function(){

		$scope.fright_box = 0;

	}

   // $scope.lastname = "Doe";   

	

	 

});

</script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script>
<script>
function downloadDiv(id,filename){
	html2canvas([document.getElementById('mypdf')], {
		dpi: 300, // Set to 300 DPI
    	scale: 1, // Adjusts your resolution
		onrendered: function(canvas) {
			
    		//document.body.appendChild(canvas);
       	 	var imgData = canvas.toDataURL("image/png");
 			var doc = new jsPDF();
			
			doc.addImage(imgData, 'png', 0, 0);
			doc.save(filename+'.pdf');
   		}
	});
	return false;
}
</script>
