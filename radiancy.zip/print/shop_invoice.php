<?php session_start(); ?>
<?php require "../bootstrap.php";
$bill_id = get_form_value('bill_id');
$shop_id = get_form_value('shop_id');
if (isset($bill_id) && $bill_id != '') {
	$bill = (new SpBill($shop_id))::getMyStock($bill_id, $shop_id);
	if ($bill != null) {
		$date = Carbon\Carbon::parse($bill->datetime)->format('d/m/Y');
	} else {
		redirect('/index.php?view=dashboard');
	}
} else {
	redirect('/index.php?view=dashboard');
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="style_old.css" rel="stylesheet">
	<!--<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>-->
	<title>POS</title>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script src="<?php echo $config['site_url'] . '/bower_components/html2canvas.js'; ?>" type="text/javascript"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.8.1/html2pdf.bundle.min.js"></script>
</head>

<body ng-app="myApp" ng-controller="myCtrl">
	<div id="mypdf">
		<form action="#" method="post">
			<div class="print" style="margin: 0px;">
				<!--<a href="javascript:void(0);" onClick="javascript:printDiv('DivIdToPrint');" id="print_button1">Print Full Page</a>-->
				<?php /*?><?php */ ?>
				<div class="mrgn-30 wrapper DivIdToPrint" id="DivIdToPrint">
					<header class="clearfix">
						<div class="hd_add">
							<div class="row" style="padding: 3px;">
								<div class="col-4" style="text-align: left;"><b>Date : </b> <?php echo $date ?></div>
								<div class="col-4" style="text-align: left;"></div>
								<div class="col-4" style="text-align: right;"><b>Invoice No. : </b><?php echo $bill->inv ?></div>
							</div>
						</div>
					</header>
					<main class="w-100">
						<div class="hgt mb-10 perfoma">
							<table class="mb-0">
							</table>
							<table class="add_dtl mb-5">
							</table>
							<table class="itm_dtl mb-0">
								<thead>
									<tr>
										<th>S.NO.</th>
										<th>NAME OF PRODUCT</th>
										<th>QUANTITY</th>
										<th>PRICE</th>
										<th>TOTAL</th>
									</tr>
								</thead>
								<tbody>
									<?php $i = 1;
									foreach ($bill->stock_items as $item) { ?>
										<tr>
											<td><?php echo $i++ ?></td>
											<td><small><b>Name : </b><?php echo $item->product->name ?><br><b>Barcode : </b><?php echo $item->product->barcode; ?></small></td>
											<td><?php echo $item->qty ?></td>
											<td><?php echo $currency_icon . get_float_num($item->rate) ?></td>
											<td><?php echo $currency_icon . get_float_num($item->amount)  ?></td>
										</tr>
									<?php } ?>
									<tr class="empty_rw">
										<td></td>
										<td></td>
										<td></td>
										<td>Quantity </td>
										<td>
											<div id="TOTAL"><?php echo $bill->qty ?></div>
										</td>
									</tr>
									<tr class="empty_rw">
										<td colspan="3"></td>
										<td>Total Amount</td>
										<td><span id="ntow" style="text-transform: capitalize;"><?php echo $currency_icon . get_float_num($bill->amount) ?></span></th>
									</tr>
								</tbody>
							</table>
							<table class="footer_dtl">
								<tbody>
								</tbody>
							</table>
						</div>
					</main>
				</div>
			</div>
		</form>
	</div>
</body>

</html>
<script>
	addEventListener('load', (event) => {
		let element = document.getElementById('mypdf');
		//html2pdf(element);
		var opt = {
			margin: 0.3,
			filename: "<?php echo $bill->shop->first_name . ' ' . $bill->shop->lat_name . '_' . $date ?>_" + Math.round(new Date().getTime() + (Math.random() * 100)) + '.pdf',
			image: {
				type: 'jpeg',
				quality: 1
			},
			html2canvas: {
				scale: 5
			},
			jsPDF: {
				unit: 'in',
				format: 'letter',
				orientation: 'portrait'
			}
		};
		//html2pdf().set(opt).from(element).save();
		html2pdf(element, opt);

		setTimeout(function() {
			history.go(-1);
		}, 500);

	});
</script>