<?php session_start(); ?>
<?php require "../bootstrap.php";

$type = get_form_value('type');
$category = get_form_value('category');
$brand = get_form_value('brand');
$search = get_form_value('search');
$order_by = get_form_value('order_by');

$wr_min_stock = Product::getMinStockProductWithPagination(0, 0, $category, $brand, $search, $order_by, 'asc', 'no');



if ($type == 'pdf') {
  GneratePDF::DownloadWrtodayOrder($wr_min_stock);
}
if ($type == 'excel') {
  GneratePDF::DownloadExcelWrtodayOrder($wr_min_stock);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="style_old.css" rel="stylesheet">
  <!--<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>-->
  <title>POS</title>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <script src="<?php echo $config['site_url'] . '/bower_components/html2canvas.js'; ?>" type="text/javascript"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.8.1/html2pdf.bundle.min.js"></script>
</head>

<body ng-app="myApp" ng-controller="myCtrl">
  <page size="custom_w_21" id="mypdf">
    <div id="mypdf">
      <form action="#" method="post">
        <div class="print" style="margin: 0px;">
          <div class="mrgn-30 wrapper DivIdToPrint" id="DivIdToPrint">
            <main class="w-100">
              <div class="hgt mb-10 perfoma">
                <table class="mb-0">
                </table>
                <table class="add_dtl mb-5">
                </table>
                <table class="itm_dtl mb-0">
                  <thead>
                    <tr>
                      <th scope="col">No <br><span></span< /th>
                      <th scope="col">Category <br><span></span< /th>
                      <th scope="col">Brand <br><span></span< /th>
                      <th scope="col">Name <br><span></span< /th>
                      <th scope="col">Req. Qty <br><span></span< /th>
                      <th scope="col">Last Order<br><span></span< /th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    if (isset($wr_min_stock) && $wr_min_stock != '') {
                      $i = 1;
                      foreach ($wr_min_stock as $key => $item) {
                        $name = $item['name'];
                        $category = $item['cat_name'];
                        $brand = $item['brand_name'];
                        $qty = $item['req_qty'];
                        $lastorderdate = $item['lastorderdate'];
                    ?>
                        <tr>
                          <td data-label="#"><?php echo $i++; ?></td>
                          <td data-label="Category">
                            <?php echo $category; ?>
                          </td>
                          <td data-label="Brand">
                            <?php echo $brand; ?>
                          </td>
                          <td data-label="Name">
                            <?php echo $name; ?>
                          </td>
                          <td data-label="Req. Qty">
                            <?php echo $qty; ?>
                          </td>
                          <td data-label="Last. Order">
                            <?php echo $lastorderdate; ?>
                          </td>
                        </tr>
                    <?php
                      }
                    } ?>
                  </tbody>
                </table>
              </div>
            </main>
          </div>
        </div>
      </form>
    </div>
  </page>
</body>

</html>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script>

<script>
  var filename = 'wr_today_order';
  addEventListener('load', (event) => {
    <?php if ($type == 'image') { ?>
      html2canvas([document.getElementById('mypdf')]).then(function(canvas) {
        var image = canvas.toDataURL('image/png');

        var downloadLink = document.createElement('a');
        downloadLink.href = image;
        downloadLink.download = filename + '.png';

        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
      });
    <?php } ?>

    setTimeout(function() {
      history.go(-1);
    }, 2000);

  });
</script>