<?php session_start(); ?>
<?php require "../bootstrap.php";
$shop_id = getSessionUserID();
$bill_id = get_form_value('bill_id');

if (isset($bill_id) && $bill_id != '') {
  $bill = RepairBill::where('id', $bill_id)->first();
  if ($bill != null) {
    $date = Carbon\Carbon::parse($bill->created_at)->format('d/m/Y');

    $name = $bill->name;
    $phone = $bill->phone;
    $ammount = $bill->ammount;
    $token = $bill->invoice_no;


    $shop = User::where('user_id', $shop_id)->first();
    $ttl = $shop->invoice_ttl != null ? $shop->invoice_ttl : $shop->first_name . ' ' . $shop->last_name;
    $vat = $shop->invoice_vat;
    $address = $shop->invoice_address;
  } else {
    redirect('/index.php?view=dashboard');
  }
} else {
  redirect('/index.php?view=dashboard');
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link href="style.css" rel="stylesheet">
  <!--<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>-->
  <title>THERMAL PRINT</title>
  <script type="text/javascript">
    function printDiv(divID) {
      var divElements = document.getElementById(divID).innerHTML;
      var oldPage = document.body.innerHTML;
      document.body.innerHTML = "<html><head><title></title></head><body>" + divElements + "</body>";
      window.print();
      document.body.innerHTML = oldPage;
    }
  </script>
</head>

<body ng-app="myApp" ng-controller="myCtrl">
  <page size="custom_w_80" id="mypdf">
    <form action="#" method="post">
      <div class="print" style="margin: 0px;">
        <!--<a href="javascript:void(0);" onClick="javascript:printDiv('DivIdToPrint');" id="print_button1">Print Full Page</a>-->
        <?php /*?><input type="submit" name="print" id="print" value="Download PDF" class="print_button1" />
		<a href="javascript:void(0);" onClick="javascript:downloadDiv('mypdf','Asian PDF');" id="print_button1">Download Page</a><?php */ ?>
        <div class="mrgn-30 wrapper DivIdToPrint" id="DivIdToPrint">
          <header class="clearfix">
            <div class="head_img">
              <!-- <img src="head_img.jpg" class="w-100" /> -->
              <h1><?php echo $ttl ?></h1>
              <p class="hd_add"><?php echo $address ?></p>
              <p class="hd_add mb-0 pb-5">VAT Number : <?php echo $vat ?></p>
            </div>
          </header>
          <main class="w-100">
            <p class="hd_add mb-0 pb-5 text-center">Name : <?php echo $name ?></p>
            <p class="hd_add mb-0 pb-5 text-center">Token No : <?php echo $token ?></p>
            <p class="hd_add mb-0 pb-5 text-center">Phone : <?php echo $phone ?></p>

            <hr />
            <table class="bottom_dtl mb-0">
              <tr>
                <td class="btm_ttl">Total</td>
                <td class="text-right font-bold"><?php echo $currency_icon . get_float_num($ammount) ?></td>
              </tr>

            </table>
            <hr />
            <table class="bottom_dtl mb-0">
              <tr>
                <td class="text-left"><?php echo $date ?></td>
              </tr>
            </table>
          </main>
        </div>
      </div>
    </form>
  </page>

</body>

</html>
<?php function numbertoword($number)
{
  $no = floor($number);
  $point = round($number - $no, 2) * 100;
  $hundred = null;
  $digits_1 = strlen($no);
  $i = 0;
  $str = array();
  $words = array(
    '0' => '', '1' => 'one', '2' => 'two', '3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six', '7' => 'seven', '8' => 'eight', '9' => 'nine', '10' => 'ten', '11' => 'eleven', '12' => 'twelve', '13' => 'thirteen', '14' => 'fourteen', '15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
    '18' => 'eighteen', '19' => 'nineteen', '20' => 'twenty', '30' => 'thirty', '40' => 'forty', '50' => 'fifty', '60' => 'sixty', '70' => 'seventy', '80' => 'eighty', '90' => 'ninety'
  );
  $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
  while ($i < $digits_1) {
    $divider = ($i == 2) ? 10 : 100;
    $number = floor($no % $divider);
    $no = floor($no / $divider);
    $i += ($divider == 10) ? 1 : 2;
    if ($number) {
      $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
      //$hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
      $hundred = ($counter == 1 && $str[0]) ? ' ' : null;
      $str[] = ($number < 21) ? $words[$number] . " " . $digits[$counter] . $plural . " " . $hundred : $words[floor($number / 10) * 10] . " " . $words[$number % 10] . " " . $digits[$counter] . $plural . " " . $hundred;
    } else $str[] = null;
  }
  $str = array_reverse($str);
  $result = implode('', $str);
  $points = ($point) ? "." . $words[$point / 10] . " " . $words[$point = $point % 10] : '';
  return array('rupees' => $result, 'paise' => $points);
} ?>
<script>
  function checkNumber(value) {
    //alert(value);
    if (isNaN(value)) {
      alert(value);
    } else {

      var QUANTITY = document.getElementById('QUANTITY').innerHTML;
      var RATEUnit = document.getElementById('RATEUnit').value;
      var AMOUNTRs = document.getElementById('AMOUNTRs').innerHTML = (QUANTITY * RATEUnit);

      var TOTAL = document.getElementById('TOTAL').innerHTML = AMOUNTRs;
      var perc = ((9 * AMOUNTRs) / 100);

      var CGST = document.getElementById('CGST').innerHTML = perc;
      var SGST = document.getElementById('SGST').innerHTML = perc;
      var IGST = document.getElementById('IGST').innerHTML = (2 * perc);
      var gtotal = (TOTAL + CGST + SGST + IGST).toFixed(2);
      var GROSSTOTAL = document.getElementById('GROSSTOTAL').innerHTML = gtotal;
      var ntow = document.getElementById('ntow').innerHTML = toWords(GROSSTOTAL);
    }
    return false;
  }

  var th = ['', 'thousand', 'million', 'billion', 'trillion'];
  var dg = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
  var tn = ['ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
  var tw = ['twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

  function toWords(s) {
    s = s.toString();
    s = s.replace(/[\, ]/g, '');
    if (s != parseFloat(s)) return 'not a number';
    var x = s.indexOf('.');
    if (x == -1)
      x = s.length;
    if (x > 15)
      return 'too big';
    var n = s.split('');
    var str = '';
    var sk = 0;
    for (var i = 0; i < x; i++) {
      if ((x - i) % 3 == 2) {
        if (n[i] == '1') {
          str += tn[Number(n[i + 1])] + ' ';
          i++;
          sk = 1;
        } else if (n[i] != 0) {
          str += tw[n[i] - 2] + ' ';
          sk = 1;
        }
      } else if (n[i] != 0) { // 0235
        str += dg[n[i]] + ' ';
        if ((x - i) % 3 == 0) str += 'hundred ';
        sk = 1;
      }
      if ((x - i) % 3 == 1) {
        if (sk)
          str += th[(x - i - 1) / 3] + ' ';
        sk = 0;
      }
    }

    if (x != s.length) {
      var y = s.length;
      str += 'point ';
      for (var i = x + 1; i < y; i++)
        str += dg[n[i]] + ' ';
    }
    return str.replace(/\s+/g, ' ');
  }
</script>
<?php if (isset($_POST['print']) && $_POST['print'] == 'Download PDF') { ?>
  <script>
    printDiv('DivIdToPrint');
  </script>
<?php } ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script>
<script>
  function downloadDiv(id, filename) {
    html2canvas([document.getElementById('mypdf')], {
      dpi: 300, // Set to 300 DPI
      scale: 1, // Adjusts your resolution
      onrendered: function(canvas) {
        //document.body.appendChild(canvas);
        var imgData = canvas.toDataURL("image/png");
        var doc = new jsPDF();

        doc.addImage(imgData, 'png', 0, 0);
        doc.save(filename + '.pdf');
      }
    });
    return false;
  }

  window.addEventListener("load", (event) => {
    printDiv('DivIdToPrint');
  });
</script>