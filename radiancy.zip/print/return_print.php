<?php session_start(); ?>
<?php require "../bootstrap.php";
$cylinder_list_id = get_form_value('cylinder_list_id');
if(isset($cylinder_list_id) && $cylinder_list_id !=''){
	$cyl_inout = CylinderInout::getCylinderInOutByListId($cylinder_list_id);
	
	$cyl_list = CylinderList::where(array('id'=>$cylinder_list_id))->first();
	$jobs = Jobs::where(array('id'=>$cyl_list->job_id))->first();
	$job_name = $jobs->name;
	
	if($cyl_inout->is_repair == 1){
		$qty = $cyl_inout->repair_nos;
	}else{
		$qty = $cyl_list->nos;
	}
}else{
	//redirect('/index.php?view=cylinder_report&type=return');
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link href="style.css" rel="stylesheet">
	<!--<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>-->
	<title>Asian_Return_<?php echo $cylinder_list_id;?></title>
	<script type="text/javascript">
		function printDiv(divID) {
			var divElements = document.getElementById(divID).innerHTML;
			var oldPage = document.body.innerHTML;
			document.body.innerHTML = "<html><head><title></title></head><body>" + divElements + "</body>";
			window.print();
			document.body.innerHTML = oldPage;
		}
	</script>
</head>
<body ng-app="myApp" ng-controller="myCtrl">
<page size="A4" id="mypdf">
	<?php 
	$ofc = $dft = $tfc = $challan_no = $transportation_mode = $challan_date = $challan_date =  $vehicle_number = $driver_name = $place_of_supply = $Contact_No = $Purpose = $Name1 = $Name2 = $Address1 = $Address2 = $GSTIN1 = $GSTIN2 = $State1 = $State2 = $StateCode1 = $StateCode2 = $Transporter1 = $PurchaseOrder = $GRNoDate = $ContactPerson = $AddContactNo = $HSN_SAC = $RATEUnit = '';
	$RATEUnit = $AMOUNTRs = 0;
	@extract($_POST);
	
	$AMOUNTRs = $RATEUnit * $qty; 
	$TOTAL = $AMOUNTRs;
	$pers = ((9*$AMOUNTRs)/100);
	$CGST = $pers;
	$SGST = $pers;
	$IGST = $pers * 2;
	$GROSSTOTAL= $TOTAL + $CGST + $SGST + $IGST;
	if($GROSSTOTAL != 0){
		$numbr= numbertoword($GROSSTOTAL);
		$ntow = $numbr['rupees'] .' point '. $numbr['paise'];
	}else{
		$ntow='';
	}
	?>
	<form action="#" method="post">
	<div class="print" style="margin: 0px;">
		<!--<a href="javascript:void(0);" onClick="javascript:printDiv('DivIdToPrint');" id="print_button1">Print Full Page</a>-->
		<input type="submit" name="print" id="print" value="Download PDF" class="print_button1" />
		<?php /*?><a href="javascript:void(0);" onClick="javascript:downloadDiv('mypdf','Asian PDF');" id="print_button1">Download Page</a><?php */?>
		<div class="mrgn-30 wrapper DivIdToPrint" id="DivIdToPrint" >
			<header class="clearfix">
				<div class="head_img"><img src="head_img.jpg" class="w-100" /></div>
				<div class="hd_add">Factory Add :-  At - Virpar(Morbi),  Opp. Ajanta Clock, Morbi-Rajkot Highway. Phone:- (02822)233355</div>
				<div class="hd_add"><b>Delivery Challan ( JOBWORK )</b></div>
			</header>
			<main class="w-100" >
				<div class=" hgt mb-10 perfoma">
					<table class="mb-0">
						<tr>
							<td class="bdr-r-0">
								<b>GSTIN : 24AAHCA7492G1ZJ</b>
							</td>
							<td class="bdr-l-0">
								<div class="head_btm">
									<div class="chln_type">
										<label>ORIGINAL FOR CONSIGNEE :</label>
										<input type="text" name="ofc" id="ofc" value="<?php echo $ofc;?>" />		
									</div>
									<div class="chln_type">
										<label>DUPLICATE FOR TRANSPORTER :</label>
										<input type="text" name="dft" id="dft" value="<?php echo $dft;?>" />		
									</div>
									<div class="chln_type">
										<label>TRIPLICATE FOR CONSIGNOR :</label>
										<input type="text" name="tfc" id="tfc" value="<?php echo $tfc;?>" />		
									</div>
								</div>
							</td>
						</tr>
					</table>
					<table class="add_dtl mb-5">
						<tr>
							<td class="adr_ttl bold">Challan No :</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" name="challan_no" id="challan_no" value="<?php echo $challan_no;?>" />		
								</div>
							</td>
							<td class="adr_ttl">Transportation Mode :</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" name="transportation_mode" id="transportation_mode" value="<?php echo $transportation_mode;?>" />		
								</div>
							</td>
						</tr>
						<tr>
							<td class="adr_ttl">Challan Date :</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" name="challan_date" id="challan_date" value="<?php echo $challan_date;?>" />		
								</div>
							</td>
							<td class="adr_ttl">Vehicle Number :</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" name="vehicle_number" id="vehicle_number" value="<?php echo $vehicle_number;?>" />		
								</div>
							</td>
						</tr>
						<tr>
							<td class="adr_ttl">Driver Name:</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" name="driver_name" id="driver_name" value="<?php echo $driver_name;?>" />		
								</div>
							</td>
							<td class="adr_ttl">Place of Supply :</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" id="place_of_supply" name="place_of_supply" value="<?php echo $place_of_supply;?>" />		
								</div>
							</td>
						</tr>
						<tr>
							<td class="adr_ttl">Contact No:</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" id="Contact_No" name="Contact_No" value="<?php echo $Contact_No;?>"/>		
								</div>
							</td>
							<td class="adr_ttl font-20 bold p-0 pl-10">Purpose :</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" id="Purpose" name="Purpose" value="<?php echo $Purpose;?>" />		
								</div>
							</td>
						</tr>
						<tr>
							<td colspan="2" class="bold font-18 text-center">Details of Receiver / Jobworker :-</td>
							<td colspan="2" class="bold font-18 text-center">Details of Consignee / Shipped to.</td>
						</tr>
						<tr>
						<tr>
							<td class="adr_ttl">Name:</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" id="Name1" name="Name1" value="<?php echo $Name1;?>" />		
								</div>
							</td>
							<td class="adr_ttl">Name:</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" id="Name2" name="Name2" value="<?php echo $Name2;?>" />		
								</div>
							</td>
						</tr>
						<tr>
							<td class="adr_ttl">Address :</td>
							<td class="input">
								<div class="head_dtl">
									<textarea id="Address1" name="Address1"><?php echo $Address1;?></textarea>
								</div>
							</td>
							<td class="adr_ttl">Address :</td>
							<td class="input">
								<div class="head_dtl">
									<textarea id="Address2" name="Address2"><?php echo $Address2;?></textarea>
								</div>
							</td>
						</tr>
						<tr>
							<td class="adr_ttl">GSTIN:</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" id="GSTIN1" name="GSTIN1" value="<?php echo $GSTIN1;?>" />		
								</div>
							</td>
							<td class="adr_ttl">GSTIN:</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" id="GSTIN2" name="GSTIN2" value="<?php echo $GSTIN2;?>" />		
								</div>
							</td>
						</tr>
						<tr>
							<td class="adr_ttl">State:</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" id="State1" name="State1" value="<?php echo $State1;?>" />		
								</div>
							</td>
							<td class="adr_ttl">State:</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" id="State2" name="State2" value="<?php echo $State2;?>" />		
								</div>
							</td>
						</tr>
						<tr>
							<td class="adr_ttl">State Code:</td>
							<td  class="input">
								<div class="head_dtl">
									<input type="text" id="StateCode1" name="StateCode1" value="<?php echo $StateCode1;?>" />		
								</div>
							</td>
							<td class="adr_ttl">State Code:</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" id="StateCode2" name="StateCode2" value="<?php echo $StateCode2;?>" class="w-30"/>		
									<label class="pl-25">Transporter :</label>
									<input class="w-50" type="text" id="Transporter1" name="Transporter1" value="<?php echo $Transporter1;?>" />		
								</div>
							</td>
						</tr>
						<tr>
							<td class="adr_ttl">Purchase Order :</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" id="PurchaseOrder" name="PurchaseOrder" value="<?php echo $PurchaseOrder;?>" />		
								</div>
							</td>
							<td class="adr_ttl">GR No. & Date :</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" id="GRNoDate" name="GRNoDate" value="<?php echo $GRNoDate;?>" />		
								</div>
							</td>
						</tr>
						<tr>
							<td class="adr_ttl">Contact Person Name :</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" id="ContactPerson" name="ContactPerson" value="<?php echo $ContactPerson;?>" />		
								</div>
							</td>
							<td class="adr_ttl">Contact No :</td>
							<td class="input">
								<div class="head_dtl">
									<input type="text" id="AddContactNo" name="AddContactNo" value="<?php echo $AddContactNo;?>" />		
								</div>
							</td>
						</tr>
					</table>
						
					<table class="itm_dtl mb-0" >
						<thead>
							<tr>
								<th>S.NO.</th>
								<th>NAME OF PRODUCT / JOB</th>
								<th>HSN / SAC</th>
								<th>QUANTITY</th>
								<th>RATE per Unit</th>
								<th>AMOUNT (Rs.)</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>1</td>
								<td><?php echo $job_name;?></td>
								<td class="p-0"><div class="head_dtl">
									<input class="pdr_dtl" type="text" id="HSN_SAC" name="HSN_SAC"  value="<?php echo $HSN_SAC;?>"/>		
								</div></td>
								<td><div id="QUANTITY"><?php echo $qty;?></div></td>
								<td class="p-0"><div class="head_dtl">
									<input class="pdr_dtl" onKeyUp="return checkNumber(this.value, 'RATEUnit');"  type="text" id="RATEUnit" name="RATEUnit" value="<?php echo $RATEUnit;?>"/>		
								</div></td>
								<td class="p-0"><div class="head_dtl" id="AMOUNTRs" style="text-align:center;width: 100%;">
									<?php echo $AMOUNTRs;?>
									<?php /*?><input class="pdr_dtl" onKeyUp="return checkNumber(this.value, 'AMOUNTRs');" type="text" id="AMOUNTRs" name="AMOUNTRs" value="0"/>	<?php */?>	
								</div></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td>TOTAL :</td>
								<td><div id="TOTAL"><?php echo $TOTAL;?></div></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td>CGST (9%)</td>
								<td><div id="CGST"><?php echo $CGST;?></div></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td>SGST (9%)</td>
								<td><div id="SGST"><?php echo $SGST;?></div></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td>IGST (18%)</td>
								<td><div id="IGST"><?php echo $IGST;?></div></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td>GROSS TOTAL</td>
								<td><div id="GROSSTOTAL"><?php echo $GROSSTOTAL;?></div></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td>Total Quantity</td>
								<td><?php echo $qty;?></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
					<table class="footer_dtl" >
						<tbody>
							<tr>
								<th class="text-left" colspan="2">Challan Amt.(Words) : <span id="ntow" style="text-transform: capitalize;"><?php echo $ntow;?></span></th>
							</tr>
							<tr>
								<th>
									<div>
										<h5>Remark :</h5>
										<p>Terms & Condition  : At a dispatch time of cylinder please return our delivery.</p>
										<p>challan with sign & stamp.</p>
										<p>Cylinder should be dispatch within a week.</p>
										
									</div>
								</th>
								<th style="vertical-align: top;">Asian Flexi Pack India Pvt. Ltd. <br/><br/><br/>Authorised Signatory.</th>
							</tr>
						</tbody>
					</table>
					
				</div>	

			</main>

		</div>

	</div>
	</form>
</page>

</body>

</html>
<?php function numbertoword($number){
   $no = floor($number);
   $point = round($number - $no, 2) * 100;
   $hundred = null;
   $digits_1 = strlen($no);
   $i = 0;
   $str = array();
   $words = array('0' => '', '1' => 'one', '2' => 'two','3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six', '7' => 'seven', '8' => 'eight', '9' => 'nine','10' => 'ten', '11' => 'eleven', '12' => 'twelve', '13' => 'thirteen', '14' => 'fourteen','15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
    '18' => 'eighteen', '19' =>'nineteen', '20' => 'twenty','30' => 'thirty', '40' => 'forty', '50' => 'fifty','60' => 'sixty', '70' => 'seventy','80' => 'eighty', '90' => 'ninety');
   $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
   while ($i < $digits_1) {
     $divider = ($i == 2) ? 10 : 100;
     $number = floor($no % $divider);
     $no = floor($no / $divider);
     $i += ($divider == 10) ? 1 : 2;
     if ($number) {
        $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
        //$hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
        $hundred = ($counter == 1 && $str[0]) ? ' ' : null;
        $str [] = ($number < 21) ? $words[$number] . " " . $digits[$counter] . $plural . " " . $hundred : $words[floor($number / 10) * 10] . " " . $words[$number % 10] . " " . $digits[$counter] . $plural . " " . $hundred;
     } else $str[] = null;
  }
  $str = array_reverse($str);
  $result = implode('', $str);
  $points = ($point) ? "." . $words[$point / 10] . " " . $words[$point = $point % 10] : '';
  return array('rupees'=>$result, 'paise'=>$points);
}?>
<script>
function checkNumber(value){
	//alert(value);
	if(isNaN(value)){
		alert(value);
	}else{
	
		var QUANTITY = document.getElementById('QUANTITY').innerHTML;
		var RATEUnit = document.getElementById('RATEUnit').value;
		var AMOUNTRs = document.getElementById('AMOUNTRs').innerHTML = (QUANTITY * RATEUnit);
		
		var TOTAL = document.getElementById('TOTAL').innerHTML = AMOUNTRs;
		var perc = ((9*AMOUNTRs)/100);
		
		var CGST = document.getElementById('CGST').innerHTML = perc;
		var SGST = document.getElementById('SGST').innerHTML = perc;
		var IGST = document.getElementById('IGST').innerHTML = (2*perc);
		var gtotal = (TOTAL + CGST + SGST + IGST).toFixed(2);
		var GROSSTOTAL = document.getElementById('GROSSTOTAL').innerHTML = gtotal;
		var ntow = document.getElementById('ntow').innerHTML = toWords(GROSSTOTAL);
	}
	return false;
}

var th = ['','thousand','million', 'billion','trillion'];
var dg = ['zero','one','two','three','four', 'five','six','seven','eight','nine'];
var tn = ['ten','eleven','twelve','thirteen', 'fourteen','fifteen','sixteen', 'seventeen','eighteen','nineteen'];
var tw = ['twenty','thirty','forty','fifty', 'sixty','seventy','eighty','ninety'];

function toWords(s) {
    s = s.toString();
    s = s.replace(/[\, ]/g,'');
    if (s != parseFloat(s)) return 'not a number';
    var x = s.indexOf('.');
    if (x == -1)
        x = s.length;
    if (x > 15)
        return 'too big';
    var n = s.split(''); 
    var str = '';
    var sk = 0;
    for (var i=0;   i < x;  i++) {
        if ((x-i)%3==2) { 
            if (n[i] == '1') {
                str += tn[Number(n[i+1])] + ' ';
                i++;
                sk=1;
            } else if (n[i]!=0) {
                str += tw[n[i]-2] + ' ';
                sk=1;
            }
        } else if (n[i]!=0) { // 0235
            str += dg[n[i]] +' ';
            if ((x-i)%3==0) str += 'hundred ';
            sk=1;
        }
        if ((x-i)%3==1) {
            if (sk)
                str += th[(x-i-1)/3] + ' ';
            sk=0;
        }
    }

    if (x != s.length) {
        var y = s.length;
        str += 'point ';
        for (var i=x+1; i<y; i++)
            str += dg[n[i]] +' ';
    }
    return str.replace(/\s+/g,' ');
}
</script>
<?php if(isset($_POST['print']) && $_POST['print'] == 'Download PDF'){?>
	<script>printDiv('DivIdToPrint');</script>
<?php }?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script>
<script>
function downloadDiv(id,filename){
	html2canvas([document.getElementById('mypdf')], {
		dpi: 300, // Set to 300 DPI
		scale: 1, // Adjusts your resolution
		onrendered: function(canvas) {
			//document.body.appendChild(canvas);
      var imgData = canvas.toDataURL("image/png");
 			var doc = new jsPDF();
			
			doc.addImage(imgData, 'png', 0, 0);
			doc.save(filename+'.pdf');
   	}
	});
	return false;
}
</script>