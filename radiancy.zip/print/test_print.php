<?php session_start(); ?>
<?php require "../bootstrap.php";
$bill_id = get_form_value('bill_id');
if(isset($bill_id) && $bill_id !=''){
  $bill = Bill::getMyBill($bill_id);
  if($bill != null){
    $date = Carbon\Carbon::parse($bill->datetime)->format('d/m/Y');
  }else{
    redirect('/index.php?view=dashboard');
  }	
}else{
	redirect('/index.php?view=dashboard');
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link href="style.css" rel="stylesheet">
	<!--<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>-->
	<title>POS</title>
</head>
<body ng-app="myApp" ng-controller="myCtrl">
<page size="A4" id="mypdf">	
	<form action="#" method="post">
	<div class="print" style="margin: 0px;">
		<!--<a href="javascript:void(0);" onClick="javascript:printDiv('DivIdToPrint');" id="print_button1">Print Full Page</a>-->
		<?php /*?><a href="javascript:void(0);" onClick="javascript:downloadDiv('mypdf','Asian PDF');" id="print_button1">Download Page</a><?php */?>
		<div class="mrgn-30 wrapper DivIdToPrint" id="DivIdToPrint" >
			<header class="clearfix">
				<div class="hd_add">
          <div class="row" style="padding: 3px;">
            <div class="col-4" style="text-align: left;"><b>Date : </b> <?php echo $date ?></div>
            <div class="col-4" style="text-align: center;"><b>POS</b></div>
            <div class="col-4" style="text-align: right;"><b>Invoice No. : </b><?php echo $bill->invoice ?></div>
            <div class="col-4"><b>Pay By : </b><?php echo ucwords($bill->pay_by) ?></div>
          </div>
        </div>
			</header>
			<main class="w-100" >
				<div class="hgt mb-10 perfoma">
					<table class="mb-0">
					</table>
					<table class="add_dtl mb-5">
					</table>						
					<table class="itm_dtl mb-0" >
						<thead>
							<tr>
								<th>S.NO.</th>
								<th>NAME OF PRODUCT</th>								
								<th>QUANTITY</th>
								<th>PRICE</th>							
								<th>TOTAL</th>
							</tr>
						</thead>
						<tbody>
              <?php $i=1; foreach($bill->bill_items as $item) {?>
							<tr>
								<td><?php echo $i++ ?></td>
								<td><?php echo $item->product->name.' ('.$item->barcode.')'?></td>
								<td><?php echo $item->qty ?></td>
								<td><?php echo $currency_icon.get_float_num($item->unit_price) ?></td>								
								<td><?php echo $currency_icon.get_float_num($item->amount)  ?></td>
							</tr>			
              <?php } ?>		
              <tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>		
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td>Quantity </td>
								<td><div id="TOTAL"><?php echo $bill->total_qty ?></div></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td>Subtotal </td>
								<td><div id="CGST"><?php echo $currency_icon.get_float_num($bill->sub_amount) ?></div></td>
							</tr>
							<tr class="empty_rw">
								<td></td>
								<td></td>
								<td></td>
								<td>Discount </td>
								<td><div id="SGST"><?php echo $currency_icon.get_float_num($bill->other_charge) ?></div></td>
							</tr>
              <tr class="empty_rw">
                <td colspan="3"></td>
                <td>Total Amount</td>
								<td><span id="ntow" style="text-transform: capitalize;"><?php echo $currency_icon.get_float_num($bill->total_amount) ?></span></th>
							</tr>													
						</tbody>
					</table>
					<table class="footer_dtl" >
						<tbody>							
							<!-- <tr>
								<th>
									<div>
										<h5>Remark :</h5>
										<p>Terms & Condition  : At a dispatch time of cylinder please return our delivery.</p>
										<p>challan with sign & stamp.</p>
										<p>Cylinder should be dispatch within a week.</p>										
									</div>
								</th>
								<th style="vertical-align: top;">Asian Flexi Pack India Pvt. Ltd. <br/><br/><br/>Authorised Signatory.</th>
							</tr> -->
						</tbody>
					</table>
				</div>	
			</main>
		</div>
	</div>
	</form>
</page>
</body>

</html>
<?php function numbertoword($number){
   $no = floor($number);
   $point = round($number - $no, 2) * 100;
   $hundred = null;
   $digits_1 = strlen($no);
   $i = 0;
   $str = array();
   $words = array('0' => '', '1' => 'one', '2' => 'two','3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six', '7' => 'seven', '8' => 'eight', '9' => 'nine','10' => 'ten', '11' => 'eleven', '12' => 'twelve', '13' => 'thirteen', '14' => 'fourteen','15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
    '18' => 'eighteen', '19' =>'nineteen', '20' => 'twenty','30' => 'thirty', '40' => 'forty', '50' => 'fifty','60' => 'sixty', '70' => 'seventy','80' => 'eighty', '90' => 'ninety');
   $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
   while ($i < $digits_1) {
     $divider = ($i == 2) ? 10 : 100;
     $number = floor($no % $divider);
     $no = floor($no / $divider);
     $i += ($divider == 10) ? 1 : 2;
     if ($number) {
        $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
        //$hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
        $hundred = ($counter == 1 && $str[0]) ? ' ' : null;
        $str [] = ($number < 21) ? $words[$number] . " " . $digits[$counter] . $plural . " " . $hundred : $words[floor($number / 10) * 10] . " " . $words[$number % 10] . " " . $digits[$counter] . $plural . " " . $hundred;
     } else $str[] = null;
  }
  $str = array_reverse($str);
  $result = implode('', $str);
  $points = ($point) ? "." . $words[$point / 10] . " " . $words[$point = $point % 10] : '';
  return array('rupees'=>$result, 'paise'=>$points);
}?>
<script>

addEventListener('load', (event) => {
  window.print();
  document.location.href = "<?php echo $config['site_url'] ?>/index.php?view=pos"; 
});

</script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script>